// ��������-������ ��� Win32
// ������ �������� ������ � ������� Win32
// DLL: Kernel32,User32,Gdi32,Comdlg32,Comctl32,Riched20

definition module Win32;

//========================================================================
//                          ����� ���� � ��������� ������
//========================================================================

type pCARDINAL=pointer to cardinal;
type pINT=pointer to integer;
type pWORD=pointer to word;
type pBOOL=pointer to boolean;
type HANDLE=cardinal;
type pHANDLE=pointer to HANDLE;
type pBYTE=pointer to byte;
type pREAL=pointer to real;
type pPROC=address;
type ATOM=cardinal;
type COLORREF=cardinal;
type pCOLORREF=pointer to COLORREF;
type LARGE_INTEGER=array[0..1]of integer;
type ULARGE_INTEGER=array[0..1]of cardinal;
type pLARGE_INTEGER=pointer to LARGE_INTEGER;
type pULARGE_INTEGER=pointer to ULARGE_INTEGER;

type HWND=HANDLE;
type HGLOBAL=HANDLE;
type HLOCAL=HANDLE;
type HMODULE=HANDLE;
type HRSRC=HANDLE;
type HFILE=HANDLE;
type HKL=HANDLE;
type HDESK=HANDLE;
type HWINST=HANDLE;
type HINSTANCE=HANDLE;
type HICON=HANDLE;
type HCURSOR=HANDLE;
type HBRUSH=HANDLE;
type HMENU=HANDLE;
type HDC=HANDLE;
type HDWP=HANDLE;
type HACCEL=HANDLE;
type HBITMAP=HANDLE;
type HRGN=HANDLE;
type HHOOK=HANDLE;
type HGDIOBJ=HANDLE;
type HMETAFILE=HANDLE;
type HPALETTE=HANDLE;
type HFONT=HANDLE;
type HPEN=HANDLE;
type HENHMETAFILE=HANDLE;
type HCOLORSPACE=HANDLE;
type HIMAGELIST=HANDLE;
//type HDR=HANDLE;
type HKEY=HANDLE;
type HTREEITEM=HANDLE;
type HCONVLIST=HANDLE;
type HCONV=HANDLE;
type HSZ=HANDLE;
type HDDEDATA=HANDLE;

type pHWND=pointer to HWND;

const MINCHAR=0X00000080;
const MAXCHAR=0X0000007F;
const MINSHORT=0X00008000;
const MAXSHORT=0X00007FFF;
const MINLONG=0X80000000;
const MAXLONG=0X7FFFFFFF;
const MAXBYTE=0X000000FF;
const MAXWORD=0X0000FFFF;

//��������� � ��������� ������ ������ Kernel32

const MAX_PATH=256;

const STATUS_WAIT_0=0X00000000;
const STATUS_ABANDONED_WAIT_0=0X00000080;
const STATUS_USER_APC=0X000000C0;
const STATUS_TIMEOUT=0X00000102;
const STATUS_PENDING=0X00000103;
const STATUS_SEGMENT_NOTIFICATION=0X40000005;
const STATUS_GUARD_PAGE_VIOLATION=0X80000001;
const STATUS_DATATYPE_MISALIGNMENT=0X80000002;
const STATUS_BREAKPOINT=0X80000003;
const STATUS_SINGLE_STEP=0X80000004;
const STATUS_ACCESS_VIOLATION=0XC0000005;
const STATUS_IN_PAGE_ERROR=0XC0000006;
const STATUS_INVALID_HANDLE=0XC0000008;
const STATUS_NO_MEMORY=0XC0000017;
const STATUS_ILLEGAL_INSTRUCTION=0XC000001D;
const STATUS_NONCONTINUABLE_EXCEPTION=0XC0000025;
const STATUS_INVALID_DISPOSITION=0XC0000026;
const STATUS_ARRAY_BOUNDS_EXCEEDED=0XC000008C;
const STATUS_FLOAT_DENORMAL_OPERAND=0XC000008D;
const STATUS_FLOAT_DIVIDE_BY_ZERO=0XC000008E;
const STATUS_FLOAT_INEXACT_RESULT=0XC000008F;
const STATUS_FLOAT_INVALID_OPERATION=0XC0000090;
const STATUS_FLOAT_OVERFLOW=0XC0000091;
const STATUS_FLOAT_STACK_CHECK=0XC0000092;
const STATUS_FLOAT_UNDERFLOW=0XC0000093;
const STATUS_INTEGER_DIVIDE_BY_ZERO=0XC0000094;
const STATUS_INTEGER_OVERFLOW=0XC0000095;
const STATUS_PRIVILEGED_INSTRUCTION=0XC0000096;
const STATUS_STACK_OVERFLOW=0XC00000FD;
const STATUS_CONTROL_C_EXIT=0xC000013A;

type LIST_ENTRY=record
       Flink:address;
       Blink:address;
     end;

type CRITICAL_SECTION_DEBUG=record
       Type:word;
       CreatorBackTraceIndex:word;
       CriticalSection:address;
       ProcessLocksList:LIST_ENTRY;
       EntryCount:cardinal;
       ContentionCount:cardinal;
       Spare:LARGE_INTEGER;
     end;
     pCRITICAL_SECTION_DEBUG=pointer to CRITICAL_SECTION_DEBUG;

const RTL_CRITSECT_TYPE=0X00000000;
const RTL_RESOURCE_TYPE=0X00000001;
type CRITICAL_SECTION=record
       DebugInfo:CRITICAL_SECTION_DEBUG;
       LockCount:cardinal;
       RecursionCount:cardinal;
       OwningThread:HANDLE;
       LockSemaphore:HANDLE;
       Reserved:cardinal;
     end;
     pCRITICAL_SECTION=pointer to CRITICAL_SECTION;

const DLL_PROCESS_ATTACH=0X00000001;
const DLL_THREAD_ATTACH=0X00000002;
const DLL_THREAD_DETACH=0X00000003;
const DLL_PROCESS_DETACH=0X00000000;

const DELETE=0X00010000;
const READ_CONTROL=0X00020000;
const WRITE_DAC=0X00040000;
const WRITE_OWNER=0X00080000;
const SYNCHRONIZE=0X00100000;
const STANDARD_RIGHTS_REQUIRED=0X000F0000;
const STANDARD_RIGHTS_READ=READ_CONTROL;
const STANDARD_RIGHTS_WRITE=READ_CONTROL;
const STANDARD_RIGHTS_EXECUTE=READ_CONTROL;
const STANDARD_RIGHTS_ALL=0X001F0000;
const SPECIFIC_RIGHTS_ALL=0X0000FFFF;
const ACCESS_SYSTEM_SECURITY=0X01000000;
const MAXIMUM_ALLOWED=0X02000000;
const GENERIC_READ=0X80000000;
const GENERIC_WRITE=0X40000000;
const GENERIC_EXECUTE=0X20000000;
const GENERIC_ALL=0X10000000;

const EVENT_MODIFY_STATE=0X00000002;
const mas3=0X00000003;
const EVENT_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|mas3;
const MUTANT_QUERY_STATE=0X00000001;
const MUTANT_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|MUTANT_QUERY_STATE;
const SEMAPHORE_MODIFY_STATE=0X00000002;
const SEMAPHORE_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|mas3;
const TIME_ZONE_ID_UNKNOWN=0X00000000;
const TIME_ZONE_ID_STANDARD=0X00000001;
const TIME_ZONE_ID_DAYLIGHT=0X00000002;
const PROCESSOR_INTEL_386=0X00000182;
const PROCESSOR_INTEL_486=0X000001E6;
const PROCESSOR_INTEL_PENTIUM=0X0000024A;
const PROCESSOR_MIPS_R4000=0X00000FA0;
const PROCESSOR_ALPHA_21064=0X00005248;
const PROCESSOR_ARCHITECTURE_INTEL=0X00000000;
const PROCESSOR_ARCHITECTURE_MIPS=0X00000001;
const PROCESSOR_ARCHITECTURE_ALPHA=0X00000002;
const PROCESSOR_ARCHITECTURE_PPC=0X00000003;
const PROCESSOR_ARCHITECTURE_UNKNOWN=0X0000FFFF;
const PF_FLOATING_POINT_PRECISION_ERRATA=0X00000000;
const PF_FLOATING_POINT_EMULATED=0X00000001;
const PF_COMPARE_EXCHANGE_DOUBLE=0X00000002;
const PF_MMX_INSTRUCTIONS_AVAILABLE=0X00000003;
type MEMORY_BASIC_INFORMATION=record
       BaseAddress:address;
       AllocationBase:address;
       AllocationProtect:cardinal;
       RegionSize:cardinal;
       State:cardinal;
       Protect:cardinal;
       Typ:cardinal;
     end;
     pMEMORY_BASIC_INFORMATION=pointer to MEMORY_BASIC_INFORMATION;

const SECTION_QUERY=0X00000001;
const SECTION_MAP_WRITE=0X00000002;
const SECTION_MAP_READ=0X00000004;
const SECTION_MAP_EXECUTE=0X00000008;
const SECTION_EXTEND_SIZE=0X00000010;
const SECTION_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SECTION_QUERY|SECTION_MAP_WRITE|SECTION_MAP_READ|SECTION_MAP_EXECUTE|SECTION_EXTEND_SIZE;
const PAGE_NOACCESS=0X00000001;
const PAGE_READONLY=0X00000002;
const PAGE_READWRITE=0X00000004;
const PAGE_WRITECOPY=0X00000008;
const PAGE_EXECUTE=0X00000010;
const PAGE_EXECUTE_READ=0X00000020;
const PAGE_EXECUTE_READWRITE=0X00000040;
const PAGE_EXECUTE_WRITECOPY=0X00000080;
const PAGE_GUARD=0X00000100;
const PAGE_NOCACHE=0X00000200;
const MEM_COMMIT=0X00001000;
const MEM_RESERVE=0X00002000;
const MEM_DECOMMIT=0X00004000;
const MEM_RELEASE=0X00008000;
const MEM_FREE=0X00010000;
const MEM_PRIVATE=0X00020000;
const MEM_MAPPED=0X00040000;
const MEM_RESET=0X00080000;
const MEM_TOP_DOWN=0X00100000;
const SEC_FILE=0X00800000;
const SEC_IMAGE=0X01000000;
const SEC_RESERVE=0X04000000;
const SEC_COMMIT=0X08000000;
const SEC_NOCACHE=0X10000000;

const PROCESS_TERMINATE=0X00000001;
const PROCESS_CREATE_THREAD=0X00000002;
const PROCESS_VM_OPERATION=0X00000008;
const PROCESS_VM_READ=0X00000010;
const PROCESS_VM_WRITE=0X00000020;
const PROCESS_DUP_HANDLE=0X00000040;
const PROCESS_CREATE_PROCESS=0X00000080;
const PROCESS_SET_QUOTA=0X00000100;
const PROCESS_SET_INFORMATION=0X00000200;
const PROCESS_QUERY_INFORMATION=0X00000400;
const PROCESS_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|0X00000FFF;
const MAXIMUM_PROCESSORS=0X00000020;
const THREAD_TERMINATE=0X00000001;
const THREAD_SUSPEND_RESUME=0X00000002;
const THREAD_GET_CONTEXT=0X00000008;
const THREAD_SET_CONTEXT=0X00000010;
const THREAD_SET_INFORMATION=0X00000020;
const THREAD_QUERY_INFORMATION=0X00000040;
const THREAD_SET_THREAD_TOKEN=0X00000080;
const THREAD_IMPERSONATE=0X00000100;
const THREAD_DIRECT_IMPERSONATION=0X00000200;
const THREAD_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|0X000003FF;
const TLS_MINIMUM_AVAILABLE=0X00000040;
type NT_TIB=record
       ExceptionList:address;
       StackBase:address;
       StackLimit:address;
       SubSystemTib:address;
       Version:cardinal;
       ArbitraryUserPointer:address;
       Self:address;
     end;
     pNT_TIB=pointer to NT_TIB;

const THREAD_BASE_PRIORITY_LOWRT=0X0000000F;
const THREAD_BASE_PRIORITY_MAX=0X00000002;
const THREAD_BASE_PRIORITY_MIN=-0X00000002;
const THREAD_BASE_PRIORITY_IDLE=-0X0000000F;
type QUOTA_LIMITS=record
       PagedPoolLimit:cardinal;
       NonPagedPoolLimit:cardinal;
       MinimumWorkingSetSize:cardinal;
       MaximumWorkingSetSize:cardinal;
       PagefileLimit:cardinal;
       TimeLimit:LARGE_INTEGER;
     end;
     pQUOTA_LIMITS=pointer to QUOTA_LIMITS;

const EXCEPTION_NONCONTINUABLE=0x1;
const EXCEPTION_MAXIMUM_PARAMETERS=15;

type EXCEPTION_RECORD=record
       ExceptionCode:cardinal;
       ExceptionFlags:cardinal;
       ExceptionRecord:address;
       ExceptionAddress:address;
       NumberParameters:cardinal;
       ExceptionInformation:array[0..EXCEPTION_MAXIMUM_PARAMETERS-1]of cardinal;
     end;
     pEXCEPTION_RECORD=pointer to EXCEPTION_RECORD;

const FILE_READ_DATA=0X00000001;
const FILE_LIST_DIRECTORY=0X00000001;
const FILE_WRITE_DATA=0X00000002;
const FILE_ADD_FILE=0X00000002;
const FILE_APPEND_DATA=0X00000004;
const FILE_ADD_SUBDIRECTORY=0X00000004;
const FILE_CREATE_PIPE_INSTANCE=0X00000004;
const FILE_READ_EA=0X00000008;
const FILE_WRITE_EA=0X00000010;
const FILE_EXECUTE=0X00000020;
const FILE_TRAVERSE=0X00000020;
const FILE_DELETE_CHILD=0X00000040;
const FILE_READ_ATTRIBUTES=0X00000080;
const FILE_WRITE_ATTRIBUTES=0X00000100;
const FILE_ALL_ACCESS=STANDARD_RIGHTS_REQUIRED|SYNCHRONIZE|0X000001FF;
const FILE_GENERIC_READ=STANDARD_RIGHTS_READ|FILE_READ_DATA|FILE_READ_ATTRIBUTES|FILE_READ_EA|SYNCHRONIZE;
const FILE_GENERIC_WRITE=STANDARD_RIGHTS_WRITE|FILE_WRITE_DATA|FILE_WRITE_ATTRIBUTES|FILE_WRITE_EA|FILE_APPEND_DATA|SYNCHRONIZE;
const FILE_GENERIC_EXECUTE=STANDARD_RIGHTS_EXECUTE|FILE_READ_ATTRIBUTES|FILE_EXECUTE|SYNCHRONIZE;
const FILE_SHARE_READ=0X00000001;
const FILE_SHARE_WRITE=0X00000002;
const FILE_SHARE_DELETE=0X00000004;
const FILE_ATTRIBUTE_READONLY=0X00000001;
const FILE_ATTRIBUTE_HIDDEN=0X00000002;
const FILE_ATTRIBUTE_SYSTEM=0X00000004;
const FILE_ATTRIBUTE_DIRECTORY=0X00000010;
const FILE_ATTRIBUTE_ARCHIVE=0X00000020;
const FILE_ATTRIBUTE_NORMAL=0X00000080;
const FILE_ATTRIBUTE_TEMPORARY=0X00000100;
const FILE_ATTRIBUTE_COMPRESSED=0X00000800;
const FILE_ATTRIBUTE_OFFLINE=0X00001000;
const FILE_NOTIFY_CHANGE_FILE_NAME=0X00000001;
const FILE_NOTIFY_CHANGE_DIR_NAME=0X00000002;
const FILE_NOTIFY_CHANGE_ATTRIBUTES=0X00000004;
const FILE_NOTIFY_CHANGE_SIZE=0X00000008;
const FILE_NOTIFY_CHANGE_LAST_WRITE=0X00000010;
const FILE_NOTIFY_CHANGE_LAST_ACCESS=0X00000020;
const FILE_NOTIFY_CHANGE_CREATION=0X00000040;
const FILE_NOTIFY_CHANGE_SECURITY=0X00000100;
const FILE_ACTION_ADDED=0X00000001;
const FILE_ACTION_REMOVED=0X00000002;
const FILE_ACTION_MODIFIED=0X00000003;
const FILE_ACTION_RENAMED_OLD_NAME=0X00000004;
const FILE_ACTION_RENAMED_NEW_NAME=0X00000005;
const MAILSLOT_NO_MESSAGE=-0X00000001;
const MAILSLOT_WAIT_FOREVER=-0X00000001;
const FILE_CASE_SENSITIVE_SEARCH=0X00000001;
const FILE_CASE_PRESERVED_NAMES=0X00000002;
const FILE_UNICODE_ON_DISK=0X00000004;
const FILE_PERSISTENT_ACLS=0X00000008;
const FILE_FILE_COMPRESSION=0X00000010;
const FILE_VOLUME_IS_COMPRESSED=0x00008000;

const CONTEXT_PORTABLE_32BIT=0X00100000;
const CONTEXT_ALPHA=0X00020000;
const CONTEXT_CONTROL       =CONTEXT_ALPHA|0x00000001L;
const CONTEXT_FLOATING_POINT=CONTEXT_ALPHA|0x00000002L;
const CONTEXT_INTEGER       =CONTEXT_ALPHA|0x00000004L;
const CONTEXT_FULL=CONTEXT_CONTROL|CONTEXT_FLOATING_POINT|CONTEXT_INTEGER;
type CONTEXT=record
       FltF0:cardinal;
       FltF1:cardinal;
       FltF2:cardinal;
       FltF3:cardinal;
       FltF4:cardinal;
       FltF5:cardinal;
       FltF6:cardinal;
       FltF7:cardinal;
       FltF8:cardinal;
       FltF9:cardinal;
       FltF10:cardinal;
       FltF11:cardinal;
       FltF12:cardinal;
       FltF13:cardinal;
       FltF14:cardinal;
       FltF15:cardinal;
       FltF16:cardinal;
       FltF17:cardinal;
       FltF18:cardinal;
       FltF19:cardinal;
       FltF20:cardinal;
       FltF21:cardinal;
       FltF22:cardinal;
       FltF23:cardinal;
       FltF24:cardinal;
       FltF25:cardinal;
       FltF26:cardinal;
       FltF27:cardinal;
       FltF28:cardinal;
       FltF29:cardinal;
       FltF30:cardinal;
       FltF31:cardinal;
       IntV0:cardinal;
       IntT0:cardinal;
       IntT1:cardinal;
       IntT2:cardinal;
       IntT3:cardinal;
       IntT4:cardinal;
       IntT5:cardinal;
       IntT6:cardinal;
       IntT7:cardinal;
       IntS0:cardinal;
       IntS1:cardinal;
       IntS2:cardinal;
       IntS3:cardinal;
       IntS4:cardinal;
       IntS5:cardinal;
       IntFp:cardinal;
       IntA0:cardinal;
       IntA1:cardinal;
       IntA2:cardinal;
       IntA3:cardinal;
       IntA4:cardinal;
       IntA5:cardinal;
       IntT8:cardinal;
       IntT9:cardinal;
       IntT10:cardinal;
       IntT11:cardinal;
       IntRa:cardinal;
       IntT12:cardinal;
       IntAt:cardinal;
       IntGp:cardinal;
       IntSp:cardinal;
       IntZero:cardinal;
       Fpcr:cardinal;
       SoftFpcr:cardinal;
       Fir:cardinal;
       Psr:cardinal;
       ContextFlags:cardinal;
       HighFltF0:cardinal;
       HighFltF1:cardinal;
       HighFltF2:cardinal;
       HighFltF3:cardinal;
       HighFltF4:cardinal;
       HighFltF5:cardinal;
       HighFltF6:cardinal;
       HighFltF7:cardinal;
       HighFltF8:cardinal;
       HighFltF9:cardinal;
       HighFltF10:cardinal;
       HighFltF11:cardinal;
       HighFltF12:cardinal;
       HighFltF13:cardinal;
       HighFltF14:cardinal;
       HighFltF15:cardinal;
       HighFltF16:cardinal;
       HighFltF17:cardinal;
       HighFltF18:cardinal;
       HighFltF19:cardinal;
       HighFltF20:cardinal;
       HighFltF21:cardinal;
       HighFltF22:cardinal;
       HighFltF23:cardinal;
       HighFltF24:cardinal;
       HighFltF25:cardinal;
       HighFltF26:cardinal;
       HighFltF27:cardinal;
       HighFltF28:cardinal;
       HighFltF29:cardinal;
       HighFltF30:cardinal;
       HighFltF31:cardinal;
       HighIntV0:cardinal;
       HighIntT0:cardinal;
       HighIntT1:cardinal;
       HighIntT2:cardinal;
       HighIntT3:cardinal;
       HighIntT4:cardinal;
       HighIntT5:cardinal;
       HighIntT6:cardinal;
       HighIntT7:cardinal;
       HighIntS0:cardinal;
       HighIntS1:cardinal;
       HighIntS2:cardinal;
       HighIntS3:cardinal;
       HighIntS4:cardinal;
       HighIntS5:cardinal;
       HighIntFp:cardinal;
       HighIntA0:cardinal;
       HighIntA1:cardinal;
       HighIntA2:cardinal;
       HighIntA3:cardinal;
       HighIntA4:cardinal;
       HighIntA5:cardinal;
       HighIntT8:cardinal;
       HighIntT9:cardinal;
       HighIntT10:cardinal;
       HighIntT11:cardinal;
       HighIntRa:cardinal;
       HighIntT12:cardinal;
       HighIntAt:cardinal;
       HighIntGp:cardinal;
       HighIntSp:cardinal;
       HighIntZero:cardinal;
       HighFpcr:cardinal;
       HighSoftFpcr:cardinal;
       HighFir:cardinal;
       DoNotUseThisField:array[0..1]of cardinal;
       HighFill:array[0..1]of cardinal;
     end;
     pCONTEXT=pointer to CONTEXT;

const ANYSIZE_ARRAY=1;

type SECURITY_ATTRIBUTES=record
       nLength:cardinal;
       lpSecurityDescriptor:address;
       bInheritHandle:boolean;
     end;
     pSECURITY_ATTRIBUTES=pointer to SECURITY_ATTRIBUTES;

type SECURITY_INFORMATION=cardinal;
     pSECURITY_INFORMATION=pointer to SECURITY_INFORMATION;

//��������� � ��������� ������ ������ User32

type POINT=record
       x:integer;
       y:integer;
     end;
     pPOINT=pointer to POINT;

type RECT=record
       left:integer;
       top:integer;
       right:integer;
       bottom:integer;
     end;
     pRECT=pointer to RECT;

const CCHDEVICENAME=0X00000020;
const CCHFORMNAME=0X00000020;
type DEVMODE=record
       dmDeviceName:array[0..CCHDEVICENAME-1]of byte;
       dmSpecVersion:word;
       dmDriverVersion:word;
       dmSize:word;
       dmDriverExtra:word;
       dmFields:cardinal;
       dmOrientation:word;
       dmPaperSize:word;
       dmPaperLength:word;
       dmPaperWidth:word;
       dmScale:word;
       dmCopies:word;
       dmDefaultSource:word;
       dmPrintQuality:word;
       dmColor:word;
       dmDuplex:word;
       dmYResolution:word;
       dmTTOption:word;
       dmCollate:word;
       dmFormName:array[0..CCHFORMNAME-1]of byte;
       dmLogPixels:word;
       dmBitsPerPel:cardinal;
       dmPelsWidth:cardinal;
       dmPelsHeight:cardinal;
       dmDisplayFlags:cardinal;
       dmDisplayFrequency:cardinal;
       dmICMMethod:cardinal;
       dmICMIntent:cardinal;
       dmMediaType:cardinal;
       dmDitherType:cardinal;
       dmICCManufacturer:cardinal;
       dmICCModel:cardinal;
       dmPanningWidth:cardinal;
       dmPanningHeight:cardinal;
     end;
     pDEVMODE=pointer to DEVMODE;

type SID=record
       Revision:byte;
       SubAuthorityCount:byte;
       IdentifierAuthority:array[0..5]of byte;
       SubAuthority:array[0..ANYSIZE_ARRAY-1]of cardinal;
     end;
     pSID=pointer to SID;

type ACL=record
       AclRevision:byte;
       Sbz1:byte;
       AclSize:word;
       AceCount:word;
       Sbz2:word;
     end;
     pACL=pointer to ACL;

type SECURITY_DESCRIPTOR=record
       Revision:byte;
       Sbz1:byte;
       Control:word;
       Owner:pSID;
       Group:pSID;
       Sacl:pACL;
       Dacl:pACL;
     end;
     pSECURITY_DESCRIPTOR=pointer to SECURITY_DESCRIPTOR;

//��������� � ��������� ������ ������ Gdi32

type SIZE=record
       x:integer;
       y:integer;
     end;
     pSIZE=pointer to SIZE;

type POINTS=record
       x:integer;
       y:integer;
     end;
     pPOINTS=pointer to POINTS;

const LF_FACESIZE=0X00000020;
type LOGFONT=record
       lfHeight:integer;
       lfWidth:integer;
       lfEscapement:integer;
       lfOrientation:integer;
       lfWeight:integer;
       lfItalic:byte;
       lfUnderline:byte;
       lfStrikeOut:byte;
       lfCharSet:byte;
       lfOutPrecision:byte;
       lfClipPrecision:byte;
       lfQuality:byte;
       lfPitchAndFamily:byte;
       lfFaceName:array[0..LF_FACESIZE-1]of char;
     end;
     pLOGFONT=pointer to LOGFONT;

const LF_FULLFACESIZE=0X00000040;

//========================================================================
//                          ���� � ������� ������ Kernel32
//========================================================================

from Kernel32;

const INVALID_HANDLE_VALUE=-0x00000001;
const INVALID_FILE_SIZE=0xFFFFFFFF;
const FILE_BEGIN=0;
const FILE_CURRENT=0x00000001;
const FILE_END=0x00000002;
const TIME_ZONE_ID_INVALID=0xFFFFFFFF;
const WAIT_FAILED=0xFFFFFFFF;
const WAIT_OBJECT_0=STATUS_WAIT_0;
const WAIT_ABANDONED=STATUS_ABANDONED_WAIT_0;
const WAIT_ABANDONED_0=STATUS_ABANDONED_WAIT_0;
const WAIT_TIMEOUT=STATUS_TIMEOUT;
const WAIT_IO_COMPLETION=STATUS_USER_APC;
const STILL_ACTIVE=STATUS_PENDING;
const EXCEPTION_ACCESS_VIOLATION=STATUS_ACCESS_VIOLATION;
const EXCEPTION_DATATYPE_MISALIGNMENT=STATUS_DATATYPE_MISALIGNMENT;
const EXCEPTION_BREAKPOINT=STATUS_BREAKPOINT;
const EXCEPTION_SINGLE_STEP=STATUS_SINGLE_STEP;
const EXCEPTION_ARRAY_BOUNDS_EXCEEDED=STATUS_ARRAY_BOUNDS_EXCEEDED;
const EXCEPTION_FLT_DENORMAL_OPERAND=STATUS_FLOAT_DENORMAL_OPERAND;
const EXCEPTION_FLT_DIVIDE_BY_ZERO=STATUS_FLOAT_DIVIDE_BY_ZERO;
const EXCEPTION_FLT_INEXACT_RESULT=STATUS_FLOAT_INEXACT_RESULT;
const EXCEPTION_FLT_INVALID_OPERATION=STATUS_FLOAT_INVALID_OPERATION;
const EXCEPTION_FLT_OVERFLOW=STATUS_FLOAT_OVERFLOW;
const EXCEPTION_FLT_STACK_CHECK=STATUS_FLOAT_STACK_CHECK;
const EXCEPTION_FLT_UNDERFLOW=STATUS_FLOAT_UNDERFLOW;
const EXCEPTION_INT_DIVIDE_BY_ZERO=STATUS_INTEGER_DIVIDE_BY_ZERO;
const EXCEPTION_INT_OVERFLOW=STATUS_INTEGER_OVERFLOW;
const EXCEPTION_PRIV_INSTRUCTION=STATUS_PRIVILEGED_INSTRUCTION;
const EXCEPTION_IN_PAGE_ERROR=STATUS_IN_PAGE_ERROR;
const EXCEPTION_ILLEGAL_INSTRUCTION=STATUS_ILLEGAL_INSTRUCTION;
const EXCEPTION_NONCONTINUABLE_EXCEPTION=STATUS_NONCONTINUABLE_EXCEPTION;
const EXCEPTION_STACK_OVERFLOW=STATUS_STACK_OVERFLOW;
const EXCEPTION_INVALID_DISPOSITION=STATUS_INVALID_DISPOSITION;
const EXCEPTION_GUARD_PAGE=STATUS_GUARD_PAGE_VIOLATION;
const EXCEPTION_INVALID_HANDLE=STATUS_INVALID_HANDLE;
const CONTROL_C_EXIT=STATUS_CONTROL_C_EXIT;
//const MoveMemory=RtlMoveMemory;
//const CopyMemory=RtlCopyMemory;
//const FillMemory=RtlFillMemory;
//const ZeroMemory=RtlZeroMemory;
const FILE_FLAG_WRITE_THROUGH=0x80000000;
const FILE_FLAG_OVERLAPPED=0x40000000;
const FILE_FLAG_NO_BUFFERING=0x20000000;
const FILE_FLAG_RANDOM_ACCESS=0x10000000;
const FILE_FLAG_SEQUENTIAL_SCAN=0x08000000;
const FILE_FLAG_DELETE_ON_CLOSE=0x04000000;
const FILE_FLAG_BACKUP_SEMANTICS=0x02000000;
const FILE_FLAG_POSIX_SEMANTICS=0x01000000;
const CREATE_NEW=0x00000001;
const CREATE_ALWAYS=0x00000002;
const OPEN_EXISTING=0x00000003;
const OPEN_ALWAYS=0x00000004;
const TRUNCATE_EXISTING=0x00000005;
const PROGRESS_CONTINUE=0;
const PROGRESS_CANCEL=0x00000001;
const PROGRESS_STOP=0x00000002;
const PROGRESS_QUIET=0x00000003;
const CALLBACK_CHUNK_FINISHED=0x00000000;
const CALLBACK_STREAM_SWITCH=0x00000001;
const COPY_FILE_FAIL_IF_EXISTS=0x00000001;
const COPY_FILE_RESTARTABLE=0x00000002;
const PIPE_ACCESS_INBOUND=0x00000001;
const PIPE_ACCESS_OUTBOUND=0x00000002;
const PIPE_ACCESS_DUPLEX=0x00000003;
const PIPE_CLIENT_END=0x00000000;
const PIPE_SERVER_END=0x00000001;
const PIPE_WAIT=0x00000000;
const PIPE_NOWAIT=0x00000001;
const PIPE_READMODE_BYTE=0x00000000;
const PIPE_READMODE_MESSAGE=0x00000002;
const PIPE_TYPE_BYTE=0x00000000;
const PIPE_TYPE_MESSAGE=0x00000004;
const PIPE_UNLIMITED_INSTANCES=0x000000FF;
const SECURITY_ANONYMOUS=0x00000000;
const SECURITY_IDENTIFICATION=0x00010000;
const SECURITY_IMPERSONATION=0x00020000;
const SECURITY_DELEGATION=0x00030000;
const SECURITY_CONTEXT_TRACKING=0x00040000;
const SECURITY_EFFECTIVE_ONLY=0x00080000;
const SECURITY_SQOS_PRESENT=0x00100000;
const SECURITY_VALID_SQOS_FLAGS=0x001F0000;
type OVERLAPPED=record
       Internal:cardinal;
       InternalHigh:cardinal;
       Offset:cardinal;
       OffsetHigh:cardinal;
       hEvent:HANDLE;
     end;
     pOVERLAPPED=pointer to OVERLAPPED;

type PROCESS_INFORMATION=record
       hProcess:HANDLE;
       hThread:HANDLE;
       dwProcessId:cardinal;
       dwThreadId:cardinal;
     end;
     pPROCESS_INFORMATION=pointer to PROCESS_INFORMATION;

type FILETIME=record
       dwLowDateTime:cardinal;
       dwHighDateTime:cardinal;
     end;
     pFILETIME=pointer to FILETIME;

type SYSTEMTIME=record
       wYear:word;
       wMonth:word;
       wDayOfWeek:word;
       wDay:word;
       wHour:word;
       wMinute:word;
       wSecond:word;
       wMilliseconds:word;
     end;
     pSYSTEMTIME=pointer to SYSTEMTIME;

const MUTEX_MODIFY_STATE=MUTANT_QUERY_STATE;
const MUTEX_ALL_ACCESS=MUTANT_ALL_ACCESS;
const SP_SERIALCOMM=0x00000001;
const PST_UNSPECIFIED=0x00000000;
const PST_RS232=0x00000001;
const PST_PARALLELPORT=0x00000002;
const PST_RS422=0x00000003;
const PST_RS423=0x00000004;
const PST_RS449=0x00000005;
const PST_MODEM=0x00000006;
const PST_FAX=0x00000021;
const PST_SCANNER=0x00000022;
const PST_NETWORK_BRIDGE=0x00000100;
const PST_LAT=0x00000101;
const PST_TCPIP_TELNET=0x00000102;
const PST_X25=0x00000103;
const PCF_DTRDSR=0x00000001;
const PCF_RTSCTS=0x00000002;
const PCF_RLSD=0x00000004;
const PCF_PARITY_CHECK=0x00000008;
const PCF_XONXOFF=0x00000010;
const PCF_SETXCHAR=0x00000020;
const PCF_TOTALTIMEOUTS=0x00000040;
const PCF_INTTIMEOUTS=0x00000080;
const PCF_SPECIALCHARS=0x00000100;
const PCF_16BITMODE=0x00000200;
const SP_PARITY=0x00000001;
const SP_BAUD=0x00000002;
const SP_DATABITS=0x00000004;
const SP_STOPBITS=0x00000008;
const SP_HANDSHAKING=0x00000010;
const SP_PARITY_CHECK=0x00000020;
const SP_RLSD=0x00000040;
const BAUD_075=0x00000001;
const BAUD_110=0x00000002;
const BAUD_134_5=0x00000004;
const BAUD_150=0x00000008;
const BAUD_300=0x00000010;
const BAUD_600=0x00000020;
const BAUD_1200=0x00000040;
const BAUD_1800=0x00000080;
const BAUD_2400=0x00000100;
const BAUD_4800=0x00000200;
const BAUD_7200=0x00000400;
const BAUD_9600=0x00000800;
const BAUD_14400=0x00001000;
const BAUD_19200=0x00002000;
const BAUD_38400=0x00004000;
const BAUD_56K=0x00008000;
const BAUD_128K=0x00010000;
const BAUD_115200=0x00020000;
const BAUD_57600=0x00040000;
const BAUD_USER=0x10000000;
const DATABITS_5=0x00000001;
const DATABITS_6=0x00000002;
const DATABITS_7=0x00000004;
const DATABITS_8=0x00000008;
const DATABITS_16=0x00000010;
const DATABITS_16X=0x00000020;
const STOPBITS_10=0x00000001;
const STOPBITS_15=0x00000002;
const STOPBITS_20=0x00000004;
const PARITY_NONE=0x00000100;
const PARITY_ODD=0x00000200;
const PARITY_EVEN=0x00000400;
const PARITY_MARK=0x00000800;
const PARITY_SPACE=0x00001000;
type COMMPROP=record
       wPacketLength:word;
       wPacketVersion:word;
       dwServiceMask:cardinal;
       dwReserved:cardinal;
       dwMaxTxQueue:cardinal;
       dwMaxRxQueue:cardinal;
       dwMaxBaud:cardinal;
       dwProvSubType:cardinal;
       dwProvCapabilities:cardinal;
       dwSettableParams:cardinal;
       dwSettableBaud:cardinal;
       wSettableData:word;
       wSettableStopParity:word;
       dwCurrentTxQueue:cardinal;
       dwCurrentRxQueue:cardinal;
       dwProvSpec1:cardinal;
       dwProvSpec2:cardinal;
       wcProvChar:array[0..0]of word;
     end;
     pCOMMPROP=pointer to COMMPROP;

const COMMPROP_INITIALIZED=0xE73CF52E;
type COMSTAT=record
       fCtsHold:cardinal;
       fDsrHold:cardinal;
       fRlsdHold:cardinal;
       fXoffHold:cardinal;
       fXoffSent:cardinal;
       fEof:cardinal;
       fTxim:cardinal;
       fReserved:cardinal;
       cbInQue:cardinal;
       cbOutQue:cardinal;
     end;
     pCOMSTAT=pointer to COMSTAT;

const DTR_CONTROL_DISABLE=0x00000000;
const DTR_CONTROL_ENABLE=0x00000001;
const DTR_CONTROL_HANDSHAKE=0x00000002;
const RTS_CONTROL_DISABLE=0x00000000;
const RTS_CONTROL_ENABLE=0x00000001;
const RTS_CONTROL_HANDSHAKE=0x00000002;
const RTS_CONTROL_TOGGLE=0x00000003;
type DCB=record
       DCBlength:cardinal;
       BaudRate:cardinal;
       fBinary:cardinal;
       fParity:cardinal;
       fOutxCtsFlow:cardinal;
       fOutxDsrFlow:cardinal;
       fDtrControl:cardinal;
       fDsrSensitivity:cardinal;
       fTXContinueOnXoff:cardinal;
       fOutX:cardinal;
       fInX:cardinal;
       fErrorChar:cardinal;
       fNull:cardinal;
       fRtsControl:cardinal;
       fAbortOnError:cardinal;
       fDummy:cardinal;
       wReserved:word;
       XonLim:word;
       XoffLim:word;
       ByteSize:byte;
       Parity:byte;
       StopBits:byte;
       XonChar:char;
       XoffChar:char;
       ErrorChar:char;
       EofChar:char;
       EvtChar:char;
       wReserved2:word;
     end;
     pDCB=pointer to DCB;

type COMMTIMEOUTS=record
       ReadIntervalTimeout:cardinal;
       ReadTotalTimeoutMultiplier:cardinal;
       ReadTotalTimeoutConstant:cardinal;
       WriteTotalTimeoutMultiplier:cardinal;
       WriteTotalTimeoutConstant:cardinal;
     end;
     pCOMMTIMEOUTS=pointer to COMMTIMEOUTS;

type COMMCONFIG=record
       dwSize:cardinal;
       wVersion:word;
       wReserved:word;
       dcb:DCB;
       dwProviderSubType:cardinal;
       dwProviderOffset:cardinal;
       dwProviderSize:cardinal;
       wcProviderData:array[0..0]of word;
     end;
     pCOMMCONFIG=pointer to COMMCONFIG;

type SYSTEM_INFO=record
       dwOemId:cardinal;
       dwPageSize:cardinal;
       lpMinimumApplicationAddress:address;
       lpMaximumApplicationAddress:address;
       dwActiveProcessorMask:cardinal;
       dwNumberOfProcessors:cardinal;
       dwProcessorType:cardinal;
       dwAllocationGranularity:cardinal;
       wProcessorLevel:word;
       wProcessorRevision:word;
     end;
     pSYSTEM_INFO=pointer to SYSTEM_INFO;

const GMEM_FIXED=0x00000000;
const GMEM_MOVEABLE=0x00000002;
const GMEM_NOCOMPACT=0x00000010;
const GMEM_NODISCARD=0x00000020;
const GMEM_ZEROINIT=0x00000040;
const GMEM_MODIFY=0x00000080;
const GMEM_DISCARDABLE=0x00000100;
const GMEM_NOT_BANKED=0x00001000;
const GMEM_SHARE=0x00002000;
const GMEM_DDESHARE=0x00002000;
const GMEM_NOTIFY=0x00004000;
const GMEM_LOWER=GMEM_NOT_BANKED;
const GMEM_VALID_FLAGS=0x00007F72;
const GMEM_INVALID_HANDLE=0x00008000;
const GHND=GMEM_MOVEABLE|GMEM_ZEROINIT;
const GPTR=GMEM_FIXED|GMEM_ZEROINIT;
const GMEM_DISCARDED=0x00004000;
const GMEM_LOCKCOUNT=0x000000FF;
type MEMORYSTATUS=record
       dwLength:cardinal;
       dwMemoryLoad:cardinal;
       dwTotalPhys:cardinal;
       dwAvailPhys:cardinal;
       dwTotalPageFile:cardinal;
       dwAvailPageFile:cardinal;
       dwTotalVirtual:cardinal;
       dwAvailVirtual:cardinal;
     end;
     pMEMORYSTATUS=pointer to MEMORYSTATUS;

const LMEM_FIXED=0x00000000;
const LMEM_MOVEABLE=0x00000002;
const LMEM_NOCOMPACT=0x00000010;
const LMEM_NODISCARD=0x00000020;
const LMEM_ZEROINIT=0x00000040;
const LMEM_MODIFY=0x00000080;
const LMEM_DISCARDABLE=0x00000F00;
const LMEM_VALID_FLAGS=0x00000F72;
const LMEM_INVALID_HANDLE=0x00008000;
const LHND=LMEM_MOVEABLE|LMEM_ZEROINIT;
const LPTR=LMEM_FIXED|LMEM_ZEROINIT;
const NONZEROLHND=LMEM_MOVEABLE;
const NONZEROLPTR=LMEM_FIXED;
const LMEM_DISCARDED=0x00004000;
const LMEM_LOCKCOUNT=0x000000FF;
const DEBUG_PROCESS=0x00000001;
const DEBUG_ONLY_THIS_PROCESS=0x00000002;
const CREATE_SUSPENDED=0x00000004;
const DETACHED_PROCESS=0x00000008;
const CREATE_NEW_CONSOLE=0x00000010;
const NORMAL_PRIORITY_CLASS=0x00000020;
const IDLE_PRIORITY_CLASS=0x00000040;
const HIGH_PRIORITY_CLASS=0x00000080;
const REALTIME_PRIORITY_CLASS=0x00000100;
const CREATE_NEW_PROCESS_GROUP=0x00000200;
const CREATE_UNICODE_ENVIRONMENT=0x00000400;
const CREATE_SEPARATE_WOW_VDM=0x00000800;
const CREATE_SHARED_WOW_VDM=0x00001000;
const CREATE_FORCEDOS=0x00002000;
const CREATE_DEFAULT_ERROR_MODE=0x04000000;
const CREATE_NO_WINDOW=0x08000000;
const PROFILE_USER=0x10000000;
const PROFILE_KERNEL=0x20000000;
const PROFILE_SERVER=0x40000000;
const THREAD_PRIORITY_LOWEST=THREAD_BASE_PRIORITY_MIN;
const THREAD_PRIORITY_BELOW_NORMAL=THREAD_PRIORITY_LOWEST+1;
const THREAD_PRIORITY_NORMAL=0;
const THREAD_PRIORITY_HIGHEST=THREAD_BASE_PRIORITY_MAX;
const THREAD_PRIORITY_ABOVE_NORMAL=THREAD_PRIORITY_HIGHEST-1;
const THREAD_PRIORITY_ERROR_RETURN=MAXLONG;
const THREAD_PRIORITY_TIME_CRITICAL=THREAD_BASE_PRIORITY_LOWRT;
const THREAD_PRIORITY_IDLE=THREAD_BASE_PRIORITY_IDLE;
const EXCEPTION_DEBUG_EVENT=0x00000001;
const CREATE_THREAD_DEBUG_EVENT=0x00000002;
const CREATE_PROCESS_DEBUG_EVENT=0x00000003;
const EXIT_THREAD_DEBUG_EVENT=0x00000004;
const EXIT_PROCESS_DEBUG_EVENT=0x00000005;
const LOAD_DLL_DEBUG_EVENT=0x00000006;
const UNLOAD_DLL_DEBUG_EVENT=0x00000007;
const OUTPUT_DEBUG_STRING_EVENT=0x00000008;
const RIP_EVENT=0x00000009;
type EXCEPTION_DEBUG_INFO=record
       ExceptionRecord:EXCEPTION_RECORD;
       dwFirstChance:cardinal;
     end;
     pEXCEPTION_DEBUG_INFO=pointer to EXCEPTION_DEBUG_INFO;

type CREATE_THREAD_DEBUG_INFO=record
       hThread:HANDLE;
       lpThreadLocalBase:address;
       lpStartAddress:address;
     end;
     pCREATE_THREAD_DEBUG_INFO=pointer to CREATE_THREAD_DEBUG_INFO;

type CREATE_PROCESS_DEBUG_INFO=record
       hFile:HANDLE;
       hProcess:HANDLE;
       hThread:HANDLE;
       lpBaseOfImage:address;
       dwDebugInfoFileOffset:cardinal;
       nDebugInfoSize:cardinal;
       lpThreadLocalBase:address;
       lpStartAddress:address;
       lpImageName:address;
       fUnicode:word;
     end;
     pCREATE_PROCESS_DEBUG_INFO=pointer to CREATE_PROCESS_DEBUG_INFO;

type EXIT_THREAD_DEBUG_INFO=record
       dwExitCode:cardinal;
     end;
     pEXIT_THREAD_DEBUG_INFO=pointer to EXIT_THREAD_DEBUG_INFO;

type EXIT_PROCESS_DEBUG_INFO=record
       dwExitCode:cardinal;
     end;
     pEXIT_PROCESS_DEBUG_INFO=pointer to EXIT_PROCESS_DEBUG_INFO;

type LOAD_DLL_DEBUG_INFO=record
       hFile:HANDLE;
       lpBaseOfDll:address;
       dwDebugInfoFileOffset:cardinal;
       nDebugInfoSize:cardinal;
       lpImageName:address;
       fUnicode:word;
     end;
     pLOAD_DLL_DEBUG_INFO=pointer to LOAD_DLL_DEBUG_INFO;

type UNLOAD_DLL_DEBUG_INFO=record
       lpBaseOfDll:address;
     end;
     pUNLOAD_DLL_DEBUG_INFO=pointer to UNLOAD_DLL_DEBUG_INFO;

type OUTPUT_DEBUG_STRING_INFO=record
       lpDebugStringData:pstr;
       fUnicode:word;
       nDebugStringLength:word;
     end;
     pOUTPUT_DEBUG_STRING_INFO=pointer to OUTPUT_DEBUG_STRING_INFO;

type RIP_INFO=record
       dwError:cardinal;
       dwType:cardinal;
     end;
     pRIP_INFO=pointer to RIP_INFO;

type DEBUG_EVENT=record
       dwDebugEventCode:cardinal;
       dwProcessId:cardinal;
       dwThreadId:cardinal;
       Exception:address;
     end;
     pDEBUG_EVENT=pointer to DEBUG_EVENT;

const DRIVE_UNKNOWN=0;
const DRIVE_NO_ROOT_DIR=0x00000001;
const DRIVE_REMOVABLE=0x00000002;
const DRIVE_FIXED=0x00000003;
const DRIVE_REMOTE=0x00000004;
const DRIVE_CDROM=0x00000005;
const DRIVE_RAMDISK=0x00000006;
const FILE_TYPE_UNKNOWN=0x00000000;
const FILE_TYPE_DISK=0x00000001;
const FILE_TYPE_CHAR=0x00000002;
const FILE_TYPE_PIPE=0x00000003;
const FILE_TYPE_REMOTE=0x00008000;
const STD_INPUT_HANDLE=-0x0000000A;
const STD_OUTPUT_HANDLE=-0x0000000B;
const STD_ERROR_HANDLE=-0x0000000C;
const NOPARITY=0;
const ODDPARITY=0x00000001;
const EVENPARITY=0x00000002;
const MARKPARITY=0x00000003;
const SPACEPARITY=0x00000004;
const ONESTOPBIT=0;
const ONE5STOPBITS=0x00000001;
const TWOSTOPBITS=0x00000002;
const IGNORE=0;
const INFINITE=0xFFFFFFFF;
const CBR_110=0x0000006E;
const CBR_300=0x0000012C;
const CBR_600=0x00000258;
const CBR_1200=0x000004B0;
const CBR_2400=0x00000960;
const CBR_4800=0x000012C0;
const CBR_9600=0x00002580;
const CBR_14400=0x00003840;
const CBR_19200=0x00004B00;
const CBR_38400=0x00009600;
const CBR_56000=0x0000DAC0;
const CBR_57600=0x0000E100;
const CBR_115200=0x0001C200;
const CBR_128000=0x0001F400;
const CBR_256000=0x0003E800;
const CE_RXOVER=0x00000001;
const CE_OVERRUN=0x00000002;
const CE_RXPARITY=0x00000004;
const CE_FRAME=0x00000008;
const CE_BREAK=0x00000010;
const CE_TXFULL=0x00000100;
const CE_PTO=0x00000200;
const CE_IOE=0x00000400;
const CE_DNS=0x00000800;
const CE_OOP=0x00001000;
const CE_MODE=0x00008000;
const IE_BADID=-0x00000001;
const IE_OPEN=-0x00000002;
const IE_NOPEN=-0x00000003;
const IE_MEMORY=-0x00000004;
const IE_DEFAULT=-0x00000005;
const IE_HARDWARE=-0x0000000A;
const IE_BYTESIZE=-0x0000000B;
const IE_BAUDRATE=-0x0000000C;
const EV_RXCHAR=0x00000001;
const EV_RXFLAG=0x00000002;
const EV_TXEMPTY=0x00000004;
const EV_CTS=0x00000008;
const EV_DSR=0x00000010;
const EV_RLSD=0x00000020;
const EV_BREAK=0x00000040;
const EV_ERR=0x00000080;
const EV_RING=0x00000100;
const EV_PERR=0x00000200;
const EV_RX80FULL=0x00000400;
const EV_EVENT1=0x00000800;
const EV_EVENT2=0x00001000;
const SETXOFF=0x00000001;
const SETXON=0x00000002;
const SETRTS=0x00000003;
const CLRRTS=0x00000004;
const SETDTR=0x00000005;
const CLRDTR=0x00000006;
const RESETDEV=0x00000007;
const SETBREAK=0x00000008;
const CLRBREAK=0x00000009;
const PURGE_TXABORT=0x00000001;
const PURGE_RXABORT=0x00000002;
const PURGE_TXCLEAR=0x00000004;
const PURGE_RXCLEAR=0x00000008;
const LPTx=0x00000080;
const MS_CTS_ON=0x00000010;
const MS_DSR_ON=0x00000020;
const MS_RING_ON=0x00000040;
const MS_RLSD_ON=0x00000080;
const S_QUEUEEMPTY=0;
const S_THRESHOLD=0x00000001;
const S_ALLTHRESHOLD=0x00000002;
const S_NORMAL=0;
const S_LEGATO=0x00000001;
const S_STACCATO=0x00000002;
const S_PERIOD512=0;
const S_PERIOD1024=0x00000001;
const S_PERIOD2048=0x00000002;
const S_PERIODVOICE=0x00000003;
const S_WHITE512=0x00000004;
const S_WHITE1024=0x00000005;
const S_WHITE2048=0x00000006;
const S_WHITEVOICE=0x00000007;
const S_SERDVNA=-0x00000001;
const S_SEROFM=-0x00000002;
const S_SERMACT=-0x00000003;
const S_SERQFUL=-0x00000004;
const S_SERBDNT=-0x00000005;
const S_SERDLN=-0x00000006;
const S_SERDCC=-0x00000007;
const S_SERDTP=-0x00000008;
const S_SERDVL=-0x00000009;
const S_SERDMD=-0x0000000A;
const S_SERDSH=-0x0000000B;
const S_SERDPT=-0x0000000C;
const S_SERDFQ=-0x0000000D;
const S_SERDDR=-0x0000000E;
const S_SERDSR=-0x0000000F;
const S_SERDST=-0x00000010;
const NMPWAIT_WAIT_FOREVER=0xFFFFFFFF;
const NMPWAIT_NOWAIT=0x00000001;
const NMPWAIT_USE_DEFAULT_WAIT=0x00000000;
const FS_CASE_IS_PRESERVED=FILE_CASE_PRESERVED_NAMES;
const FS_CASE_SENSITIVE=FILE_CASE_SENSITIVE_SEARCH;
const FS_UNICODE_STORED_ON_DISK=FILE_UNICODE_ON_DISK;
const FS_PERSISTENT_ACLS=FILE_PERSISTENT_ACLS;
const FS_VOL_IS_COMPRESSED=FILE_VOLUME_IS_COMPRESSED;
const FS_FILE_COMPRESSION=FILE_FILE_COMPRESSION;
const FILE_MAP_COPY=SECTION_QUERY;
const FILE_MAP_WRITE=SECTION_MAP_WRITE;
const FILE_MAP_READ=SECTION_MAP_READ;
const FILE_MAP_ALL_ACCESS=SECTION_ALL_ACCESS;
const OF_READ=0x00000000;
const OF_WRITE=0x00000001;
const OF_READWRITE=0x00000002;
const OF_SHARE_COMPAT=0x00000000;
const OF_SHARE_EXCLUSIVE=0x00000010;
const OF_SHARE_DENY_WRITE=0x00000020;
const OF_SHARE_DENY_READ=0x00000030;
const OF_SHARE_DENY_NONE=0x00000040;
const OF_PARSE=0x00000100;
const OF_DELETE=0x00000200;
const OF_VERIFY=0x00000400;
const OF_CANCEL=0x00000800;
const OF_CREATE=0x00001000;
const OF_PROMPT=0x00002000;
const OF_EXIST=0x00004000;
const OF_REOPEN=0x00008000;
const OFS_MAXPATHNAME=0x00000080;
type OFSTRUCT=record
       cBytes:byte;
       fFixedDisk:byte;
       nErrCode:word;
       Reserved1:word;
       Reserved2:word;
       szPathName:array[0..OFS_MAXPATHNAME-1]of char;
     end;
     pOFSTRUCT=pointer to OFSTRUCT;

procedure InterlockedIncrement(lpAddend:pCARDINAL):cardinal;
procedure InterlockedDecrement(lpAddend:pCARDINAL):cardinal;
procedure InterlockedExchange(Target:pCARDINAL; Value:cardinal):cardinal;
procedure FreeResource(hResData:HGLOBAL):boolean;
procedure LockResource(hResData:HGLOBAL):address;

const MAXINTATOM=0x0000C000;
const INVALID_ATOM=0;

procedure FreeLibrary(hLibModule:HMODULE):boolean;
procedure FreeLibraryAndExitThread(hLibModule:HMODULE; dwExitCode:cardinal);
procedure DisableThreadLibraryCalls(hLibModule:HMODULE):boolean;
procedure GetProcAddress(hModule:HMODULE; lpProcName:pstr):pPROC;
procedure GetVersion():cardinal;
procedure GlobalAlloc(uFlags:cardinal; dwBytes:cardinal):HGLOBAL;
procedure GlobalReAlloc(hMem:HGLOBAL; dwBytes:cardinal; uFlags:cardinal):HGLOBAL;
procedure GlobalSize(hMem:HGLOBAL):cardinal;
procedure GlobalFlags(hMem:HGLOBAL):cardinal;
procedure GlobalLock(hMem:HGLOBAL):address;
procedure GlobalHandle(pMem:address):HGLOBAL;
procedure GlobalUnlock(hMem:HGLOBAL):boolean;
procedure GlobalFree(hMem:HGLOBAL):HGLOBAL;
procedure GlobalCompact(dwMinFree:cardinal):cardinal;
procedure GlobalFix(hMem:HGLOBAL);
procedure GlobalUnfix(hMem:HGLOBAL);
procedure GlobalWire(hMem:HGLOBAL):address;
procedure GlobalUnWire(hMem:HGLOBAL):boolean;
procedure GlobalMemoryStatus(lpBuffer:pMEMORYSTATUS);
procedure LocalAlloc(uFlags:cardinal; uBytes:cardinal):HLOCAL;
procedure LocalReAlloc(hMem:HLOCAL; uBytes:cardinal; uFlags:cardinal):HLOCAL;
procedure LocalLock(hMem:HLOCAL):address;
procedure LocalHandle(pMem:address):HLOCAL;
procedure LocalUnlock(hMem:HLOCAL):boolean;
procedure LocalSize(hMem:HLOCAL):cardinal;
procedure LocalFlags(hMem:HLOCAL):cardinal;
procedure LocalFree(hMem:HLOCAL):HLOCAL;
procedure LocalShrink(hMem:HLOCAL; cbNewSize:cardinal):cardinal;
procedure LocalCompact(uMinFree:cardinal):cardinal;
procedure FlushInstructionCache(hProcess:HANDLE; lpBaseAddress:address; dwSize:cardinal):boolean;
procedure VirtualAlloc(lpAddress:address; dwSize:cardinal; flAllocationType:cardinal; flProtect:cardinal):address;
procedure VirtualFree(lpAddress:address; dwSize:cardinal; dwFreeType:cardinal):boolean;
procedure VirtualProtect(lpAddress:address; dwSize:cardinal; flNewProtect:cardinal; lpflOldProtect:pCARDINAL):boolean;
procedure VirtualQuery(lpAddress:address; lpBuffer:pMEMORY_BASIC_INFORMATION; dwLength:cardinal):cardinal;
procedure VirtualProtectEx(hProcess:HANDLE; lpAddress:address; dwSize:cardinal; flNewProtect:cardinal; lpflOldProtect:pCARDINAL):boolean;
procedure VirtualQueryEx(hProcess:HANDLE; lpAddress:address; lpBuffer:pMEMORY_BASIC_INFORMATION; dwLength:cardinal):cardinal;
procedure HeapCreate(flOptions:cardinal; dwInitialSize:cardinal; dwMaximumSize:cardinal):HANDLE;
procedure HeapDestroy(hHeap:HANDLE):boolean;
procedure HeapAlloc(hHeap:HANDLE; dwFlags:cardinal; dwBytes:cardinal):address;
procedure HeapReAlloc(hHeap:HANDLE; dwFlags:cardinal; lpMem:address; dwBytes:cardinal):address;
procedure HeapFree(hHeap:HANDLE; dwFlags:cardinal; lpMem:address):boolean;
procedure HeapSize(hHeap:HANDLE; dwFlags:cardinal; lpMem:address):cardinal;
procedure HeapValidate(hHeap:HANDLE; dwFlags:cardinal; lpMem:address):boolean;
procedure HeapCompact(hHeap:HANDLE; dwFlags:cardinal):cardinal;
procedure GetProcessHeap():HANDLE;
procedure GetProcessHeaps(NumberOfHeaps:cardinal; ProcessHeaps:pHANDLE):cardinal;
procedure RtlMoveMemory(dest,sou:address; len:cardinal);
//procedure RtlCopyMemory(dest,sou:address; len:cardinal);
procedure RtlFillMemory(dest:address; len:cardinal; fill:byte);
procedure RtlZeroMemory(dest:address; len:cardinal);

type PROCESS_HEAP_ENTRY=record
       lpData:address;
       cbData:cardinal;
       cbOverhead:byte;
       iRegionIndex:byte;
       wFlags:word;
       dwCommittedSize:cardinal;
       dwUnCommittedSize:cardinal;
       lpFirstBlock:address;
       lpLastBlock:address;
     end;
     pPROCESS_HEAP_ENTRY=pointer to PROCESS_HEAP_ENTRY;

const PROCESS_HEAP_REGION=0x00000001;
const PROCESS_HEAP_UNCOMMITTED_RANGE=0x00000002;
const PROCESS_HEAP_ENTRY_BUSY=0x00000004;
const PROCESS_HEAP_ENTRY_MOVEABLE=0x00000010;
const PROCESS_HEAP_ENTRY_DDESHARE=0x00000020;

procedure HeapLock(hHeap:HANDLE):boolean;
procedure HeapUnlock(hHeap:HANDLE):boolean;
procedure HeapWalk(hHeap:HANDLE; lpEntry:pPROCESS_HEAP_ENTRY):boolean;

const SCS_32BIT_BINARY=0;
const SCS_DOS_BINARY=0x00000001;
const SCS_WOW_BINARY=0x00000002;
const SCS_PIF_BINARY=0x00000003;
const SCS_POSIX_BINARY=0x00000004;
const SCS_OS216_BINARY=0x00000005;

procedure GetBinaryType ascii(lpApplicationName:pstr; lpBinaryType:pCARDINAL):boolean;
procedure GetShortPathName ascii(lpszLongPath:pstr; lpszShortPath:pstr; cchBuffer:cardinal):cardinal;
procedure GetProcessAffinityMask(hProcess:HANDLE; lpProcessAffinityMask:pCARDINAL; lpSystemAffinityMask:pCARDINAL):boolean;
procedure GetProcessTimes(hProcess:HANDLE; lpCreationTime:pFILETIME; lpExitTime:pFILETIME; lpKernelTime:pFILETIME; lpUserTime:pFILETIME):boolean;
procedure GetProcessWorkingSetSize(hProcess:HANDLE; lpMinimumWorkingSetSize:pCARDINAL; lpMaximumWorkingSetSize:pCARDINAL):boolean;
procedure SetProcessWorkingSetSize(hProcess:HANDLE; dwMinimumWorkingSetSize:cardinal; dwMaximumWorkingSetSize:cardinal):boolean;
procedure OpenProcess(dwDesiredAccess:cardinal; bInheritHandle:boolean; dwProcessId:cardinal):HANDLE;
procedure GetCurrentProcess():HANDLE;
procedure GetCurrentProcessId():cardinal;
procedure ExitProcess(uExitCode:cardinal);
procedure TerminateProcess(hProcess:HANDLE; uExitCode:cardinal):boolean;
procedure GetExitCodeProcess(hProcess:HANDLE; lpExitCode:pCARDINAL):boolean;
procedure FatalExit(ExitCode:integer);
procedure GetEnvironmentStrings ascii():pstr;
procedure FreeEnvironmentStrings ascii(pstr):boolean;
procedure RaiseException(dwExceptionCode:cardinal; dwExceptionFlags:cardinal; nNumberOfArguments:cardinal; lpArguments:pCARDINAL);
procedure UnhandledExceptionFilter(ExceptionInfo:address):cardinal;
procedure CreateThread(lpThreadAttributes:pSECURITY_ATTRIBUTES; dwStackSize:cardinal; lpStartAddress:pPROC; lpParameter:address; dwCreationFlags:cardinal; lpThreadId:pCARDINAL):HANDLE;
procedure CreateRemoteThread(hProcess:HANDLE; lpThreadAttributes:pSECURITY_ATTRIBUTES; dwStackSize:cardinal; lpStartAddress:pPROC; lpParameter:address; dwCreationFlags:cardinal; lpThreadId:pCARDINAL):HANDLE;
procedure GetCurrentThread():HANDLE;
procedure GetCurrentThreadId():cardinal;
procedure SetThreadAffinityMask(hThread:HANDLE; dwThreadAffinityMask:cardinal):cardinal;
procedure SetThreadPriority(hThread:HANDLE; nPriority:integer):boolean;
procedure GetThreadPriority(hThread:HANDLE):integer;
procedure GetThreadTimes(hThread:HANDLE; lpCreationTime:pFILETIME; lpExitTime:pFILETIME; lpKernelTime:pFILETIME; lpUserTime:pFILETIME):boolean;
procedure ExitThread(dwExitCode:cardinal);
procedure TerminateThread(hThread:HANDLE; dwExitCode:cardinal):boolean;
procedure GetExitCodeThread(hThread:HANDLE; lpExitCode:pCARDINAL):boolean;
procedure GetThreadSelectorEntry(hThread:HANDLE; dwSelector:cardinal; lpSelectorEntry:address):boolean;
procedure GetLastError():cardinal;
procedure SetLastError(dwErrCode:cardinal);
procedure GetOverlappedResult(hFile:HANDLE; lpOverlapped:pOVERLAPPED; lpNumberOfBytesTransferred:pCARDINAL; bWait:boolean):boolean;
procedure CreateIoCompletionPort(FileHandle:HANDLE; ExistingCompletionPort:HANDLE; CompletionKey:cardinal; NumberOfConcurrentThreads:cardinal):HANDLE;
procedure GetQueuedCompletionStatus(CompletionPort:HANDLE; lpNumberOfBytesTransferred:pCARDINAL; lpCompletionKey:pCARDINAL; lpOverlapped:pOVERLAPPED; dwMilliseconds:cardinal):boolean;
procedure PostQueuedCompletionStatus(CompletionPort:HANDLE; dwNumberOfBytesTransferred:cardinal; dwCompletionKey:cardinal; lpOverlapped:pOVERLAPPED):boolean;

const SEM_FAILCRITICALERRORS=0x00000001;
const SEM_NOGPFAULTERRORBOX=0x00000002;
const SEM_NOALIGNMENTFAULTEXCEPT=0x00000004;
const SEM_NOOPENFILEERRORBOX=0x00008000;

procedure SetErrorMode(uMode:cardinal):cardinal;
procedure ReadProcessMemory(hProcess:HANDLE; lpBaseAddress:address; lpBuffer:address; nSize:cardinal; lpNumberOfBytesRead:pCARDINAL):boolean;
procedure WriteProcessMemory(hProcess:HANDLE; lpBaseAddress:address; lpBuffer:address; nSize:cardinal; lpNumberOfBytesWritten:pCARDINAL):boolean;
procedure GetThreadContext(hThread:HANDLE; lpContext:pCONTEXT):boolean;
procedure SetThreadContext(hThread:HANDLE; lpContext:pCONTEXT):boolean;
procedure SuspendThread(hThread:HANDLE):cardinal;
procedure ResumeThread(hThread:HANDLE):cardinal;
procedure QueueUserAPC(pfnAPC:pPROC; hThread:HANDLE; dwData:cardinal):cardinal;
procedure DebugBreak();
procedure WaitForDebugEvent(lpDebugEvent:pDEBUG_EVENT; dwMilliseconds:cardinal):boolean;
procedure ContinueDebugEvent(dwProcessId:cardinal; dwThreadId:cardinal; dwContinueStatus:cardinal):boolean;
procedure DebugActiveProcess(dwProcessId:cardinal):boolean;
procedure InitializeCriticalSection(lpCriticalSection:pCRITICAL_SECTION);
procedure EnterCriticalSection(lpCriticalSection:pCRITICAL_SECTION);
procedure LeaveCriticalSection(lpCriticalSection:pCRITICAL_SECTION);
procedure DeleteCriticalSection(lpCriticalSection:pCRITICAL_SECTION);
procedure SetEvent(hEvent:HANDLE):boolean;
procedure ResetEvent(hEvent:HANDLE):boolean;
procedure PulseEvent(hEvent:HANDLE):boolean;
procedure ReleaseSemaphore(hSemaphore:HANDLE; lReleaseCount:cardinal; lpPreviousCount:pCARDINAL):boolean;
procedure ReleaseMutex(hMutex:HANDLE):boolean;
procedure WaitForSingleObject(hHandle:HANDLE; dwMilliseconds:cardinal):cardinal;
procedure WaitForMultipleObjects(nCount:cardinal; lpHandles:pHANDLE; bWaitAll:boolean; dwMilliseconds:cardinal):cardinal;
procedure Sleep(dwMilliseconds:cardinal);
procedure LoadResource(hModule:HMODULE; hResInfo:HRSRC):HGLOBAL;
procedure SizeofResource(hModule:HMODULE; hResInfo:HRSRC):cardinal;
procedure GlobalDeleteAtom(nAtom:ATOM):ATOM;
procedure InitAtomTable(nSize:cardinal):boolean;
procedure DeleteAtom(nAtom:ATOM):ATOM;
procedure SetHandleCount(uNumber:cardinal):cardinal;
procedure GetLogicalDrives():cardinal;
procedure LockFile(hFile:HANDLE; dwFileOffsetLow:cardinal; dwFileOffsetHigh:cardinal; nNumberOfBytesToLockLow:cardinal; nNumberOfBytesToLockHigh:cardinal):boolean;
procedure UnlockFile(hFile:HANDLE; dwFileOffsetLow:cardinal; dwFileOffsetHigh:cardinal; nNumberOfBytesToUnlockLow:cardinal; nNumberOfBytesToUnlockHigh:cardinal):boolean;
procedure LockFileEx(hFile:HANDLE; dwFlags:cardinal; dwReserved:cardinal; nNumberOfBytesToLockLow:cardinal; nNumberOfBytesToLockHigh:cardinal; lpOverlapped:pOVERLAPPED):boolean;

const LOCKFILE_FAIL_IMMEDIATELY=0x00000001;
const LOCKFILE_EXCLUSIVE_LOCK=0x00000002;

procedure UnlockFileEx(hFile:HANDLE; dwReserved:cardinal; nNumberOfBytesToUnlockLow:cardinal; nNumberOfBytesToUnlockHigh:cardinal; lpOverlapped:pOVERLAPPED):boolean;

type BY_HANDLE_FILE_INFORMATION=record
       dwFileAttributes:cardinal;
       ftCreationTime:FILETIME;
       ftLastAccessTime:FILETIME;
       ftLastWriteTime:FILETIME;
       dwVolumeSerialNumber:cardinal;
       nFileSizeHigh:cardinal;
       nFileSizeLow:cardinal;
       nNumberOfLinks:cardinal;
       nFileIndexHigh:cardinal;
       nFileIndexLow:cardinal;
     end;
     pBY_HANDLE_FILE_INFORMATION=pointer to BY_HANDLE_FILE_INFORMATION;

procedure GetFileInformationByHandle(hFile:HANDLE; lpFileInformation:pBY_HANDLE_FILE_INFORMATION):boolean;
procedure GetFileType(hFile:HANDLE):cardinal;
procedure GetFileSize(hFile:HANDLE; lpFileSizeHigh:pCARDINAL):cardinal;
procedure GetStdHandle(nStdHandle:cardinal):HANDLE;
procedure SetStdHandle(nStdHandle:cardinal; hHandle:HANDLE):boolean;
procedure WriteFile(hFile:HANDLE; lpBuffer:address; nNumberOfBytesToWrite:cardinal; lpNumberOfBytesWritten:pCARDINAL; lpOverlapped:pOVERLAPPED):boolean;
procedure ReadFile(hFile:HANDLE; lpBuffer:address; nNumberOfBytesToRead:cardinal; lpNumberOfBytesRead:pCARDINAL; lpOverlapped:pOVERLAPPED):boolean;
procedure FlushFileBuffers(hFile:HANDLE):boolean;
procedure DeviceIoControl(hDevice:HANDLE; dwIoControlCode:cardinal; lpInBuffer:address; nInBufferSize:cardinal; lpOutBuffer:address; nOutBufferSize:cardinal; lpBytesReturned:pCARDINAL; lpOverlapped:pOVERLAPPED):boolean;
procedure SetEndOfFile(hFile:HANDLE):boolean;
procedure SetFilePointer(hFile:HANDLE; lDistanceToMove:cardinal; lpDistanceToMoveHigh:pCARDINAL; dwMoveMethod:cardinal):cardinal;
procedure FindClose(hFindFile:HANDLE):boolean;
procedure GetFileTime(hFile:HANDLE; lpCreationTime:pFILETIME; lpLastAccessTime:pFILETIME; lpLastWriteTime:pFILETIME):boolean;
procedure SetFileTime(hFile:HANDLE; lpCreationTime:pFILETIME; lpLastAccessTime:pFILETIME; lpLastWriteTime:pFILETIME):boolean;
procedure CloseHandle(hObject:HANDLE):boolean;
procedure DuplicateHandle(hSourceProcessHandle:HANDLE; hSourceHandle:HANDLE; hTargetProcessHandle:HANDLE; lpTargetHandle:pHANDLE; dwDesiredAccess:cardinal; bInheritHandle:boolean; dwOptions:cardinal):boolean;
procedure GetHandleInformation(hObject:HANDLE; lpdwFlags:pCARDINAL):boolean;
procedure SetHandleInformation(hObject:HANDLE; dwMask:cardinal; dwFlags:cardinal):boolean;

const HANDLE_FLAG_INHERIT=0x00000001;
const HANDLE_FLAG_PROTECT_FROM_CLOSE=0x00000002;
const HINSTANCE_ERROR=0x00000020;

procedure LoadModule(lpModuleName:pstr; lpParameterBlock:address):cardinal;
procedure WinExec(lpCmdLine:pstr; uCmdShow:cardinal):cardinal;
procedure ClearCommBreak(hFile:HANDLE):boolean;
procedure ClearCommError(hFile:HANDLE; lpErrors:pCARDINAL; lpStat:pCOMSTAT):boolean;
procedure SetupComm(hFile:HANDLE; dwInQueue:cardinal; dwOutQueue:cardinal):boolean;
procedure EscapeCommFunction(hFile:HANDLE; dwFunc:cardinal):boolean;
procedure GetCommConfig(hCommDev:HANDLE; lpCC:pCOMMCONFIG; lpdwSize:pCARDINAL):boolean;
procedure GetCommMask(hFile:HANDLE; lpEvtMask:pCARDINAL):boolean;
procedure GetCommProperties(hFile:HANDLE; lpCommProp:pCOMMPROP):boolean;
procedure GetCommModemStatus(hFile:HANDLE; lpModemStat:pCARDINAL):boolean;
procedure GetCommState(hFile:HANDLE; lpDCB:pDCB):boolean;
procedure GetCommTimeouts(hFile:HANDLE; lpCommTimeouts:pCOMMTIMEOUTS):boolean;
procedure PurgeComm(hFile:HANDLE; dwFlags:cardinal):boolean;
procedure SetCommBreak(hFile:HANDLE):boolean;
procedure SetCommConfig(hCommDev:HANDLE; lpCC:pCOMMCONFIG; dwSize:cardinal):boolean;
procedure SetCommMask(hFile:HANDLE; dwEvtMask:cardinal):boolean;
procedure SetCommState(hFile:HANDLE; lpDCB:pDCB):boolean;
procedure SetCommTimeouts(hFile:HANDLE; lpCommTimeouts:pCOMMTIMEOUTS):boolean;
procedure TransmitCommChar(hFile:HANDLE; cChar:char):boolean;
procedure WaitCommEvent(hFile:HANDLE; lpEvtMask:pCARDINAL; lpOverlapped:pOVERLAPPED):boolean;
procedure SetTapePosition(hDevice:HANDLE; dwPositionMethod:cardinal; dwPartition:cardinal; dwOffsetLow:cardinal; dwOffsetHigh:cardinal; bImmediate:boolean):cardinal;
procedure GetTapePosition(hDevice:HANDLE; dwPositionType:cardinal; lpdwPartition:pCARDINAL; lpdwOffsetLow:pCARDINAL; lpdwOffsetHigh:pCARDINAL):cardinal;
procedure PrepareTape(hDevice:HANDLE; dwOperation:cardinal; bImmediate:boolean):cardinal;
procedure EraseTape(hDevice:HANDLE; dwEraseType:cardinal; bImmediate:boolean):cardinal;
procedure CreateTapePartition(hDevice:HANDLE; dwPartitionMethod:cardinal; dwCount:cardinal; dwSize:cardinal):cardinal;
procedure WriteTapemark(hDevice:HANDLE; dwTapemarkType:cardinal; dwTapemarkCount:cardinal; bImmediate:boolean):cardinal;
procedure GetTapeStatus(hDevice:HANDLE):cardinal;
procedure GetTapeParameters(hDevice:HANDLE; dwOperation:cardinal; lpdwSize:pCARDINAL; lpTapeInformation:address):cardinal;

const GET_TAPE_MEDIA_INFORMATION=0;
const GET_TAPE_DRIVE_INFORMATION=0x00000001;

procedure SetTapeParameters(hDevice:HANDLE; dwOperation:cardinal; lpTapeInformation:address):cardinal;

const SET_TAPE_MEDIA_INFORMATION=0;
const SET_TAPE_DRIVE_INFORMATION=0x00000001;

procedure Beep(dwFreq:cardinal; dwDuration:cardinal):boolean;
procedure MulDiv(nNumber:integer; nNumerator:integer; nDenominator:integer):integer;
procedure GetSystemTime(lpSystemTime:pSYSTEMTIME);
procedure GetSystemTimeAsFileTime(lpSystemTimeAsFileTime:pFILETIME);
procedure SetSystemTime(lpSystemTime:pSYSTEMTIME):boolean;
procedure GetLocalTime(lpSystemTime:pSYSTEMTIME);
procedure SetLocalTime(lpSystemTime:pSYSTEMTIME):boolean;
procedure GetSystemInfo(lpSystemInfo:pSYSTEM_INFO);

type TIME_ZONE_INFORMATION=record
       Bias:cardinal;
       StandardName:array[0..31]of word;
       StandardDate:SYSTEMTIME;
       StandardBias:cardinal;
       DaylightName:array[0..31]of word;
       DaylightDate:SYSTEMTIME;
       DaylightBias:cardinal;
     end;
     pTIME_ZONE_INFORMATION=pointer to TIME_ZONE_INFORMATION;

procedure SystemTimeToTzSpecificLocalTime(lpTimeZoneInformation:pTIME_ZONE_INFORMATION; lpUniversalTime:pSYSTEMTIME; lpLocalTime:pSYSTEMTIME):boolean;
procedure GetTimeZoneInformation(lpTimeZoneInformation:pTIME_ZONE_INFORMATION):cardinal;
procedure SetTimeZoneInformation(lpTimeZoneInformation:pTIME_ZONE_INFORMATION):boolean;
procedure SystemTimeToFileTime(lpSystemTime:pSYSTEMTIME; lpFileTime:pFILETIME):boolean;
procedure FileTimeToLocalFileTime(lpFileTime:pFILETIME; lpLocalFileTime:pFILETIME):boolean;
procedure LocalFileTimeToFileTime(lpLocalFileTime:pFILETIME; lpFileTime:pFILETIME):boolean;
procedure FileTimeToSystemTime(lpFileTime:pFILETIME; lpSystemTime:pSYSTEMTIME):boolean;
procedure CompareFileTime(lpFileTime1:pFILETIME; lpFileTime2:pFILETIME):cardinal;
procedure FileTimeToDosDateTime(lpFileTime:pFILETIME; lpFatDate:pWORD; lpFatTime:pWORD):boolean;
procedure DosDateTimeToFileTime(wFatDate:word; wFatTime:word; lpFileTime:pFILETIME):boolean;
procedure GetTickCount():cardinal;
procedure SetSystemTimeAdjustment(dwTimeAdjustment:cardinal; bTimeAdjustmentDisabled:boolean):boolean;
procedure GetSystemTimeAdjustment(lpTimeAdjustment:pCARDINAL; lpTimeIncrement:pCARDINAL; lpTimeAdjustmentDisabled:pBOOL):boolean;
procedure FormatMessage ascii(dwFlags:cardinal; lpSource:address; dwMessageId:cardinal; dwLanguageId:cardinal; lpBuffer:pstr; nSize:cardinal; Arguments:address):cardinal;

const FORMAT_MESSAGE_ALLOCATE_BUFFER=0x00000100;
const FORMAT_MESSAGE_IGNORE_INSERTS=0x00000200;
const FORMAT_MESSAGE_FROM_STRING=0x00000400;
const FORMAT_MESSAGE_FROM_HMODULE=0x00000800;
const FORMAT_MESSAGE_FROM_SYSTEM=0x00001000;
const FORMAT_MESSAGE_ARGUMENT_ARRAY=0x00002000;
const FORMAT_MESSAGE_MAX_WIDTH_MASK=0x000000FF;

procedure CreatePipe(hReadPipe:pHANDLE; hWritePipe:pHANDLE; lpPipeAttributes:pSECURITY_ATTRIBUTES; nSize:cardinal):boolean;
procedure ConnectNamedPipe(hNamedPipe:HANDLE; lpOverlapped:pOVERLAPPED):boolean;
procedure DisconnectNamedPipe(hNamedPipe:HANDLE):boolean;
procedure SetNamedPipeHandleState(hNamedPipe:HANDLE; lpMode:pCARDINAL; lpMaxCollectionCount:pCARDINAL; lpCollectDataTimeout:pCARDINAL):boolean;
procedure GetNamedPipeInfo(hNamedPipe:HANDLE; lpFlags:pCARDINAL; lpOutBufferSize:pCARDINAL; lpInBufferSize:pCARDINAL; lpMaxInstances:pCARDINAL):boolean;
procedure PeekNamedPipe(hNamedPipe:HANDLE; lpBuffer:address; nBufferSize:cardinal; lpBytesRead:pCARDINAL; lpTotalBytesAvail:pCARDINAL; lpBytesLeftThisMessage:pCARDINAL):boolean;
procedure TransactNamedPipe(hNamedPipe:HANDLE; lpInBuffer:address; nInBufferSize:cardinal; lpOutBuffer:address; nOutBufferSize:cardinal; lpBytesRead:pCARDINAL; lpOverlapped:pOVERLAPPED):boolean;
procedure CreateMailslot ascii(lpName:pstr; nMaxMessageSize:cardinal; lReadTimeout:cardinal; lpSecurityAttributes:pSECURITY_ATTRIBUTES):HANDLE;
procedure GetMailslotInfo(hMailslot:HANDLE; lpMaxMessageSize:pCARDINAL; lpNextSize:pCARDINAL; lpMessageCount:pCARDINAL; lpReadTimeout:pCARDINAL):boolean;
procedure SetMailslotInfo(hMailslot:HANDLE; lReadTimeout:cardinal):boolean;
procedure MapViewOfFile(hFileMappingObject:HANDLE; dwDesiredAccess:cardinal; dwFileOffsetHigh:cardinal; dwFileOffsetLow:cardinal; dwNumberOfBytesToMap:cardinal):address;
procedure FlushViewOfFile(lpBaseAddress:address; dwNumberOfBytesToFlush:cardinal):boolean;
procedure UnmapViewOfFile(lpBaseAddress:address):boolean;
procedure lstrcmp ascii(lpString1:pstr; lpString2:pstr):integer;
procedure lstrcmpi ascii(lpString1:pstr; lpString2:pstr):integer;
procedure lstrcpyn ascii(lpString1:pstr; lpString2:pstr; iMaxLength:integer):pstr;
procedure lstrcpy ascii(lpString1:pstr; lpString2:pstr):pstr;
procedure lstrcat ascii(lpString1:pstr; lpString2:pstr):pstr;
procedure lstrlen ascii(lpString:pstr):integer;
procedure OpenFile(lpFileName:pstr; lpReOpenBuff:pOFSTRUCT; uStyle:cardinal):HFILE;
procedure _lopen(lpPathName:pstr; iReadWrite:integer):HFILE;
procedure _lcreat(lpPathName:pstr; iAttribute:integer):HFILE;
procedure _lread(hFile:HFILE; lpBuffer:address; uBytes:cardinal):cardinal;
procedure _lwrite(hFile:HFILE; lpBuffer:pstr; uBytes:cardinal):cardinal;
procedure _hread(hFile:HFILE; lpBuffer:address; lBytes:integer):integer;
procedure _hwrite(hFile:HFILE; lpBuffer:pstr; lBytes:integer):integer;
procedure _lclose(hFile:HFILE):HFILE;
procedure _llseek(hFile:HFILE; lOffset:cardinal; iOrigin:integer):cardinal;
procedure TlsAlloc():cardinal;

const TLS_OUT_OF_INDEXES=0xFFFFFFFF;

procedure TlsGetValue(dwTlsIndex:cardinal):address;
procedure TlsSetValue(dwTlsIndex:cardinal; lpTlsValue:address):boolean;
procedure TlsFree(dwTlsIndex:cardinal):boolean;
procedure SleepEx(dwMilliseconds:cardinal; bAlertable:boolean):cardinal;
procedure WaitForSingleObjectEx(hHandle:HANDLE; dwMilliseconds:cardinal; bAlertable:boolean):cardinal;
procedure WaitForMultipleObjectsEx(nCount:cardinal; lpHandles:pHANDLE; bWaitAll:boolean; dwMilliseconds:cardinal; bAlertable:boolean):cardinal;
procedure ReadFileEx(hFile:HANDLE; lpBuffer:address; nNumberOfBytesToRead:cardinal; lpOverlapped:pOVERLAPPED; lpCompletionRoutine:pPROC):boolean;
procedure WriteFileEx(hFile:HANDLE; lpBuffer:address; nNumberOfBytesToWrite:cardinal; lpOverlapped:pOVERLAPPED; lpCompletionRoutine:pPROC):boolean;
procedure BackupRead(hFile:HANDLE; lpBuffer:pBYTE; nNumberOfBytesToRead:cardinal; lpNumberOfBytesRead:pCARDINAL; bAbort:boolean; bProcessSecurity:boolean; lpContext:address):boolean;
procedure BackupSeek(hFile:HANDLE; dwLowBytesToSeek:cardinal; dwHighBytesToSeek:cardinal; lpdwLowByteSeeked:pCARDINAL; lpdwHighByteSeeked:pCARDINAL; lpContext:address):boolean;
procedure BackupWrite(hFile:HANDLE; lpBuffer:pBYTE; nNumberOfBytesToWrite:cardinal; lpNumberOfBytesWritten:pCARDINAL; bAbort:boolean; bProcessSecurity:boolean; lpContext:address):boolean;

type WIN32_STREAM_ID=record
       dwStreamId:cardinal;
       dwStreamAttributes:cardinal;
       Size:LARGE_INTEGER;
       dwStreamNameSize:cardinal;
       cStreamName:array[0..ANYSIZE_ARRAY-1]of word;
     end;
     pWIN32_STREAM_ID=pointer to WIN32_STREAM_ID;

const BACKUP_INVALID=0x00000000;
const BACKUP_DATA=0x00000001;
const BACKUP_EA_DATA=0x00000002;
const BACKUP_SECURITY_DATA=0x00000003;
const BACKUP_ALTERNATE_DATA=0x00000004;
const BACKUP_LINK=0x00000005;
const BACKUP_PROPERTY_DATA=0x00000006;
const STREAM_NORMAL_ATTRIBUTE=0x00000000;
const STREAM_MODIFIED_WHEN_READ=0x00000001;
const STREAM_CONTAINS_SECURITY=0x00000002;
const STREAM_CONTAINS_PROPERTIES=0x00000004;
const STARTF_USESHOWWINDOW=0x00000001;
const STARTF_USESIZE=0x00000002;
const STARTF_USEPOSITION=0x00000004;
const STARTF_USECOUNTCHARS=0x00000008;
const STARTF_USEFILLATTRIBUTE=0x00000010;
const STARTF_RUNFULLSCREEN=0x00000020;
const STARTF_FORCEONFEEDBACK=0x00000040;
const STARTF_FORCEOFFFEEDBACK=0x00000080;
const STARTF_USESTDHANDLES=0x00000100;
const STARTF_USEHOTKEY=0x00000200;

type STARTUPINFO=record
       cb:cardinal;
       lpReserved:pstr;
       lpDesktop:pstr;
       lpTitle:pstr;
       dwX:cardinal;
       dwY:cardinal;
       dwXSize:cardinal;
       dwYSize:cardinal;
       dwXCountChars:cardinal;
       dwYCountChars:cardinal;
       dwFillAttribute:cardinal;
       dwFlags:cardinal;
       wShowWindow:word;
       cbReserved2:word;
       lpReserved2:pBYTE;
       hStdInput:HANDLE;
       hStdOutput:HANDLE;
       hStdError:HANDLE;
     end;
     pSTARTUPINFO=pointer to STARTUPINFO;

const SHUTDOWN_NORETRY=0x00000001;

type WIN32_FIND_DATA=record
       dwFileAttributes:cardinal;
       ftCreationTime:FILETIME;
       ftLastAccessTime:FILETIME;
       ftLastWriteTime:FILETIME;
       nFileSizeHigh:cardinal;
       nFileSizeLow:cardinal;
       dwReserved0:cardinal;
       dwReserved1:cardinal;
       cFileName:array[0..MAX_PATH-1]of char;
       cAlternateFileName:array[0..13]of char;
     end;
     pWIN32_FIND_DATA=pointer to WIN32_FIND_DATA;

type WIN32_FILE_ATTRIBUTE_DATA=record
       dwFileAttributes:cardinal;
       ftCreationTime:FILETIME;
       ftLastAccessTime:FILETIME;
       ftLastWriteTime:FILETIME;
       nFileSizeHigh:cardinal;
       nFileSizeLow:cardinal;
     end;
     pWIN32_FILE_ATTRIBUTE_DATA=pointer to WIN32_FILE_ATTRIBUTE_DATA;

procedure CreateMutex ascii(lpMutexAttributes:pSECURITY_ATTRIBUTES; bInitialOwner:boolean; lpName:pstr):HANDLE;
procedure OpenMutex ascii(dwDesiredAccess:cardinal; bInheritHandle:boolean; lpName:pstr):HANDLE;
procedure CreateEvent ascii(lpEventAttributes:pSECURITY_ATTRIBUTES; bManualReset:boolean; bInitialState:boolean; lpName:pstr):HANDLE;
procedure OpenEvent ascii(dwDesiredAccess:cardinal; bInheritHandle:boolean; lpName:pstr):HANDLE;
procedure CreateSemaphore ascii(lpSemaphoreAttributes:pSECURITY_ATTRIBUTES; lInitialCount:cardinal; lMaximumCount:cardinal; lpName:pstr):HANDLE;
procedure OpenSemaphore ascii(dwDesiredAccess:cardinal; bInheritHandle:boolean; lpName:pstr):HANDLE;
procedure CreateFileMapping ascii(hFile:HANDLE; lpFileMappingAttributes:pSECURITY_ATTRIBUTES; flProtect:cardinal; dwMaximumSizeHigh:cardinal; dwMaximumSizeLow:cardinal; lpName:pstr):HANDLE;
procedure OpenFileMapping ascii(dwDesiredAccess:cardinal; bInheritHandle:boolean; lpName:pstr):HANDLE;
procedure GetLogicalDriveStrings ascii(nBufferLength:cardinal; lpBuffer:pstr):cardinal;
procedure LoadLibrary ascii(lpLibFileName:pstr):HMODULE;
procedure LoadLibraryEx ascii(lpLibFileName:pstr; hFile:HANDLE; dwFlags:cardinal):HMODULE;

const DONT_RESOLVE_DLL_REFERENCES=0x00000001;
const LOAD_LIBRARY_AS_DATAFILE=0x00000002;
const LOAD_WITH_ALTERED_SEARCH_PATH=0x00000008;

procedure GetModuleFileName ascii(hModule:HMODULE; lpFilename:pstr; nSize:cardinal):cardinal;
procedure GetModuleHandle ascii(lpModuleName:pstr):HMODULE;
procedure CreateProcess ascii(lpApplicationName:pstr; lpCommandLine:pstr; lpProcessAttributes:pSECURITY_ATTRIBUTES; lpThreadAttributes:pSECURITY_ATTRIBUTES; bInheritHandles:boolean; dwCreationFlags:cardinal; lpEnvironment:address; lpCurrentDirectory:pstr; lpStartupInfo:pSTARTUPINFO; lpProcessInformation:pPROCESS_INFORMATION);
procedure SetProcessShutdownParameters(dwLevel:cardinal; dwFlags:cardinal):boolean;
procedure GetProcessShutdownParameters(lpdwLevel:pCARDINAL; lpdwFlags:pCARDINAL):boolean;
procedure GetProcessVersion(ProcessId:cardinal):cardinal;
procedure FatalAppExit ascii(uAction:cardinal; lpMessageText:pstr);
procedure GetStartupInfo ascii(lpStartupInfo:pSTARTUPINFO);
procedure GetCommandLine ascii():pstr;
procedure GetEnvironmentVariable ascii(lpName:pstr; lpBuffer:pstr; nSize:cardinal):cardinal;
procedure SetEnvironmentVariable ascii(lpName:pstr; lpValue:pstr):boolean;
procedure ExpandEnvironmentStrings ascii(lpSrc:pstr; lpDst:pstr; nSize:cardinal):cardinal;
procedure OutputDebugString ascii(lpOutputString:pstr);
procedure FindResource ascii(hModule:HMODULE; lpName:pstr; lpType:pstr):HRSRC;
procedure FindResourceEx ascii(hModule:HMODULE; lpType:pstr; lpName:pstr; wLanguage:word):HRSRC;
procedure EnumResourceTypes ascii(hModule:HMODULE; lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure EnumResourceNames ascii(hModule:HMODULE; lpType:pstr; lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure EnumResourceLanguages ascii(hModule:HMODULE; lpType:pstr; lpName:pstr; lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure BeginUpdateResource ascii(pFileName:pstr; bDeleteExistingResources:boolean):HANDLE;
procedure UpdateResource ascii(hUpdate:HANDLE; lpType:pstr; lpName:pstr; wLanguage:word; lpData:address; cbData:cardinal):boolean;
procedure EndUpdateResource ascii(hUpdate:HANDLE; fDiscard:boolean):boolean;
procedure GlobalAddAtom ascii(lpString:pstr):ATOM;
procedure GlobalFindAtom ascii(lpString:pstr):ATOM;
procedure GlobalGetAtomName ascii(nAtom:ATOM; lpBuffer:pstr; nSize:integer):cardinal;
procedure AddAtom ascii(lpString:pstr):ATOM;
procedure FindAtom ascii(lpString:pstr):ATOM;
procedure GetAtomName ascii(nAtom:ATOM; lpBuffer:pstr; nSize:integer):cardinal;
procedure GetProfileInt ascii(lpAppName:pstr; lpKeyName:pstr; nDefault:integer):cardinal;
procedure GetProfileString ascii(lpAppName:pstr; lpKeyName:pstr; lpDefault:pstr; lpReturnedString:pstr; nSize:cardinal):cardinal;
procedure WriteProfileString ascii(lpAppName:pstr; lpKeyName:pstr; lpString:pstr):boolean;
procedure GetProfileSection ascii(lpAppName:pstr; lpReturnedString:pstr; nSize:cardinal):cardinal;
procedure WriteProfileSection ascii(lpAppName:pstr; lpString:pstr):boolean;
procedure GetPrivateProfileInt ascii(lpAppName:pstr; lpKeyName:pstr; nDefault:integer; lpFileName:pstr):cardinal;
procedure GetPrivateProfileString ascii(lpAppName:pstr; lpKeyName:pstr; lpDefault:pstr; lpReturnedString:pstr; nSize:cardinal; lpFileName:pstr):cardinal;
procedure WritePrivateProfileString ascii(lpAppName:pstr; lpKeyName:pstr; lpString:pstr; lpFileName:pstr):boolean;
procedure GetPrivateProfileSection ascii(lpAppName:pstr; lpReturnedString:pstr; nSize:cardinal; lpFileName:pstr):cardinal;
procedure WritePrivateProfileSection ascii(lpAppName:pstr; lpString:pstr; lpFileName:pstr):boolean;
procedure GetPrivateProfileSectionNames ascii(lpszReturnBuffer:pstr; nSize:cardinal; lpFileName:pstr):cardinal;
procedure GetPrivateProfileStruct ascii(lpszSection:pstr; lpszKey:pstr; lpStruct:address; uSizeStruct:cardinal; szFile:pstr):boolean;
procedure WritePrivateProfileStruct ascii(lpszSection:pstr; lpszKey:pstr; lpStruct:address; uSizeStruct:cardinal; szFile:pstr):boolean;
procedure GetDriveType ascii(lpRootPathName:pstr):cardinal;
procedure GetSystemDirectory ascii(lpBuffer:pstr; uSize:cardinal):cardinal;
procedure GetTempPath ascii(nBufferLength:cardinal; lpBuffer:pstr):cardinal;
procedure GetTempFileName ascii(lpPathName:pstr; lpPrefixString:pstr; uUnique:cardinal; lpTempFileName:pstr):cardinal;
procedure GetWindowsDirectory ascii(lpBuffer:pstr; uSize:cardinal):cardinal;
procedure SetCurrentDirectory ascii(lpPathName:pstr):boolean;
procedure GetCurrentDirectory ascii(nBufferLength:cardinal; lpBuffer:pstr):cardinal;
procedure GetDiskFreeSpace ascii(lpRootPathName:pstr; lpSectorsPerCluster:pCARDINAL; lpBytesPerSector:pCARDINAL; lpNumberOfFreeClusters:pCARDINAL; lpTotalNumberOfClusters:pCARDINAL):boolean;
procedure GetDiskFreeSpaceEx ascii(lpDirectoryName:pstr; lpFreeBytesAvailableToCaller:pULARGE_INTEGER; lpTotalNumberOfBytes:pULARGE_INTEGER; lpTotalNumberOfFreeBytes:pULARGE_INTEGER):boolean;
procedure CreateDirectory ascii(lpPathName:pstr; lpSecurityAttributes:pSECURITY_ATTRIBUTES):boolean;
procedure CreateDirectoryEx ascii(lpTemplateDirectory:pstr; lpNewDirectory:pstr; lpSecurityAttributes:pSECURITY_ATTRIBUTES):boolean;
procedure RemoveDirectory ascii(lpPathName:pstr):boolean;
procedure GetFullPathName ascii(lpFileName:pstr; nBufferLength:cardinal; lpBuffer:pstr; lpFilePart:pstr):cardinal;

const DDD_RAW_TARGET_PATH=0x00000001;
const DDD_REMOVE_DEFINITION=0x00000002;
const DDD_EXACT_MATCH_ON_REMOVE=0x00000004;
const DDD_NO_BROADCAST_SYSTEM=0x00000008;

procedure DefineDosDevice ascii(dwFlags:cardinal; lpDeviceName:pstr; lpTargetPath:pstr):boolean;
procedure QueryDosDevice ascii(lpDeviceName:pstr; lpTargetPath:pstr; ucchMax:cardinal):cardinal;
procedure CreateFile ascii(lpFileName:pstr; dwDesiredAccess:cardinal; dwShareMode:cardinal; lpSecurityAttributes:pSECURITY_ATTRIBUTES; dwCreationDisposition:cardinal; dwFlagsAndAttributes:cardinal; hTemplateFile:HANDLE):HANDLE;
procedure SetFileAttributes ascii(lpFileName:pstr; dwFileAttributes:cardinal):boolean;
procedure GetFileAttributes ascii(lpFileName:pstr):cardinal;

const GetFileExInfoStandard=0;
const GetFileExMaxInfoLevel=0x00000001;

procedure GetCompressedFileSize ascii(lpFileName:pstr; lpFileSizeHigh:pCARDINAL):cardinal;
procedure DeleteFile ascii(lpFileName:pstr):boolean;

const FindExInfoStandard=0;
const FindExInfoMaxInfoLevel=0x00000001;
const FindExSearchNameMatch=0;
const FindExSearchLimitToDirectories=0x00000001;
const FindExSearchLimitToDevices=0x00000002;
const FindExSearchMaxSearchOp=0x00000003;
const FIND_FIRST_EX_CASE_SENSITIVE=0x00000001;

procedure FindFirstFile ascii(lpFileName:pstr; lpFindFileData:pWIN32_FIND_DATA):HANDLE;
procedure FindNextFile ascii(hFindFile:HANDLE; lpFindFileData:pWIN32_FIND_DATA):boolean;
procedure SearchPath ascii(lpPath:pstr; lpFileName:pstr; lpExtension:pstr; nBufferLength:cardinal; lpBuffer:pstr; lpFilePart:pstr):cardinal;
procedure CopyFile ascii(lpExistingFileName:pstr; lpNewFileName:pstr; bFailIfExists:boolean):boolean;
procedure MoveFile ascii(lpExistingFileName:pstr; lpNewFileName:pstr):boolean;
procedure MoveFileEx ascii(lpExistingFileName:pstr; lpNewFileName:pstr; dwFlags:cardinal):boolean;

const MOVEFILE_REPLACE_EXISTING=0x00000001;
const MOVEFILE_COPY_ALLOWED=0x00000002;
const MOVEFILE_DELAY_UNTIL_REBOOT=0x00000004;
const MOVEFILE_WRITE_THROUGH=0x00000008;

procedure CreateNamedPipe ascii(lpName:pstr; dwOpenMode:cardinal; dwPipeMode:cardinal; nMaxInstances:cardinal; nOutBufferSize:cardinal; nInBufferSize:cardinal; nDefaultTimeOut:cardinal; lpSecurityAttributes:pSECURITY_ATTRIBUTES):HANDLE;
procedure GetNamedPipeHandleState ascii(hNamedPipe:HANDLE; lpState:pCARDINAL; lpCurInstances:pCARDINAL; lpMaxCollectionCount:pCARDINAL; lpCollectDataTimeout:pCARDINAL; lpUserName:pstr; nMaxUserNameSize:cardinal):boolean;
procedure CallNamedPipe ascii(lpNamedPipeName:pstr; lpInBuffer:address; nInBufferSize:cardinal; lpOutBuffer:address; nOutBufferSize:cardinal; lpBytesRead:pCARDINAL; nTimeOut:cardinal):boolean;
procedure WaitNamedPipe ascii(lpNamedPipeName:pstr; nTimeOut:cardinal):boolean;
procedure SetVolumeLabel ascii(lpRootPathName:pstr; lpVolumeName:pstr):boolean;
procedure SetFileApisToOEM();
procedure SetFileApisToANSI();
procedure AreFileApisANSI():boolean;
procedure GetVolumeInformation ascii(lpRootPathName:pstr; lpVolumeNameBuffer:pstr; nVolumeNameSize:cardinal; lpVolumeSerialNumber:pCARDINAL; lpMaximumComponentLength:pCARDINAL; lpFileSystemFlags:pCARDINAL; lpFileSystemNameBuffer:pstr; nFileSystemNameSize:cardinal):boolean;

procedure FindFirstChangeNotification ascii(lpPathName:pstr; bWatchSubtree:boolean; dwNotifyFilter:cardinal):HANDLE;
procedure FindNextChangeNotification(hChangeHandle:HANDLE):boolean;
procedure FindCloseChangeNotification(hChangeHandle:HANDLE):boolean;
procedure VirtualLock(lpAddress:address; dwSize:cardinal):boolean;
procedure VirtualUnlock(lpAddress:address; dwSize:cardinal):boolean;
procedure MapViewOfFileEx(hFileMappingObject:HANDLE; dwDesiredAccess:cardinal; dwFileOffsetHigh:cardinal; dwFileOffsetLow:cardinal; dwNumberOfBytesToMap:cardinal; lpBaseAddress:address):address;
procedure SetPriorityClass(hProcess:HANDLE; dwPriorityClass:cardinal):boolean;
procedure GetPriorityClass(hProcess:HANDLE):cardinal;
procedure IsBadReadPtr(lp:address; ucb:cardinal):boolean;
procedure IsBadWritePtr(lp:address; ucb:cardinal):boolean;
procedure IsBadHugeReadPtr(lp:address; ucb:cardinal):boolean;
procedure IsBadHugeWritePtr(lp:address; ucb:cardinal):boolean;
procedure IsBadCodePtr(lpfn:pPROC):boolean;
procedure IsBadStringPtr ascii(lpsz:pstr; ucchMax:cardinal):boolean;

procedure BuildCommDCB ascii(lpDef:pstr; lpDCB:pDCB):boolean;
procedure BuildCommDCBAndTimeouts ascii(lpDef:pstr; lpDCB:pDCB; lpCommTimeouts:pCOMMTIMEOUTS):boolean;
procedure CommConfigDialog ascii(lpszName:pstr; hWnd:HWND; lpCC:pCOMMCONFIG):boolean;
procedure GetDefaultCommConfig ascii(lpszName:pstr; lpCC:pCOMMCONFIG; lpdwSize:pCARDINAL):boolean;
procedure SetDefaultCommConfig ascii(lpszName:pstr; lpCC:pCOMMCONFIG; dwSize:cardinal):boolean;

const MAX_COMPUTERNAME_LENGTH=0x0000000F;

procedure GetComputerName ascii(lpBuffer:pstr; nSize:pCARDINAL):boolean;
procedure SetComputerName ascii(lpComputerName:pstr):boolean;

const LOGON32_LOGON_INTERACTIVE=0x00000002;
const LOGON32_LOGON_NETWORK=0x00000003;
const LOGON32_LOGON_BATCH=0x00000004;
const LOGON32_LOGON_SERVICE=0x00000005;
const LOGON32_PROVIDER_DEFAULT=0;
const LOGON32_PROVIDER_WINNT35=0x00000001;
const LOGON32_PROVIDER_WINNT40=0x00000002;

const HW_PROFILE_GUIDLEN=0x00000027;
const MAX_PROFILE_LEN=0x00000050;
const DOCKINFO_UNDOCKED=0x00000001;
const DOCKINFO_DOCKED=0x00000002;
const DOCKINFO_USER_SUPPLIED=0x00000004;
const DOCKINFO_USER_UNDOCKED=DOCKINFO_USER_SUPPLIED|DOCKINFO_UNDOCKED;
const DOCKINFO_USER_DOCKED=DOCKINFO_USER_SUPPLIED|DOCKINFO_DOCKED;

type HW_PROFILE_INFO=record
       dwDockInfo:cardinal;
       szHwProfileGuid:array[0..HW_PROFILE_GUIDLEN-1]of char;
       szHwProfileName:array[0..MAX_PROFILE_LEN-1]of char;
     end;
     pHW_PROFILE_INFO=pointer to HW_PROFILE_INFO;

procedure QueryPerformanceCounter(lpPerformanceCount:pLARGE_INTEGER):boolean;
procedure QueryPerformanceFrequency(lpFrequency:pLARGE_INTEGER):boolean;

type OSVERSIONINFO=record
       dwOSVersionInfoSize:cardinal;
       dwMajorVersion:cardinal;
       dwMinorVersion:cardinal;
       dwBuildNumber:cardinal;
       dwPlatformId:cardinal;
       szCSDVersion:array[0..127]of char;
     end;
     pOSVERSIONINFO=pointer to OSVERSIONINFO;

const VER_PLATFORM_WIN32s=0;
const VER_PLATFORM_WIN32_WINDOWS=0x00000001;
const VER_PLATFORM_WIN32_NT=0x00000002;

procedure GetVersionEx ascii(lpVersionInformation:pOSVERSIONINFO):boolean;

const TC_NORMAL=0;
const TC_HARDERR=0x00000001;
const TC_GP_TRAP=0x00000002;
const TC_SIGNAL=0x00000003;
const AC_LINE_OFFLINE=0x00000000;
const AC_LINE_ONLINE=0x00000001;
const AC_LINE_BACKUP_POWER=0x00000002;
const AC_LINE_UNKNOWN=0x000000FF;
const BATTERY_FLAG_HIGH=0x00000001;
const BATTERY_FLAG_LOW=0x00000002;
const BATTERY_FLAG_CRITICAL=0x00000004;
const BATTERY_FLAG_CHARGING=0x00000008;
const BATTERY_FLAG_NO_BATTERY=0x00000080;
const BATTERY_FLAG_UNKNOWN=0x000000FF;
const BATTERY_PERCENTAGE_UNKNOWN=0x000000FF;
const BATTERY_LIFE_UNKNOWN=0xFFFFFFFF;

type SYSTEM_POWER_STATUS=record
       ACLineStatus:byte;
       BatteryFlag:byte;
       BatteryLifePercent:byte;
       Reserved1:byte;
       BatteryLifeTime:cardinal;
       BatteryFullLifeTime:cardinal;
     end;
     pSYSTEM_POWER_STATUS=pointer to SYSTEM_POWER_STATUS;

procedure GetSystemPowerStatus(lpSystemPowerStatus:pSYSTEM_POWER_STATUS):boolean;
procedure SetSystemPowerState(fSuspend:boolean; fForce:boolean):boolean;

type WIN_CERTIFICATE=record
       dwLength:cardinal;
       wRevision:word;
       wCertificateType:word;
       bCertificate:array[0..ANYSIZE_ARRAY-1]of byte;
     end;
     pWIN_CERTIFICATE=pointer to WIN_CERTIFICATE;

const WIN_CERT_REVISION_1_0=0x00000100;
const WIN_CERT_TYPE_X509=0x00000001;
const WIN_CERT_TYPE_PKCS_SIGNED_DATA=0x00000002;
const WIN_CERT_TYPE_RESERVED_1=0x00000003;

type GUID=record
       Data1:cardinal;
       Data2:word;
       Data3:word;
       Data4:array[0..7]of byte;
     end;

type WIN_TRUST_SUBJECT=address;
type WIN_TRUST_ACTDATA_CONTEXT_WITH_SUBJECT=record
       hClientToken:HANDLE;
       SubjectType:pointer to GUID;
       Subject:WIN_TRUST_SUBJECT;
     end;
     pWIN_TRUST_ACTDATA_CONTEXT_WITH_SUBJECT=pointer to WIN_TRUST_ACTDATA_CONTEXT_WITH_SUBJECT;

type WIN_TRUST_ACTDATA_SUBJECT_ONLY=record
       SubjectType:pointer to GUID;
       Subject:WIN_TRUST_SUBJECT;
     end;
     pWIN_TRUST_ACTDATA_SUBJECT_ONLY=pointer to WIN_TRUST_ACTDATA_SUBJECT_ONLY;

type WIN_TRUST_SUBJECT_FILE=record
       hFile:HANDLE;
       lpPath:address;
     end;
     pWIN_TRUST_SUBJECT_FILE=pointer to WIN_TRUST_SUBJECT_FILE;

type WIN_TRUST_SUBJECT_FILE_AND_DISPLAY=record
       hFile:HANDLE;
       lpPath:address;
       lpDisplayName:address;
     end;
     pWIN_TRUST_SUBJECT_FILE_AND_DISPLAY=pointer to WIN_TRUST_SUBJECT_FILE_AND_DISPLAY;

type WIN_SPUB_TRUSTED_PUBLISHER_DATA=record
       hClientToken:HANDLE;
       lpCertificate:pWIN_CERTIFICATE;
     end;
     pWIN_SPUB_TRUSTED_PUBLISHER_DATA=pointer to WIN_SPUB_TRUSTED_PUBLISHER_DATA;

type COORD=record
       X:word;
       Y:word;
     end;
     pCOORD=pointer to COORD;

type SMALL_RECT=record
       Left:byte;
       Top:byte;
       Right:byte;
       Bottom:byte;
     end;
     pSMALL_RECT=pointer to SMALL_RECT;

type KEY_EVENT_RECORD=record
       bKeyDown:boolean;
       wRepeatCount:word;
       wVirtualKeyCode:word;
       wVirtualScanCode:word;
       Char:word;
       dwControlKeyState:cardinal;
     end;
     pKEY_EVENT_RECORD=pointer to KEY_EVENT_RECORD;

const RIGHT_ALT_PRESSED=0X00000001;
const LEFT_ALT_PRESSED=0X00000002;
const RIGHT_CTRL_PRESSED=0X00000004;
const LEFT_CTRL_PRESSED=0X00000008;
const SHIFT_PRESSED=0X00000010;
const NUMLOCK_ON=0X00000020;
const SCROLLLOCK_ON=0X00000040;
const CAPSLOCK_ON=0X00000080;
const ENHANCED_KEY=0X00000100;
type MOUSE_EVENT_RECORD=record
       dwMousePosition:COORD;
       dwButtonState:cardinal;
       dwControlKeyState:cardinal;
       dwEventFlags:cardinal;
     end;
     pMOUSE_EVENT_RECORD=pointer to MOUSE_EVENT_RECORD;

const FROM_LEFT_1ST_BUTTON_PRESSED=0X00000001;
const RIGHTMOST_BUTTON_PRESSED=0X00000002;
const FROM_LEFT_2ND_BUTTON_PRESSED=0X00000004;
const FROM_LEFT_3RD_BUTTON_PRESSED=0X00000008;
const FROM_LEFT_4TH_BUTTON_PRESSED=0X00000010;
const MOUSE_MOVED=0X00000001;
const DOUBLE_CLICK=0X00000002;
type WINDOW_BUFFER_SIZE_RECORD=record
       dwSize:COORD;
     end;
     pWINDOW_BUFFER_SIZE_RECORD=pointer to WINDOW_BUFFER_SIZE_RECORD;

type MENU_EVENT_RECORD=record
       dwCommandId:cardinal;
     end;
     pMENU_EVENT_RECORD=pointer to MENU_EVENT_RECORD;

type FOCUS_EVENT_RECORD=record
       bSetFocus:boolean;
     end;
     pFOCUS_EVENT_RECORD=pointer to FOCUS_EVENT_RECORD;

type INPUT_RECORD=record
       EventType:word;
       Event:array[0..3]of cardinal;
     end;
     pINPUT_RECORD=pointer to INPUT_RECORD;

const KEY_EVENT=0X00000001;
const MOUSE_EVENT=0X00000002;
const WINDOW_BUFFER_SIZE_EVENT=0X00000004;
const MENU_EVENT=0X00000008;
const FOCUS_EVENT=0X00000010;
type CHAR_INFO=record
       Char:word;
       Attributes:word;
     end;
     pCHAR_INFO=pointer to CHAR_INFO;

const FOREGROUND_BLUE=0X00000001;
const FOREGROUND_GREEN=0X00000002;
const FOREGROUND_RED=0X00000004;
const FOREGROUND_INTENSITY=0X00000008;
const BACKGROUND_BLUE=0X00000010;
const BACKGROUND_GREEN=0X00000020;
const BACKGROUND_RED=0X00000040;
const BACKGROUND_INTENSITY=0X00000080;
type CONSOLE_SCREEN_BUFFER_INFO=record
       dwSize:COORD;
       dwCursorPosition:COORD;
       wAttributes:word;
       srWindow:SMALL_RECT;
       dwMaximumWindowSize:COORD;
     end;
     pCONSOLE_SCREEN_BUFFER_INFO=pointer to CONSOLE_SCREEN_BUFFER_INFO;

type CONSOLE_CURSOR_INFO=record
       dwSize:cardinal;
       bVisible:boolean;
     end;
     pCONSOLE_CURSOR_INFO=pointer to CONSOLE_CURSOR_INFO;

const CTRL_C_EVENT=0X00000000;
const CTRL_BREAK_EVENT=0X00000001;
const CTRL_CLOSE_EVENT=0X00000002;
const CTRL_LOGOFF_EVENT=0X00000005;
const CTRL_SHUTDOWN_EVENT=0X00000006;
const ENABLE_PROCESSED_INPUT=0X00000001;
const ENABLE_LINE_INPUT=0X00000002;
const ENABLE_ECHO_INPUT=0X00000004;
const ENABLE_WINDOW_INPUT=0X00000008;
const ENABLE_MOUSE_INPUT=0X00000010;
const ENABLE_PROCESSED_OUTPUT=0X00000001;
const ENABLE_WRAP_AT_EOL_OUTPUT=0X00000002;
procedure PeekConsoleInput ascii(hConsoleInput:HANDLE; lpBuffer:pINPUT_RECORD; nLength:cardinal; lpNumberOfEventsRead:pCARDINAL):boolean;
procedure ReadConsoleInput ascii(hConsoleInput:HANDLE; lpBuffer:pINPUT_RECORD; nLength:cardinal; lpNumberOfEventsRead:pCARDINAL):boolean;
procedure WriteConsoleInput ascii(hConsoleInput:HANDLE; lpBuffer:pINPUT_RECORD; nLength:cardinal; lpNumberOfEventsWritten:pCARDINAL):boolean;
procedure ReadConsoleOutput ascii(hConsoleOutput:HANDLE; lpBuffer:pCHAR_INFO; dwBufferSize:COORD; dwBufferCoord:COORD; lpReadRegion:pSMALL_RECT):boolean;
procedure WriteConsoleOutput ascii(hConsoleOutput:HANDLE; lpBuffer:pCHAR_INFO; dwBufferSize:COORD; dwBufferCoord:COORD; lpWriteRegion:pSMALL_RECT):boolean;
procedure ReadConsoleOutputCharacter ascii(hConsoleOutput:HANDLE; lpCharacter:pstr; nLength:cardinal; dwReadCoord:COORD; lpNumberOfCharsRead:pCARDINAL):boolean;
procedure ReadConsoleOutputAttribute(hConsoleOutput:HANDLE; lpAttribute:pWORD; nLength:cardinal; dwReadCoord:COORD; lpNumberOfAttrsRead:pCARDINAL):boolean;
procedure WriteConsoleOutputCharacter ascii(hConsoleOutput:HANDLE; lpCharacter:pstr; nLength:cardinal; dwWriteCoord:COORD; lpNumberOfCharsWritten:pCARDINAL):boolean;
procedure WriteConsoleOutputAttribute(hConsoleOutput:HANDLE; lpAttribute:pWORD; nLength:cardinal; dwWriteCoord:COORD; lpNumberOfAttrsWritten:pCARDINAL):boolean;
procedure FillConsoleOutputCharacter ascii(hConsoleOutput:HANDLE; cCharacter:char; nLength:cardinal; dwWriteCoord:COORD; lpNumberOfCharsWritten:pCARDINAL):boolean;
procedure FillConsoleOutputAttribute(hConsoleOutput:HANDLE; wAttribute:word; nLength:cardinal; dwWriteCoord:COORD; lpNumberOfAttrsWritten:pCARDINAL):boolean;
procedure GetConsoleMode(hConsoleHandle:HANDLE; lpMode:pCARDINAL):boolean;
procedure GetNumberOfConsoleInputEvents(hConsoleInput:HANDLE; lpNumberOfEvents:pCARDINAL):boolean;
procedure GetConsoleScreenBufferInfo(hConsoleOutput:HANDLE; lpConsoleScreenBufferInfo:pCONSOLE_SCREEN_BUFFER_INFO):boolean;
procedure GetLargestConsoleWindowSize(hConsoleOutput:HANDLE):COORD;
procedure GetConsoleCursorInfo(hConsoleOutput:HANDLE; lpConsoleCursorInfo:pCONSOLE_CURSOR_INFO):boolean;
procedure GetNumberOfConsoleMouseButtons(lpNumberOfMouseButtons:pCARDINAL):boolean;
procedure SetConsoleMode(hConsoleHandle:HANDLE; dwMode:cardinal):boolean;
procedure SetConsoleActiveScreenBuffer(hConsoleOutput:HANDLE):boolean;
procedure FlushConsoleInputBuffer(hConsoleInput:HANDLE):boolean;
procedure SetConsoleScreenBufferSize(hConsoleOutput:HANDLE; dwSize:COORD):boolean;
procedure SetConsoleCursorPosition(hConsoleOutput:HANDLE; dwCursorPosition:COORD):boolean;
procedure SetConsoleCursorInfo(hConsoleOutput:HANDLE; lpConsoleCursorInfo:pCONSOLE_CURSOR_INFO):boolean;
procedure ScrollConsoleScreenBuffer ascii(hConsoleOutput:HANDLE; lpScrollRectangle:pSMALL_RECT; lpClipRectangle:pSMALL_RECT; dwDestinationOrigin:COORD; lpFill:pCHAR_INFO):boolean;
procedure SetConsoleWindowInfo(hConsoleOutput:HANDLE; bAbsolute:boolean; lpConsoleWindow:pSMALL_RECT):boolean;
procedure SetConsoleTextAttribute(hConsoleOutput:HANDLE; wAttributes:word):boolean;
procedure SetConsoleCtrlHandler(HandlerRoutine:address; Add:boolean):boolean;
procedure GenerateConsoleCtrlEvent(dwCtrlEvent:cardinal; dwProcessGroupId:cardinal):boolean;
procedure AllocConsole():boolean;
procedure FreeConsole():boolean;
procedure GetConsoleTitle ascii(lpConsoleTitle:pstr; nSize:cardinal):cardinal;
procedure SetConsoleTitle ascii(lpConsoleTitle:pstr):boolean;
procedure ReadConsole ascii(hConsoleInput:HANDLE; lpBuffer:address; nNumberOfCharsToRead:cardinal; lpNumberOfCharsRead:pCARDINAL; lpReserved:address):boolean;
procedure WriteConsole ascii(hConsoleOutput:HANDLE; lpBuffer:address; nNumberOfCharsToWrite:cardinal; lpNumberOfCharsWritten:pCARDINAL; lpReserved:address):boolean;
const CONSOLE_TEXTMODE_BUFFER=0X00000001;
procedure CreateConsoleScreenBuffer(dwDesiredAccess:cardinal; dwShareMode:cardinal; lpSecurityAttributes:pSECURITY_ATTRIBUTES; dwFlags:cardinal; lpScreenBufferData:address):HANDLE;
procedure GetConsoleCP():cardinal;
procedure SetConsoleCP(wCodePageID:cardinal):boolean;
procedure GetConsoleOutputCP():cardinal;
procedure SetConsoleOutputCP(wCodePageID:cardinal):boolean;

//---------------------------------winnls---------------------------------

const
// Primary language IDs. 

  LANG_NEUTRAL                         = 0x00; 

  LANG_AFRIKAANS                       = 0x36; 
  LANG_ALBANIAN                        = 0x1c; 
  LANG_ARABIC                          = 0x01; 
  LANG_BASQUE                          = 0x2d; 
  LANG_BELARUSIAN                      = 0x23; 
  LANG_BULGARIAN                       = 0x02; 
  LANG_CATALAN                         = 0x03; 
  LANG_CHINESE                         = 0x04; 
  LANG_CROATIAN                        = 0x1a; 
  LANG_CZECH                           = 0x05; 
  LANG_DANISH                          = 0x06; 
  LANG_DUTCH                           = 0x13; 
  LANG_ENGLISH                         = 0x09; 
  LANG_ESTONIAN                        = 0x25; 
  LANG_FAEROESE                        = 0x38; 
  LANG_FARSI                           = 0x29; 
  LANG_FINNISH                         = 0x0b; 
  LANG_FRENCH                          = 0x0c; 
  LANG_GERMAN                          = 0x07; 
  LANG_GREEK                           = 0x08; 
  LANG_HEBREW                          = 0x0d; 
  LANG_HUNGARIAN                       = 0x0e; 
  LANG_ICELANDIC                       = 0x0f; 
  LANG_INDONESIAN                      = 0x21; 
  LANG_ITALIAN                         = 0x10; 
  LANG_JAPANESE                        = 0x11; 
  LANG_KOREAN                          = 0x12; 
  LANG_LATVIAN                         = 0x26; 
  LANG_LITHUANIAN                      = 0x27; 
  LANG_NORWEGIAN                       = 0x14; 
  LANG_POLISH                          = 0x15; 
  LANG_PORTUGUESE                      = 0x16; 
  LANG_ROMANIAN                        = 0x18; 
  LANG_RUSSIAN                         = 0x19; 
  LANG_SERBIAN                         = 0x1a; 
  LANG_SLOVAK                          = 0x1b; 
  LANG_SLOVENIAN                       = 0x24; 
  LANG_SPANISH                         = 0x0a; 
  LANG_SWEDISH                         = 0x1d; 
  LANG_THAI                            = 0x1e; 
  LANG_TURKISH                         = 0x1f; 
  LANG_UKRAINIAN                       = 0x22; 
  LANG_VIETNAMESE                      = 0x2a; 


// Sublanguage IDs. 

  SUBLANG_NEUTRAL                      = 0x00;    // language neutral 
  SUBLANG_DEFAULT                      = 0x01;    // user default 
  SUBLANG_SYS_DEFAULT                  = 0x02;    // system default 

  SUBLANG_ARABIC_SAUDI_ARABIA          = 0x01;    // Arabic (Saudi Arabia) 
  SUBLANG_ARABIC_IRAQ                  = 0x02;    // Arabic (Iraq) 
  SUBLANG_ARABIC_EGYPT                 = 0x03;    // Arabic (Egypt) 
  SUBLANG_ARABIC_LIBYA                 = 0x04;    // Arabic (Libya) 
  SUBLANG_ARABIC_ALGERIA               = 0x05;    // Arabic (Algeria) 
  SUBLANG_ARABIC_MOROCCO               = 0x06;    // Arabic (Morocco) 
  SUBLANG_ARABIC_TUNISIA               = 0x07;    // Arabic (Tunisia) 
  SUBLANG_ARABIC_OMAN                  = 0x08;    // Arabic (Oman) 
  SUBLANG_ARABIC_YEMEN                 = 0x09;    // Arabic (Yemen) 
  SUBLANG_ARABIC_SYRIA                 = 0x0a;    // Arabic (Syria) 
  SUBLANG_ARABIC_JORDAN                = 0x0b;    // Arabic (Jordan) 
  SUBLANG_ARABIC_LEBANON               = 0x0c;    // Arabic (Lebanon) 
  SUBLANG_ARABIC_KUWAIT                = 0x0d;    // Arabic (Kuwait) 
  SUBLANG_ARABIC_UAE                   = 0x0e;    // Arabic (U.A.E) 
  SUBLANG_ARABIC_BAHRAIN               = 0x0f;    // Arabic (Bahrain) 
  SUBLANG_ARABIC_QATAR                 = 0x10;    // Arabic (Qatar) 
  SUBLANG_CHINESE_TRADITIONAL          = 0x01;    // Chinese (Taiwan) 
  SUBLANG_CHINESE_SIMPLIFIED           = 0x02;    // Chinese (PR China) 
  SUBLANG_CHINESE_HONGKONG             = 0x03;    // Chinese (Hong Kong) 
  SUBLANG_CHINESE_SINGAPORE            = 0x04;    // Chinese (Singapore) 
  SUBLANG_DUTCH                        = 0x01;    // Dutch 
  SUBLANG_DUTCH_BELGIAN                = 0x02;    // Dutch (Belgian) 
  SUBLANG_ENGLISH_US                   = 0x01;    // English (USA) 
  SUBLANG_ENGLISH_UK                   = 0x02;    // English (UK) 
  SUBLANG_ENGLISH_AUS                  = 0x03;    // English (Australian) 
  SUBLANG_ENGLISH_CAN                  = 0x04;    // English (Canadian) 
  SUBLANG_ENGLISH_NZ                   = 0x05;    // English (New Zealand) 
  SUBLANG_ENGLISH_EIRE                 = 0x06;    // English (Irish) 
  SUBLANG_ENGLISH_SOUTH_AFRICA         = 0x07;    // English (South Africa) 
  SUBLANG_ENGLISH_JAMAICA              = 0x08;    // English (Jamaica) 
  SUBLANG_ENGLISH_CARIBBEAN            = 0x09;    // English (Caribbean) 
  SUBLANG_ENGLISH_BELIZE               = 0x0a;    // English (Belize) 
  SUBLANG_ENGLISH_TRINIDAD             = 0x0b;    // English (Trinidad) 
  SUBLANG_FRENCH                       = 0x01;    // French 
  SUBLANG_FRENCH_BELGIAN               = 0x02;    // French (Belgian) 
  SUBLANG_FRENCH_CANADIAN              = 0x03;    // French (Canadian) 
  SUBLANG_FRENCH_SWISS                 = 0x04;    // French (Swiss) 
  SUBLANG_FRENCH_LUXEMBOURG            = 0x05;    // French (Luxembourg) 
  SUBLANG_GERMAN                       = 0x01;    // German 
  SUBLANG_GERMAN_SWISS                 = 0x02;    // German (Swiss) 
  SUBLANG_GERMAN_AUSTRIAN              = 0x03;    // German (Austrian) 
  SUBLANG_GERMAN_LUXEMBOURG            = 0x04;    // German (Luxembourg) 
  SUBLANG_GERMAN_LIECHTENSTEIN         = 0x05;    // German (Liechtenstein) 
  SUBLANG_ITALIAN                      = 0x01;    // Italian 
  SUBLANG_ITALIAN_SWISS                = 0x02;    // Italian (Swiss) 
  SUBLANG_KOREAN                       = 0x01;    // Korean (Extended Wansung) 
  SUBLANG_KOREAN_JOHAB                 = 0x02;    // Korean (Johab) 
  SUBLANG_NORWEGIAN_BOKMAL             = 0x01;    // Norwegian (Bokmal) 
  SUBLANG_NORWEGIAN_NYNORSK            = 0x02;    // Norwegian (Nynorsk) 
  SUBLANG_PORTUGUESE                   = 0x02;    // Portuguese 
  SUBLANG_PORTUGUESE_BRAZILIAN         = 0x01;    // Portuguese (Brazilian) 
  SUBLANG_SERBIAN_LATIN                = 0x02;    // Serbian (Latin) 
  SUBLANG_SERBIAN_CYRILLIC             = 0x03;    // Serbian (Cyrillic) 
  SUBLANG_SPANISH                      = 0x01;    // Spanish (Castilian) 
  SUBLANG_SPANISH_MEXICAN              = 0x02;    // Spanish (Mexican) 
  SUBLANG_SPANISH_MODERN               = 0x03;    // Spanish (Modern) 
  SUBLANG_SPANISH_GUATEMALA            = 0x04;    // Spanish (Guatemala) 
  SUBLANG_SPANISH_COSTA_RICA           = 0x05;    // Spanish (Costa Rica) 
  SUBLANG_SPANISH_PANAMA               = 0x06;    // Spanish (Panama) 
  SUBLANG_SPANISH_DOMINICAN_REPUBLIC     = 0x07;  // Spanish (Dominican Republic) 
  SUBLANG_SPANISH_VENEZUELA            = 0x08;    // Spanish (Venezuela) 
  SUBLANG_SPANISH_COLOMBIA             = 0x09;    // Spanish (Colombia) 
  SUBLANG_SPANISH_PERU                 = 0x0a;    // Spanish (Peru) 
  SUBLANG_SPANISH_ARGENTINA            = 0x0b;    // Spanish (Argentina) 
  SUBLANG_SPANISH_ECUADOR              = 0x0c;    // Spanish (Ecuador) 
  SUBLANG_SPANISH_CHILE                = 0x0d;    // Spanish (Chile) 
  SUBLANG_SPANISH_URUGUAY              = 0x0e;    // Spanish (Uruguay) 
  SUBLANG_SPANISH_PARAGUAY             = 0x0f;    // Spanish (Paraguay) 
  SUBLANG_SPANISH_BOLIVIA              = 0x10;    // Spanish (Bolivia) 
  SUBLANG_SPANISH_EL_SALVADOR          = 0x11;    // Spanish (El Salvador) 
  SUBLANG_SPANISH_HONDURAS             = 0x12;    // Spanish (Honduras) 
  SUBLANG_SPANISH_NICARAGUA            = 0x13;    // Spanish (Nicaragua) 
  SUBLANG_SPANISH_PUERTO_RICO          = 0x14;    // Spanish (Puerto Rico) 
  SUBLANG_SWEDISH                      = 0x01;    // Swedish 
  SUBLANG_SWEDISH_FINLAND              = 0x02;    // Swedish (Finland) 


// Sorting IDs. 

  SORT_DEFAULT                         = 0x0;     // sorting default 

  SORT_JAPANESE_XJIS                   = 0x0;     // Japanese XJIS order 
  SORT_JAPANESE_UNICODE                = 0x1;     // Japanese Unicode order 

  SORT_CHINESE_BIG5                    = 0x0;     // Chinese BIG5 order 
  SORT_CHINESE_PRCP                    = 0x0;     // PRC Chinese Phonetic order 
  SORT_CHINESE_UNICODE                 = 0x1;     // Chinese Unicode order 
  SORT_CHINESE_PRC                     = 0x2;     // PRC Chinese Stroke Count order 

  SORT_KOREAN_KSC                      = 0x0;     // Korean KSC order 
  SORT_KOREAN_UNICODE                  = 0x1;     // Korean Unicode order 

  SORT_GERMAN_PHONE_BOOK               = 0x1;     // German Phone Book order 

// Default System and User IDs for language and locale. 

  LANG_SYSTEM_DEFAULT   = 0x00000800;
  LANG_USER_DEFAULT     = 0x00000400;
 
  LOCALE_SYSTEM_DEFAULT = LANG_SYSTEM_DEFAULT;
  LOCALE_USER_DEFAULT   = LANG_USER_DEFAULT;

const

// String Length Maximums.

  MAX_LEADBYTES = 12; // 5 ranges, 2 bytes ea., 0 term.
  MAX_DEFAULTCHAR = 2; // single or double byte

// MBCS and Unicode Translation Flags.

  MB_PRECOMPOSED = 1; // use precomposed chars
  MB_COMPOSITE = 2; // use composite chars
  MB_USEGLYPHCHARS = 4; // use glyph chars, not ctrl chars

  WC_DEFAULTCHECK = 0x100; // check for default char
  WC_COMPOSITECHECK = 0x200; // convert composite to precomposed
  WC_DISCARDNS = 0x10; // discard non-spacing chars
  WC_SEPCHARS = 0x20; // generate separate chars
  WC_DEFAULTCHAR = 0x40; // replace w default char

// Character Type Flags.

  CT_CTYPE1 = 1; // ctype 1 information
  CT_CTYPE2 = 2; // ctype 2 information
  CT_CTYPE3 = 4; // ctype 3 information

// CType 1 Flag Bits.

  C1_UPPER = 1; // upper case
  C1_LOWER = 2; // lower case
  C1_DIGIT = 4; // decimal digits
  C1_SPACE = 8; // spacing characters
  C1_PUNCT = 0x10; // punctuation characters
  C1_CNTRL = 0x20; // control characters
  C1_BLANK = 0x40; // blank characters
  C1_XDIGIT = 0x80; // other digits
  C1_ALPHA = 0x100; // any letter

// CType 2 Flag Bits.

  C2_LEFTTORIGHT = 1; // left to right
  C2_RIGHTTOLEFT = 2; // right to left
  C2_EUROPENUMBER = 3; // European number, digit
  C2_EUROPESEPARATOR = 4; // European numeric separator
  C2_EUROPETERMINATOR = 5; // European numeric terminator
  C2_ARABICNUMBER = 6; // Arabic number
  C2_COMMONSEPARATOR = 7; // common numeric separator
  C2_BLOCKSEPARATOR = 8; // block separator
  C2_SEGMENTSEPARATOR = 9; // segment separator
  C2_WHITESPACE = 10; // white space
  C2_OTHERNEUTRAL = 11; // other neutrals
  C2_NOTAPPLICABLE = 0; // no implicit directionality

// CType 3 Flag Bits.

  C3_NONSPACING = 1; // nonspacing character
  C3_DIACRITIC = 2; // diacritic mark
  C3_VOWELMARK = 4; // vowel mark
  C3_SYMBOL = 8; // symbols
  C3_NOTAPPLICABLE = 0; // ctype 3 is not applicable

// String Flags.

  NORM_IGNORECASE = 1; // ignore case
  NORM_IGNORENONSPACE = 2; // ignore nonspacing chars
  NORM_IGNORESYMBOLS = 4; // ignore symbols
  NORM_IGNOREKANATYPE = 0x10000;
  NORM_IGNOREWIDTH = 0x20000;

// Locale Independent Mapping Flags.

  MAP_FOLDCZONE = 0x10; // fold compatibility zone chars
  MAP_PRECOMPOSED = 0x20; // convert to precomposed chars
  MAP_COMPOSITE = 0x40; // convert to composite chars
  MAP_FOLDDIGITS = 0x80; // all digits to ASCII 0-9

// Locale Dependent Mapping Flags.

  LCMAP_LOWERCASE = 0x00000100;              // lower case letters
  LCMAP_UPPERCASE = 0x00000200;              // upper case letters
  LCMAP_SORTKEY = 0x00000400;                // WC sort key (normalize)
  LCMAP_BYTEREV = 0x00000800;                // byte reversal

  LCMAP_HIRAGANA = 0x00100000;               // map katakana to hiragana
  LCMAP_KATAKANA = 0x00200000;               // map hiragana to katakana
  LCMAP_HALFWIDTH = 0x00400000;              // map double byte to single byte
  LCMAP_FULLWIDTH = 0x00800000;              // map single byte to double byte

  LCMAP_LINGUISTIC_CASING = 0x01000000;      // use linguistic rules for casing

  LCMAP_SIMPLIFIED_CHINESE      = 0x02000000;  // map traditional chinese to simplified chinese
  LCMAP_TRADITIONAL_CHINESE     = 0x04000000;  // map simplified chinese to traditional chinese

// Locale Enumeration Flags.

  LCID_INSTALLED          = 0x00000001;  // installed locale ids
  LCID_SUPPORTED          = 0x00000002;  // supported locale ids

// Code Page Enumeration Flags.

  CP_INSTALLED            = 0x00000001;  // installed code page ids
  CP_SUPPORTED            = 0x00000002;  // supported code page ids

  SORT_STRINGSORT = 0x1000; // use string sort method

// Code Page Default Values.

  CP_ACP                   = 0;             // default to ANSI code page
  CP_OEMCP                 = 1;             // default to OEM  code page
  CP_MACCP                 = 2;             // default to MAC  code page

  CP_UTF7                  = 65000;         // UTF-7 translation
  CP_UTF8                  = 65001;         // UTF-8 translation

// Country Codes.

  CTRY_DEFAULT = 0;
  CTRY_AUSTRALIA = 61; // Australia
  CTRY_AUSTRIA = 43; // Austria
  CTRY_BELGIUM = 0x20; // Belgium
  CTRY_BRAZIL = 55; // Brazil
  CTRY_CANADA = 2; // Canada
  CTRY_DENMARK = 45; // Denmark
  CTRY_FINLAND = 358; // Finland
  CTRY_FRANCE = 33; // France
  CTRY_GERMANY = 49; // Germany
  CTRY_ICELAND = 354; // Iceland
  CTRY_IRELAND = 353; // Ireland
  CTRY_ITALY = 39; // Italy
  CTRY_JAPAN = 81; // Japan
  CTRY_MEXICO = 52; // Mexico
  CTRY_NETHERLANDS = 31; // Netherlands
  CTRY_NEW_ZEALAND = 0x40; // New Zealand
  CTRY_NORWAY = 47; // Norway
  CTRY_PORTUGAL = 351; // Portugal
  CTRY_PRCHINA = 86; // PR China
  CTRY_SOUTH_KOREA = 82; // South Korea
  CTRY_SPAIN = 34; // Spain
  CTRY_SWEDEN = 46; // Sweden
  CTRY_SWITZERLAND = 41; // Switzerland
  CTRY_TAIWAN = 886; // Taiwan
  CTRY_UNITED_KINGDOM = 44; // United Kingdom
  CTRY_UNITED_STATES = 1; // United States

// Locale Types.  These types are used for the GetLocaleInfoW NLS API routine.

// LOCALE_NOUSEROVERRIDE is also used in GetTimeFormatW and GetDateFormatW.

  LOCALE_NOUSEROVERRIDE           = 0x80000000;   // do not use user overrides
  LOCALE_USE_CP_ACP               = 0x40000000;   // use the system ACP

  LOCALE_ILANGUAGE                = 0x00000001;   // language id
  LOCALE_SLANGUAGE                = 0x00000002;   // localized name of language
  LOCALE_SENGLANGUAGE             = 0x00001001;   // English name of language
  LOCALE_SABBREVLANGNAME          = 0x00000003;   // abbreviated language name
  LOCALE_SNATIVELANGNAME          = 0x00000004;   // native name of language

  LOCALE_ICOUNTRY                 = 0x00000005;   // country code
  LOCALE_SCOUNTRY                 = 0x00000006;   // localized name of country
  LOCALE_SENGCOUNTRY              = 0x00001002;   // English name of country
  LOCALE_SABBREVCTRYNAME          = 0x00000007;   // abbreviated country name
  LOCALE_SNATIVECTRYNAME          = 0x00000008;   // native name of country

  LOCALE_IDEFAULTLANGUAGE         = 0x00000009;   // default language id
  LOCALE_IDEFAULTCOUNTRY          = 0x0000000A;   // default country code
  LOCALE_IDEFAULTCODEPAGE         = 0x0000000B;   // default oem code page
  LOCALE_IDEFAULTANSICODEPAGE     = 0x00001004;   // default ansi code page
  LOCALE_IDEFAULTMACCODEPAGE      = 0x00001011;   // default mac code page

  LOCALE_SLIST                    = 0x0000000C;   // list item separator
  LOCALE_IMEASURE                 = 0x0000000D;   // 0 = metric, 1 = US

  LOCALE_SDECIMAL                 = 0x0000000E;   // decimal separator
  LOCALE_STHOUSAND                = 0x0000000F;   // thousand separator
  LOCALE_SGROUPING                = 0x00000010;   // digit grouping
  LOCALE_IDIGITS                  = 0x00000011;   // number of fractional digits
  LOCALE_ILZERO                   = 0x00000012;   // leading zeros for decimal
  LOCALE_INEGNUMBER               = 0x00001010;   // negative number mode
  LOCALE_SNATIVEDIGITS            = 0x00000013;   // native ascii 0-9

  LOCALE_SCURRENCY                = 0x00000014;   // local monetary symbol
  LOCALE_SINTLSYMBOL              = 0x00000015;   // intl monetary symbol
  LOCALE_SMONDECIMALSEP           = 0x00000016;   // monetary decimal separator
  LOCALE_SMONTHOUSANDSEP          = 0x00000017;   // monetary thousand separator
  LOCALE_SMONGROUPING             = 0x00000018;   // monetary grouping
  LOCALE_ICURRDIGITS              = 0x00000019;   // # local monetary digits
  LOCALE_IINTLCURRDIGITS          = 0x0000001A;   // # intl monetary digits
  LOCALE_ICURRENCY                = 0x0000001B;   // positive currency mode
  LOCALE_INEGCURR                 = 0x0000001C;   // negative currency mode

  LOCALE_SDATE                    = 0x0000001D;   // date separator
  LOCALE_STIME                    = 0x0000001E;   // time separator
  LOCALE_SSHORTDATE               = 0x0000001F;   // short date format string
  LOCALE_SLONGDATE                = 0x00000020;   // long date format string
  LOCALE_STIMEFORMAT              = 0x00001003;   // time format string
  LOCALE_IDATE                    = 0x00000021;   // short date format ordering
  LOCALE_ILDATE                   = 0x00000022;   // long date format ordering
  LOCALE_ITIME                    = 0x00000023;   // time format specifier
  LOCALE_ITIMEMARKPOSN            = 0x00001005;   // time marker position
  LOCALE_ICENTURY                 = 0x00000024;   // century format specifier (short date)
  LOCALE_ITLZERO                  = 0x00000025;   // leading zeros in time field
  LOCALE_IDAYLZERO                = 0x00000026;   // leading zeros in day field (short date)
  LOCALE_IMONLZERO                = 0x00000027;   // leading zeros in month field (short date)
  LOCALE_S1159                    = 0x00000028;   // AM designator
  LOCALE_S2359                    = 0x00000029;   // PM designator

  LOCALE_ICALENDARTYPE            = 0x00001009;   // type of calendar specifier
  LOCALE_IOPTIONALCALENDAR        = 0x0000100B;   // additional calendar types specifier
  LOCALE_IFIRSTDAYOFWEEK          = 0x0000100C;   // first day of week specifier
  LOCALE_IFIRSTWEEKOFYEAR         = 0x0000100D;   // first week of year specifier

  LOCALE_SDAYNAME1                = 0x0000002A;   // long name for Monday
  LOCALE_SDAYNAME2                = 0x0000002B;   // long name for Tuesday
  LOCALE_SDAYNAME3                = 0x0000002C;   // long name for Wednesday
  LOCALE_SDAYNAME4                = 0x0000002D;   // long name for Thursday
  LOCALE_SDAYNAME5                = 0x0000002E;   // long name for Friday
  LOCALE_SDAYNAME6                = 0x0000002F;   // long name for Saturday
  LOCALE_SDAYNAME7                = 0x00000030;   // long name for Sunday
  LOCALE_SABBREVDAYNAME1          = 0x00000031;   // abbreviated name for Monday
  LOCALE_SABBREVDAYNAME2          = 0x00000032;   // abbreviated name for Tuesday
  LOCALE_SABBREVDAYNAME3          = 0x00000033;   // abbreviated name for Wednesday
  LOCALE_SABBREVDAYNAME4          = 0x00000034;   // abbreviated name for Thursday
  LOCALE_SABBREVDAYNAME5          = 0x00000035;   // abbreviated name for Friday
  LOCALE_SABBREVDAYNAME6          = 0x00000036;   // abbreviated name for Saturday
  LOCALE_SABBREVDAYNAME7          = 0x00000037;   // abbreviated name for Sunday
  LOCALE_SMONTHNAME1              = 0x00000038;   // long name for January
  LOCALE_SMONTHNAME2              = 0x00000039;   // long name for February
  LOCALE_SMONTHNAME3              = 0x0000003A;   // long name for March
  LOCALE_SMONTHNAME4              = 0x0000003B;   // long name for April
  LOCALE_SMONTHNAME5              = 0x0000003C;   // long name for May
  LOCALE_SMONTHNAME6              = 0x0000003D;   // long name for June
  LOCALE_SMONTHNAME7              = 0x0000003E;   // long name for July
  LOCALE_SMONTHNAME8              = 0x0000003F;   // long name for August
  LOCALE_SMONTHNAME9              = 0x00000040;   // long name for September
  LOCALE_SMONTHNAME10             = 0x00000041;   // long name for October
  LOCALE_SMONTHNAME11             = 0x00000042;   // long name for November
  LOCALE_SMONTHNAME12             = 0x00000043;   // long name for December
  LOCALE_SMONTHNAME13             = 0x0000100E;   // long name for 13th month (if exists)
  LOCALE_SABBREVMONTHNAME1        = 0x00000044;   // abbreviated name for January
  LOCALE_SABBREVMONTHNAME2        = 0x00000045;   // abbreviated name for February
  LOCALE_SABBREVMONTHNAME3        = 0x00000046;   // abbreviated name for March
  LOCALE_SABBREVMONTHNAME4        = 0x00000047;   // abbreviated name for April
  LOCALE_SABBREVMONTHNAME5        = 0x00000048;   // abbreviated name for May
  LOCALE_SABBREVMONTHNAME6        = 0x00000049;   // abbreviated name for June
  LOCALE_SABBREVMONTHNAME7        = 0x0000004A;   // abbreviated name for July
  LOCALE_SABBREVMONTHNAME8        = 0x0000004B;   // abbreviated name for August
  LOCALE_SABBREVMONTHNAME9        = 0x0000004C;   // abbreviated name for September
  LOCALE_SABBREVMONTHNAME10       = 0x0000004D;   // abbreviated name for October
  LOCALE_SABBREVMONTHNAME11       = 0x0000004E;   // abbreviated name for November
  LOCALE_SABBREVMONTHNAME12       = 0x0000004F;   // abbreviated name for December
  LOCALE_SABBREVMONTHNAME13       = 0x0000100F;   // abbreviated name for 13th month (if exists)

  LOCALE_SPOSITIVESIGN            = 0x00000050;   // positive sign
  LOCALE_SNEGATIVESIGN            = 0x00000051;   // negative sign
  LOCALE_IPOSSIGNPOSN             = 0x00000052;   // positive sign position
  LOCALE_INEGSIGNPOSN             = 0x00000053;   // negative sign position
  LOCALE_IPOSSYMPRECEDES          = 0x00000054;   // mon sym precedes pos amt
  LOCALE_IPOSSEPBYSPACE           = 0x00000055;   // mon sym sep by space from pos amt
  LOCALE_INEGSYMPRECEDES          = 0x00000056;   // mon sym precedes neg amt
  LOCALE_INEGSEPBYSPACE           = 0x00000057;   // mon sym sep by space from neg amt

  LOCALE_FONTSIGNATURE            = 0x00000058;   // font signature
  LOCALE_SISO639LANGNAME          = 0x00000059;   // ISO abbreviated language name
  LOCALE_SISO3166CTRYNAME         = 0x0000005A;   // ISO abbreviated country name


// Time Flags for GetTimeFormatW.

  TIME_NOMINUTESORSECONDS = 1; // do not use minutes or seconds
  TIME_NOSECONDS = 2; // do not use seconds
  TIME_NOTIMEMARKER = 4; // do not use time marker
  TIME_FORCE24HOURFORMAT = 8; // always use 24 hour format

// Date Flags for GetDateFormatW.

  DATE_SHORTDATE = 1; // use short date picture
  DATE_LONGDATE = 2; // use long date picture
  DATE_USE_ALT_CALENDAR = 4;   // use alternate calendar (if any)

// Calendar Types.  These types are used for the GetALTCalendarInfoW NLS API routine.

  CAL_ICALINTVALUE = 1;   // calendar type
  CAL_SCALNAME = 2;   // native name of calendar
  CAL_IYEAROFFSETRANGE = 3;   // starting years of eras
  CAL_SERASTRING = 4;   // era name for IYearOffsetRanges
  CAL_SSHORTDATE = 5;   // short date format string
  CAL_SLONGDATE = 6;   // long date format string
  CAL_SDAYNAME1 = 7;   // native name for Monday
  CAL_SDAYNAME2 = 8;   // native name for Tuesday
  CAL_SDAYNAME3 = 9;   // native name for Wednesday
  CAL_SDAYNAME4 = 10;   // native name for Thursday
  CAL_SDAYNAME5 = 11;   // native name for Friday
  CAL_SDAYNAME6 = 12;   // native name for Saturday
  CAL_SDAYNAME7 = 13;   // native name for Sunday
  CAL_SABBREVDAYNAME1 = 14;   // abbreviated name for Monday
  CAL_SABBREVDAYNAME2 = 15;   // abbreviated name for Tuesday
  CAL_SABBREVDAYNAME3 = 0x10;   // abbreviated name for Wednesday
  CAL_SABBREVDAYNAME4 = 17;   // abbreviated name for Thursday
  CAL_SABBREVDAYNAME5 = 18;   // abbreviated name for Friday
  CAL_SABBREVDAYNAME6 = 19;   // abbreviated name for Saturday
  CAL_SABBREVDAYNAME7 = 20;   // abbreviated name for Sunday
  CAL_SMONTHNAME1 = 21;   // native name for January
  CAL_SMONTHNAME2 = 22;   // native name for February
  CAL_SMONTHNAME3 = 23;   // native name for March
  CAL_SMONTHNAME4 = 24;   // native name for April
  CAL_SMONTHNAME5 = 25;   // native name for May
  CAL_SMONTHNAME6 = 26;   // native name for June
  CAL_SMONTHNAME7 = 27;   // native name for July
  CAL_SMONTHNAME8 = 28;   // native name for August
  CAL_SMONTHNAME9 = 29;   // native name for September
  CAL_SMONTHNAME10 = 30;   // native name for October
  CAL_SMONTHNAME11 = 31;   // native name for November
  CAL_SMONTHNAME12 = 0x20;   // native name for December
  CAL_SMONTHNAME13 = 33;   // native name for 13th month (if any)
  CAL_SABBREVMONTHNAME1 = 34;   // abbreviated name for January
  CAL_SABBREVMONTHNAME2 = 35;   // abbreviated name for February
  CAL_SABBREVMONTHNAME3 = 36;   // abbreviated name for March
  CAL_SABBREVMONTHNAME4 = 37;   // abbreviated name for April
  CAL_SABBREVMONTHNAME5 = 38;   // abbreviated name for May
  CAL_SABBREVMONTHNAME6 = 39;   // abbreviated name for June
  CAL_SABBREVMONTHNAME7 = 40;   // abbreviated name for July
  CAL_SABBREVMONTHNAME8 = 41;   // abbreviated name for August
  CAL_SABBREVMONTHNAME9 = 42;   // abbreviated name for September
  CAL_SABBREVMONTHNAME10 = 43;   // abbreviated name for October
  CAL_SABBREVMONTHNAME11 = 44;   // abbreviated name for November
  CAL_SABBREVMONTHNAME12 = 45;   // abbreviated name for December
  CAL_SABBREVMONTHNAME13 = 46;   // abbreviated name for 13th month (if any)

// Calendar Enumeration Value.

  ENUM_ALL_CALENDARS = 0xFFFFFFFF;   // enumerate all calendars

// Calendar ID Values.

  CAL_GREGORIAN = 1;           // Gregorian (localized) calendar
  CAL_GREGORIAN_US = 2;        // Gregorian (U.S.) calendar
  CAL_JAPAN = 3;               // Japanese Emperor Era calendar
  CAL_TAIWAN = 4;              // Republic of China Era calendar
  CAL_KOREA = 5;               // Korean Tangun Era calendar
  CAL_HIJRI = 6;               // Hijri (Arabic Lunar) calendar
  CAL_THAI = 7;                // Thai calendar
  CAL_HEBREW = 8;              // Hebrew calendar


type
  LCTYPE = cardinal;   // Locale type constant.
  CALTYPE = cardinal;  // Calendar type constant.
  CALID = cardinal;    // Calendar ID.

  TCPINFO = record
    MaxCharSize: cardinal;                       // max length (bytes) of a char
    DefaultChar: array[0..MAX_DEFAULTCHAR - 1] of byte; // default character
    LeadByte: array[0..MAX_LEADBYTES - 1] of byte;      // lead byte ranges
  end;
  pTCPINFO = pointer to TCPINFO;

type
  NUMBERFMT =record
    NumDigits: cardinal;        // number of decimal digits
    LeadingZero: cardinal;      // if leading zero in decimal fields
    Grouping: cardinal;         // group size left of decimal
    lpDecimalSep: pstr;   // ptr to decimal separator string
    lpThousandSep: pstr;  // ptr to thousand separator string
    NegativeOrder: cardinal;    // negative number ordering
  end;
  pNUMBERFMT = pointer to NUMBERFMT;

  CURRENCYFMT = record
    NumDigits: cardinal;           // number of decimal digits
    LeadingZero: cardinal;         // if leading zero in decimal fields
    Grouping: cardinal;            // group size left of decimal
    lpDecimalSep: pstr;      // ptr to decimal separator string
    lpThousandSep: pstr;     // ptr to thousand separator string
    NegativeOrder: cardinal;       // negative currency ordering
    PositiveOrder: cardinal;       // positive currency ordering
    lpCurrencySymbol: pstr;  // ptr to currency symbol string
  end;
  pCURRENCYFMT = pointer to CURRENCYFMT;

// Code Page Dependent APIs.

procedure IsValidCodePage(CodePage: cardinal): boolean;
procedure GetACP(): cardinal;
procedure GetOEMCP(): cardinal;
procedure GetCPInfo(CodePage: cardinal; lpCPInfo: pTCPINFO): boolean;
procedure IsDBCSLeadByte(TestChar: byte): boolean;
procedure IsDBCSLeadByteEx(CodePage: cardinal; TestChar: byte): boolean;
procedure MultiByteToWideChar(CodePage: cardinal; dwFlags: cardinal; lpMultiByteStr: pstr; cchMultiByte: integer; lpWideCharStr: address; cchWideChar: integer): integer;
procedure WideCharToMultiByte(CodePage: cardinal; dwFlags: cardinal; lpWideCharStr: address; cchWideChar: integer; lpMultiByteStr: pstr;  cchMultiByte: integer; lpDefaultChar: pstr; lpUsedDefaultChar: pBOOL): integer;

// Locale Dependent APIs.

procedure CompareString ascii(Locale: cardinal; dwCmpFlags: cardinal; lpString1: pstr; cchCount1: integer; lpString2: pstr; cchCount2: integer): integer;
procedure LCMapString ascii(Locale: cardinal; dwMapFlags: cardinal; lpSrcStr: pstr; cchSrc: integer; lpDestStr: pstr; cchDest: integer): integer;
procedure GetLocaleInfo ascii(Locale: cardinal; LCType: LCTYPE; lpLCData: pstr; cchData: integer): integer;
procedure SetLocaleInfo ascii(Locale: cardinal; LCType: LCTYPE; lpLCData: pstr): boolean;
procedure GetTimeFormat ascii(Locale: cardinal; dwFlags: cardinal; lpTime: pSYSTEMTIME; lpFormat: pstr; lpTimeStr: pstr; cchTime: integer): integer;
procedure GetDateFormat ascii(Locale: cardinal; dwFlags: cardinal; lpDate: pSYSTEMTIME; lpFormat: pstr; lpDateStr: pstr; cchDate: integer): integer;
procedure GetNumberFormat ascii(Locale: cardinal; dwFlags: cardinal; lpValue: pstr; lpFormat: pNUMBERFMT; lpNumberStr: pstr; cchNumber: integer): integer;
procedure GetCurrencyFormat ascii(Locale: cardinal; dwFlags: cardinal; lpValue: pstr; lpFormat: pCURRENCYFMT; lpCurrencyStr: pstr; cchCurrency: integer): integer;
procedure EnumCalendarInfo ascii(lpCalInfoEnumProc: address; Locale: cardinal; Calendar: CALID; CalType: CALTYPE): boolean;
procedure EnumTimeFormats ascii(lpTimeFmtEnumProc: address; Locale: cardinal; dwFlags: cardinal): boolean;
procedure EnumDateFormats ascii(lpDateFmtEnumProc: address; Locale: cardinal; dwFlags: cardinal): boolean;
procedure IsValidLocale(Locale: cardinal; dwFlags: cardinal): boolean;
procedure ConvertDefaultLocale(Locale: cardinal): cardinal;
procedure GetThreadLocale(): cardinal;
procedure SetThreadLocale(Locale: cardinal): boolean;
procedure GetSystemDefaultLangID(): cardinal;
procedure GetUserDefaultLangID(): cardinal;
procedure GetSystemDefaultcardinal(): cardinal;
procedure GetUserDefaultcardinal(): cardinal;

// Locale Independent APIs.

procedure GetStringTypeEx ascii(Locale: cardinal; dwInfoType: cardinal; lpSrcStr: pstr; cchSrc: integer; lpCharType:address): boolean;
procedure GetStringType ascii(Locale: cardinal; dwInfoType: cardinal; lpSrcStr: pstr; cchSrc: boolean; lpCharType:address): boolean;
procedure FoldString ascii(dwMapFlags: cardinal; lpSrcStr: pstr; cchSrc: integer; lpDestStr: pstr; cchDest: integer): integer;
procedure EnumSystemLocales ascii(lpLocaleEnumProc: address; dwFlags: cardinal): boolean;
procedure EnumSystemCodePages ascii(lpCodePageEnumProc: address; dwFlags: cardinal): boolean;

//========================================================================
//                          ���� � ������� ������ User32
//========================================================================

from User32;

type pMENUTEMPLATE=address;
const RT_CURSOR=0x00000001;
const RT_BITMAP=0x00000002;
const RT_ICON=0x00000003;
const RT_MENU=0x00000004;
const RT_DIALOG=0x00000005;
const RT_STRING=0x00000006;
const RT_FONTDIR=0x00000007;
const RT_FONT=0x00000008;
const RT_ACCELERATOR=0x00000009;
const RT_RCDATA=0x0000000A;
const RT_MESSAGETABLE=0x0000000B;
const RT_GROUP_CURSOR=0x0000000C;
const RT_GROUP_ICON=0x0000000E;
const RT_VERSION=0x00000010;
const RT_DLGINCLUDE=0x00000011;
const RT_PLUGPLAY=0x00000013;
const RT_VXD=0x00000014;
const RT_ANICURSOR=0x00000015;
const RT_ANIICON=0x00000016;

procedure wvsprintf ascii(pstr, pstr, address):integer;
procedure wsprintf ascii(pstr, pstr, cardinal):integer;

const SB_HORZ=0x00000000;
const SB_VERT=0x00000001;
const SB_CTL=0x00000002;
const SB_BOTH=0x00000003;
const SB_LINEUP=0x00000000;
const SB_LINELEFT=0x00000000;
const SB_LINEDOWN=0x00000001;
const SB_LINERIGHT=0x00000001;
const SB_PAGEUP=0x00000002;
const SB_PAGELEFT=0x00000002;
const SB_PAGEDOWN=0x00000003;
const SB_PAGERIGHT=0x00000003;
const SB_THUMBPOSITION=0x00000004;
const SB_THUMBTRACK=0x00000005;
const SB_TOP=0x00000006;
const SB_LEFT=0x00000006;
const SB_BOTTOM=0x00000007;
const SB_RIGHT=0x00000007;
const SB_ENDSCROLL=0x00000008;
const SW_HIDE=0x00000000;
const SW_SHOWNORMAL=0x00000001;
const SW_NORMAL=0x00000001;
const SW_SHOWMINIMIZED=0x00000002;
const SW_SHOWMAXIMIZED=0x00000003;
const SW_MAXIMIZE=0x00000003;
const SW_SHOWNOACTIVATE=0x00000004;
const SW_SHOW=0x00000005;
const SW_MINIMIZE=0x00000006;
const SW_SHOWMINNOACTIVE=0x00000007;
const SW_SHOWNA=0x00000008;
const SW_RESTORE=0x00000009;
const SW_SHOWDEFAULT=0x0000000A;
const SW_MAX=0x0000000A;
const HIDE_WINDOW=0x00000000;
const SHOW_OPENWINDOW=0x00000001;
const SHOW_ICONWINDOW=0x00000002;
const SHOW_FULLSCREEN=0x00000003;
const SHOW_OPENNOACTIVATE=0x00000004;
const SW_PARENTCLOSING=0x00000001;
const SW_OTHERZOOM=0x00000002;
const SW_PARENTOPENING=0x00000003;
const SW_OTHERUNZOOM=0x00000004;
const KF_EXTENDED=0x00000100;
const KF_DLGMODE=0x00000800;
const KF_MENUMODE=0x00001000;
const KF_ALTDOWN=0x00002000;
const KF_REPEAT=0x00004000;
const KF_UP=0x00008000;
const VK_LBUTTON=0x00000001;
const VK_RBUTTON=0x00000002;
const VK_CANCEL=0x00000003;
const VK_MBUTTON=0x00000004;
const VK_BACK=0x00000008;
const VK_TAB=0x00000009;
const VK_CLEAR=0x0000000C;
const VK_RETURN=0x0000000D;
const VK_SHIFT=0x00000010;
const VK_CONTROL=0x00000011;
const VK_MENU=0x00000012;
const VK_PAUSE=0x00000013;
const VK_CAPITAL=0x00000014;
const VK_ESCAPE=0x0000001B;
const VK_SPACE=0x00000020;
const VK_PRIOR=0x00000021;
const VK_NEXT=0x00000022;
const VK_END=0x00000023;
const VK_HOME=0x00000024;
const VK_LEFT=0x00000025;
const VK_UP=0x00000026;
const VK_RIGHT=0x00000027;
const VK_DOWN=0x00000028;
const VK_SELECT=0x00000029;
const VK_PRINT=0x0000002A;
const VK_EXECUTE=0x0000002B;
const VK_SNAPSHOT=0x0000002C;
const VK_INSERT=0x0000002D;
const VK_DELETE=0x0000002E;
const VK_HELP=0x0000002F;
const VK_LWIN=0x0000005B;
const VK_RWIN=0x0000005C;
const VK_APPS=0x0000005D;
const VK_NUMPAD0=0x00000060;
const VK_NUMPAD1=0x00000061;
const VK_NUMPAD2=0x00000062;
const VK_NUMPAD3=0x00000063;
const VK_NUMPAD4=0x00000064;
const VK_NUMPAD5=0x00000065;
const VK_NUMPAD6=0x00000066;
const VK_NUMPAD7=0x00000067;
const VK_NUMPAD8=0x00000068;
const VK_NUMPAD9=0x00000069;
const VK_MULTIPLY=0x0000006A;
const VK_ADD=0x0000006B;
const VK_SEPARATOR=0x0000006C;
const VK_SUBTRACT=0x0000006D;
const VK_DECIMAL=0x0000006E;
const VK_DIVIDE=0x0000006F;
const VK_F1=0x00000070;
const VK_F2=0x00000071;
const VK_F3=0x00000072;
const VK_F4=0x00000073;
const VK_F5=0x00000074;
const VK_F6=0x00000075;
const VK_F7=0x00000076;
const VK_F8=0x00000077;
const VK_F9=0x00000078;
const VK_F10=0x00000079;
const VK_F11=0x0000007A;
const VK_F12=0x0000007B;
const VK_F13=0x0000007C;
const VK_F14=0x0000007D;
const VK_F15=0x0000007E;
const VK_F16=0x0000007F;
const VK_F17=0x00000080;
const VK_F18=0x00000081;
const VK_F19=0x00000082;
const VK_F20=0x00000083;
const VK_F21=0x00000084;
const VK_F22=0x00000085;
const VK_F23=0x00000086;
const VK_F24=0x00000087;
const VK_NUMLOCK=0x00000090;
const VK_SCROLL=0x00000091;
const VK_LSHIFT=0x000000A0;
const VK_RSHIFT=0x000000A1;
const VK_LCONTROL=0x000000A2;
const VK_RCONTROL=0x000000A3;
const VK_LMENU=0x000000A4;
const VK_RMENU=0x000000A5;
const VK_PROCESSKEY=0x000000E5;
const VK_ATTN=0x000000F6;
const VK_CRSEL=0x000000F7;
const VK_EXSEL=0x000000F8;
const VK_EREOF=0x000000F9;
const VK_PLAY=0x000000FA;
const VK_ZOOM=0x000000FB;
const VK_NONAME=0x000000FC;
const VK_PA1=0x000000FD;
const VK_OEM_CLEAR=0x000000FE;

const WH_MIN=-0x00000001;
const WH_MSGFILTER=-0x00000001;
const WH_JOURNALRECORD=0x00000000;
const WH_JOURNALPLAYBACK=0x00000001;
const WH_KEYBOARD=0x00000002;
const WH_GETMESSAGE=0x00000003;
const WH_CALLWNDPROC=0x00000004;
const WH_CBT=0x00000005;
const WH_SYSMSGFILTER=0x00000006;
const WH_MOUSE=0x00000007;
const WH_HARDWARE=0x00000008;
const WH_DEBUG=0x00000009;
const WH_SHELL=0x0000000A;
const WH_FOREGROUNDIDLE=0x0000000B;
const WH_CALLWNDPROCRET=0x0000000C;
const WH_MAX=0x0000000C;
const WH_MINHOOK=WH_MIN;
const WH_MAXHOOK=WH_MAX;

const HC_ACTION=0x00000000;
const HC_GETNEXT=0x00000001;
const HC_SKIP=0x00000002;
const HC_NOREMOVE=0x00000003;
const HC_NOREM=HC_NOREMOVE;
const HC_SYSMODALON=0x00000004;
const HC_SYSMODALOFF=0x00000005;

const MSGF_DIALOGBOX=0x00000000;
const MSGF_MESSAGEBOX=0x00000001;
const MSGF_MENU=0x00000002;
const MSGF_MOVE=0x00000003;
const MSGF_SIZE=0x00000004;
const MSGF_SCROLLBAR=0x00000005;
const MSGF_NEXTWINDOW=0x00000006;
const MSGF_MAINLOOP=0x00000008;
const MSGF_MAX=0x00000008;
const MSGF_USER=0x00001000;
const HSHELL_WINDOWCREATED=0x00000001;
const HSHELL_WINDOWDESTROYED=0x00000002;
const HSHELL_ACTIVATESHELLWINDOW=0x00000003;
const HSHELL_WINDOWACTIVATED=0x00000004;
const HSHELL_GETMINRECT=0x00000005;
const HSHELL_REDRAW=0x00000006;
const HSHELL_TASKMAN=0x00000007;
const HSHELL_LANGUAGE=0x00000008;
type EVENTMSG=record
       message:cardinal;
       paramL:cardinal;
       paramH:cardinal;
       time:cardinal;
       hwnd:HWND;
     end;
     pEVENTMSG=pointer to EVENTMSG;

type CWPSTRUCT=record
       lParam:cardinal;
       wParam:cardinal;
       message:cardinal;
       hwnd:HWND;
     end;
     pCWPSTRUCT=pointer to CWPSTRUCT;

type CWPRETSTRUCT=record
       lResult:cardinal;
       lParam:cardinal;
       wParam:cardinal;
       message:cardinal;
       hwnd:HWND;
     end;
     pCWPRETSTRUCT=pointer to CWPRETSTRUCT;

type DEBUGHOOKINFO=record
       idThread:cardinal;
       idThreadInstaller:cardinal;
       lParam:cardinal;
       wParam:cardinal;
       code:integer;
     end;
     pDEBUGHOOKINFO=pointer to DEBUGHOOKINFO;

type MOUSEHOOKSTRUCT=record
       pt:POINT;
       hwnd:HWND;
       wHitTestCode:cardinal;
       dwExtraInfo:cardinal;
     end;
     pMOUSEHOOKSTRUCT=pointer to MOUSEHOOKSTRUCT;

type HARDWAREHOOKSTRUCT=record
       hwnd:HWND;
       message:cardinal;
       wParam:cardinal;
       lParam:cardinal;
     end;
     pHARDWAREHOOKSTRUCT=pointer to HARDWAREHOOKSTRUCT;

const HKL_PREV=0x00000000;
const HKL_NEXT=0x00000001;
const KLF_ACTIVATE=0x00000001;
const KLF_SUBSTITUTE_OK=0x00000002;
const KLF_UNLOADPREVIOUS=0x00000004;
const KLF_REORDER=0x00000008;
const KLF_REPLACELANG=0x00000010;
const KLF_NOTELLSHELL=0x00000080;
const KL_NAMELENGTH=0x00000009;

procedure LoadKeyboardLayout ascii(pwszKLID:pstr; Flags:cardinal):HKL;
procedure ActivateKeyboardLayout(hkl:HKL; Flags:cardinal):HKL;
procedure UnloadKeyboardLayout(hkl:HKL):boolean;
procedure GetKeyboardLayoutName ascii(pwszKLID:pstr):boolean;
procedure GetKeyboardLayoutList(nBuff:integer; lpList:pHANDLE):integer;
procedure GetKeyboardLayout(dwLayout:cardinal):HKL;

const DESKTOP_READOBJECTS=0x00000001;
const DESKTOP_CREATEWINDOW=0x00000002;
const DESKTOP_CREATEMENU=0x00000004;
const DESKTOP_HOOKCONTROL=0x00000008;
const DESKTOP_JOURNALRECORD=0x00000010;
const DESKTOP_JOURNALPLAYBACK=0x00000020;
const DESKTOP_ENUMERATE=0x00000040;
const DESKTOP_WRITEOBJECTS=0x00000080;
const DESKTOP_SWITCHDESKTOP=0x00000100;
const DF_ALLOWOTHERACCOUNTHOOK=0x00000001;

procedure CreateDesktop ascii(lpszDesktop:pstr; lpszDevice:pstr; pDevmode:pDEVMODE; dwFlags:cardinal; dwDesiredAccess:cardinal; lpsa:pSECURITY_ATTRIBUTES):HDESK;
procedure OpenDesktop ascii(lpszDesktop:pstr; dwFlags:cardinal; fInherit:boolean; dwDesiredAccess:cardinal):HDESK;
procedure OpenInputDesktop(dwFlags:cardinal; fInherit:boolean; dwDesiredAccess:cardinal):HDESK;
procedure EnumDesktops ascii(hwinsta:HWINST; lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure EnumDesktopWindows(hDesktop:HDESK; lpfn:pPROC; lParam:cardinal):boolean;
procedure SwitchDesktop(hDesktop:HDESK):boolean;
procedure SetThreadDesktop(hDesktop:HDESK):boolean;
procedure CloseDesktop(hDesktop:HDESK):boolean;
procedure GetThreadDesktop(dwThreadId:cardinal):HDESK;

const WINSTA_ENUMDESKTOPS=0x00000001;
const WINSTA_READATTRIBUTES=0x00000002;
const WINSTA_ACCESSCLIPBOARD=0x00000004;
const WINSTA_CREATEDESKTOP=0x00000008;
const WINSTA_WRITEATTRIBUTES=0x00000010;
const WINSTA_ACCESSGLOBALATOMS=0x00000020;
const WINSTA_EXITWINDOWS=0x00000040;
const WINSTA_ENUMERATE=0x00000100;
const WINSTA_READSCREEN=0x00000200;
const WSF_VISIBLE=0x00000001;

procedure CreateWindowStation ascii(lpwinsta:pstr; dwReserved:cardinal; dwDesiredAccess:cardinal; lpsa:pSECURITY_ATTRIBUTES):HWINST;
procedure OpenWindowStation ascii(lpszWinSta:pstr; fInherit:boolean; dwDesiredAccess:cardinal):HWINST;
procedure EnumWindowStations ascii(lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure CloseWindowStation(hWinSta:HWINST):boolean;
procedure SetProcessWindowStation(hWinSta:HWINST):boolean;
procedure GetProcessWindowStation():HWINST;
procedure SetUserObjectSecurity(hObj:HANDLE; pSIRequested:pSECURITY_INFORMATION; pSIDes:pSECURITY_DESCRIPTOR):boolean;
procedure GetUserObjectSecurity(hObj:HANDLE; pSIRequested:pSECURITY_INFORMATION; pSIDes:pSECURITY_DESCRIPTOR; nLength:cardinal; lpnLengthNeeded:pCARDINAL):boolean;

const UOI_FLAGS=0x00000001;
const UOI_NAME=0x00000002;
const UOI_TYPE=0x00000003;
const UOI_USER_SID=0x00000004;
type USEROBJECTFLAGS=record
       fInherit:boolean;
       fReserved:boolean;
       dwFlags:cardinal;
     end;
     pUSEROBJECTFLAGS=pointer to USEROBJECTFLAGS;

procedure GetUserObjectInformation ascii(hObj:HANDLE; nIndex:integer; pvInfo:address; nLength:cardinal; lpnLengthNeeded:pCARDINAL):boolean;
procedure SetUserObjectInformation ascii(hObj:HANDLE; nIndex:integer; pvInfo:address; nLength:cardinal):boolean;
type WNDCLASSEX=record
       cbSize:cardinal;
       style:cardinal;
       lpfnWndProc:pPROC;
       cbClsExtra:integer;
       cbWndExtra:integer;
       hInstance:HINSTANCE;
       hIcon:HICON;
       hCursor:HCURSOR;
       hbrBackground:HBRUSH;
       lpszMenuName:pstr;
       lpszClassName:pstr;
       hIconSm:HICON;
     end;
     pWNDCLASSEX=pointer to WNDCLASSEX;

type WNDCLASS=record
       style:cardinal;
       lpfnWndProc:pPROC;
       cbClsExtra:integer;
       cbWndExtra:integer;
       hInstance:HINSTANCE;
       hIcon:HICON;
       hCursor:HCURSOR;
       hbrBackground:HBRUSH;
       lpszMenuName:pstr;
       lpszClassName:pstr;
     end;
     pWNDCLASS=pointer to WNDCLASS;

type MSG=record
       hwnd:HWND;
       message:cardinal;
       wParam:cardinal;
       lParam:cardinal;
       time:cardinal;
       pt:POINT;
     end;
     pMSG=pointer to MSG;

const GWL_WNDPROC=-0x00000004;
const GWL_HINSTANCE=-0x00000006;
const GWL_HWNDPARENT=-0x00000008;
const GWL_STYLE=-0x00000010;
const GWL_EXSTYLE=-0x00000014;
const GWL_USERDATA=-0x00000015;
const GWL_ID=-0x0000000C;
const GCL_MENUNAME=-0x00000008;
const GCL_HBRBACKGROUND=-0x0000000A;
const GCL_HCURSOR=-0x0000000C;
const GCL_HICON=-0x0000000E;
const GCL_HMODULE=-0x00000010;
const GCL_CBWNDEXTRA=-0x00000012;
const GCL_CBCLSEXTRA=-0x00000014;
const GCL_WNDPROC=-0x00000018;
const GCL_STYLE=-0x0000001A;
const GCW_ATOM=-0x00000020;
const GCL_HICONSM=-0x00000022;
const WM_NULL=0x00000000;
const WM_CREATE=0x00000001;
const WM_DESTROY=0x00000002;
const WM_MOVE=0x00000003;
const WM_SIZE=0x00000005;
const WM_ACTIVATE=0x00000006;
const WA_INACTIVE=0x00000000;
const WA_ACTIVE=0x00000001;
const WA_CLICKACTIVE=0x00000002;
const WM_SETFOCUS=0x00000007;
const WM_KILLFOCUS=0x00000008;
const WM_ENABLE=0x0000000A;
const WM_SETREDRAW=0x0000000B;
const WM_SETTEXT=0x0000000C;
const WM_GETTEXT=0x0000000D;
const WM_GETTEXTLENGTH=0x0000000E;
const WM_PAINT=0x0000000F;
const WM_CLOSE=0x00000010;
const WM_QUERYENDSESSION=0x00000011;
const WM_QUIT=0x00000012;
const WM_QUERYOPEN=0x00000013;
const WM_ERASEBKGND=0x00000014;
const WM_SYSCOLORCHANGE=0x00000015;
const WM_ENDSESSION=0x00000016;
const WM_SHOWWINDOW=0x00000018;
const WM_WININICHANGE=0x0000001A;
const WM_SETTINGCHANGE=WM_WININICHANGE;
const WM_DEVMODECHANGE=0x0000001B;
const WM_ACTIVATEAPP=0x0000001C;
const WM_FONTCHANGE=0x0000001D;
const WM_TIMECHANGE=0x0000001E;
const WM_CANCELMODE=0x0000001F;
const WM_SETCURSOR=0x00000020;
const WM_MOUSEACTIVATE=0x00000021;
const WM_CHILDACTIVATE=0x00000022;
const WM_QUEUESYNC=0x00000023;
const WM_GETMINMAXINFO=0x00000024;
type MINMAXINFO=record
       ptReserved:POINT;
       ptMaxSize:POINT;
       ptMaxPosition:POINT;
       ptMinTrackSize:POINT;
       ptMaxTrackSize:POINT;
     end;
     pMINMAXINFO=pointer to MINMAXINFO;

const WM_PAINTICON=0x00000026;
const WM_ICONERASEBKGND=0x00000027;
const WM_NEXTDLGCTL=0x00000028;
const WM_SPOOLERSTATUS=0x0000002A;
const WM_DRAWITEM=0x0000002B;
const WM_MEASUREITEM=0x0000002C;
const WM_DELETEITEM=0x0000002D;
const WM_VKEYTOITEM=0x0000002E;
const WM_CHARTOITEM=0x0000002F;
const WM_SETFONT=0x00000030;
const WM_GETFONT=0x00000031;
const WM_SETHOTKEY=0x00000032;
const WM_GETHOTKEY=0x00000033;
const WM_QUERYDRAGICON=0x00000037;
const WM_COMPAREITEM=0x00000039;
const WM_COMPACTING=0x00000041;
const WM_COMMNOTIFY=0x00000044;
const WM_WINDOWPOSCHANGING=0x00000046;
const WM_WINDOWPOSCHANGED=0x00000047;
const WM_POWER=0x00000048;
const PWR_OK=0x00000001;
const PWR_FAIL=-0x00000001;
const PWR_SUSPENDREQUEST=0x00000001;
const PWR_SUSPENDRESUME=0x00000002;
const PWR_CRITICALRESUME=0x00000003;
const WM_COPYDATA=0x0000004A;
const WM_CANCELJOURNAL=0x0000004B;
type COPYDATASTRUCT=record
       dwData:cardinal;
       cbData:cardinal;
       lpData:address;
     end;
     pCOPYDATASTRUCT=pointer to COPYDATASTRUCT;

const WM_NOTIFY=0x0000004E;
const WM_INPUTLANGCHANGEREQUEST=0x00000050;
const WM_INPUTLANGCHANGE=0x00000051;
const WM_TCARD=0x00000052;
const WM_HELP=0x00000053;
const WM_USERCHANGED=0x00000054;
const WM_NOTIFYFORMAT=0x00000055;
const NFR_ANSI=0x00000001;
const NFR_UNICODE=0x00000002;
const NF_QUERY=0x00000003;
const NF_REQUERY=0x00000004;
const WM_CONTEXTMENU=0x0000007B;
const WM_STYLECHANGING=0x0000007C;
const WM_STYLECHANGED=0x0000007D;
const WM_DISPLAYCHANGE=0x0000007E;
const WM_GETICON=0x0000007F;
const WM_SETICON=0x00000080;
const WM_NCCREATE=0x00000081;
const WM_NCDESTROY=0x00000082;
const WM_NCCALCSIZE=0x00000083;
const WM_NCHITTEST=0x00000084;
const WM_NCPAINT=0x00000085;
const WM_NCACTIVATE=0x00000086;
const WM_GETDLGCODE=0x00000087;
const WM_NCMOUSEMOVE=0x000000A0;
const WM_NCLBUTTONDOWN=0x000000A1;
const WM_NCLBUTTONUP=0x000000A2;
const WM_NCLBUTTONDBLCLK=0x000000A3;
const WM_NCRBUTTONDOWN=0x000000A4;
const WM_NCRBUTTONUP=0x000000A5;
const WM_NCRBUTTONDBLCLK=0x000000A6;
const WM_NCMBUTTONDOWN=0x000000A7;
const WM_NCMBUTTONUP=0x000000A8;
const WM_NCMBUTTONDBLCLK=0x000000A9;
const WM_KEYFIRST=0x00000100;
const WM_KEYDOWN=0x00000100;
const WM_KEYUP=0x00000101;
const WM_CHAR=0x00000102;
const WM_DEADCHAR=0x00000103;
const WM_SYSKEYDOWN=0x00000104;
const WM_SYSKEYUP=0x00000105;
const WM_SYSCHAR=0x00000106;
const WM_SYSDEADCHAR=0x00000107;
const WM_KEYLAST=0x00000108;
const WM_IME_STARTCOMPOSITION=0x0000010D;
const WM_IME_ENDCOMPOSITION=0x0000010E;
const WM_IME_COMPOSITION=0x0000010F;
const WM_IME_KEYLAST=0x0000010F;
const WM_INITDIALOG=0x00000110;
const WM_COMMAND=0x00000111;
const WM_SYSCOMMAND=0x00000112;
const WM_TIMER=0x00000113;
const WM_HSCROLL=0x00000114;
const WM_VSCROLL=0x00000115;
const WM_INITMENU=0x00000116;
const WM_INITMENUPOPUP=0x00000117;
const WM_MENUSELECT=0x0000011F;
const WM_MENUCHAR=0x00000120;
const WM_ENTERIDLE=0x00000121;
const WM_CTLCOLORMSGBOX=0x00000132;
const WM_CTLCOLOREDIT=0x00000133;
const WM_CTLCOLORLISTBOX=0x00000134;
const WM_CTLCOLORBTN=0x00000135;
const WM_CTLCOLORDLG=0x00000136;
const WM_CTLCOLORSCROLLBAR=0x00000137;
const WM_CTLCOLORSTATIC=0x00000138;
const WM_MOUSEFIRST=0x00000200;
const WM_MOUSEMOVE=0x00000200;
const WM_LBUTTONDOWN=0x00000201;
const WM_LBUTTONUP=0x00000202;
const WM_LBUTTONDBLCLK=0x00000203;
const WM_RBUTTONDOWN=0x00000204;
const WM_RBUTTONUP=0x00000205;
const WM_RBUTTONDBLCLK=0x00000206;
const WM_MBUTTONDOWN=0x00000207;
const WM_MBUTTONUP=0x00000208;
const WM_MBUTTONDBLCLK=0x00000209;
const WM_MOUSEWHEEL=0x0000020A;
const WM_MOUSELAST=0x00000209;
const WHEEL_DELTA=0x00000078;
//const WHEEL_PAGESCROLL=cardinal_MAX;
const WM_PARENTNOTIFY=0x00000210;
const MENULOOP_WINDOW=0x00000000;
const MENULOOP_POPUP=0x00000001;
const WM_ENTERMENULOOP=0x00000211;
const WM_EXITMENULOOP=0x00000212;
const WM_NEXTMENU=0x00000213;
type MDINEXTMENU=record
       hmenuIn:HMENU;
       hmenuNext:HMENU;
       hwndNext:HWND;
     end;
     pMDINEXTMENU=pointer to MDINEXTMENU;

const WM_SIZING=0x00000214;
const WM_CAPTURECHANGED=0x00000215;
const WM_MOVING=0x00000216;
const WM_POWERBROADCAST=0x00000218;
const WM_DEVICECHANGE=0x00000219;
const WM_IME_SETCONTEXT=0x00000281;
const WM_IME_NOTIFY=0x00000282;
const WM_IME_CONTROL=0x00000283;
const WM_IME_COMPOSITIONFULL=0x00000284;
const WM_IME_SELECT=0x00000285;
const WM_IME_CHAR=0x00000286;
const WM_IME_KEYDOWN=0x00000290;
const WM_IME_KEYUP=0x00000291;
const WM_MDICREATE=0x00000220;
const WM_MDIDESTROY=0x00000221;
const WM_MDIACTIVATE=0x00000222;
const WM_MDIRESTORE=0x00000223;
const WM_MDINEXT=0x00000224;
const WM_MDIMAXIMIZE=0x00000225;
const WM_MDITILE=0x00000226;
const WM_MDICASCADE=0x00000227;
const WM_MDIICONARRANGE=0x00000228;
const WM_MDIGETACTIVE=0x00000229;
const WM_MDISETMENU=0x00000230;
const WM_ENTERSIZEMOVE=0x00000231;
const WM_EXITSIZEMOVE=0x00000232;
const WM_DROPFILES=0x00000233;
const WM_MDIREFRESHMENU=0x00000234;
const WM_MOUSEHOVER=0x000002A1;
const WM_MOUSELEAVE=0x000002A3;
const WM_CUT=0x00000300;
const WM_COPY=0x00000301;
const WM_PASTE=0x00000302;
const WM_CLEAR=0x00000303;
const WM_UNDO=0x00000304;
const WM_RENDERFORMAT=0x00000305;
const WM_RENDERALLFORMATS=0x00000306;
const WM_DESTROYCLIPBOARD=0x00000307;
const WM_DRAWCLIPBOARD=0x00000308;
const WM_PAINTCLIPBOARD=0x00000309;
const WM_VSCROLLCLIPBOARD=0x0000030A;
const WM_SIZECLIPBOARD=0x0000030B;
const WM_ASKCBFORMATNAME=0x0000030C;
const WM_CHANGECBCHAIN=0x0000030D;
const WM_HSCROLLCLIPBOARD=0x0000030E;
const WM_QUERYNEWPALETTE=0x0000030F;
const WM_PALETTEISCHANGING=0x00000310;
const WM_PALETTECHANGED=0x00000311;
const WM_HOTKEY=0x00000312;
const WM_PRINT=0x00000317;
const WM_PRINTCLIENT=0x00000318;
const WM_HANDHELDFIRST=0x00000358;
const WM_HANDHELDLAST=0x0000035F;
const WM_AFXFIRST=0x00000360;
const WM_AFXLAST=0x0000037F;
const WM_PENWINFIRST=0x00000380;
const WM_PENWINLAST=0x0000038F;
const WM_APP=0x00008000;
const WM_USER=0x00000400;
const WMSZ_LEFT=0x00000001;
const WMSZ_RIGHT=0x00000002;
const WMSZ_TOP=0x00000003;
const WMSZ_TOPLEFT=0x00000004;
const WMSZ_TOPRIGHT=0x00000005;
const WMSZ_BOTTOM=0x00000006;
const WMSZ_BOTTOMLEFT=0x00000007;
const WMSZ_BOTTOMRIGHT=0x00000008;
const ST_BEGINSWP=0x00000000;
const ST_ENDSWP=0x00000001;
const HTERROR=-0x00000002;
const HTTRANSPARENT=-0x00000001;
const HTNOWHERE=0x00000000;
const HTCLIENT=0x00000001;
const HTCAPTION=0x00000002;
const HTSYSMENU=0x00000003;
const HTGROWBOX=0x00000004;
const HTSIZE=HTGROWBOX;
const HTMENU=0x00000005;
const HTHSCROLL=0x00000006;
const HTVSCROLL=0x00000007;
const HTMINBUTTON=0x00000008;
const HTMAXBUTTON=0x00000009;
const HTLEFT=0x0000000A;
const HTRIGHT=0x0000000B;
const HTTOP=0x0000000C;
const HTTOPLEFT=0x0000000D;
const HTTOPRIGHT=0x0000000E;
const HTBOTTOM=0x0000000F;
const HTBOTTOMLEFT=0x00000010;
const HTBOTTOMRIGHT=0x00000011;
const HTBORDER=0x00000012;
const HTREDUCE=HTMINBUTTON;
const HTZOOM=HTMAXBUTTON;
const HTSIZEFIRST=HTLEFT;
const HTSIZELAST=HTBOTTOMRIGHT;
const HTOBJECT=0x00000013;
const HTCLOSE=0x00000014;
const HTHELP=0x00000015;
const SMTO_NORMAL=0x00000000;
const SMTO_BLOCK=0x00000001;
const SMTO_ABORTIFHUNG=0x00000002;
const MA_ACTIVATE=0x00000001;
const MA_ACTIVATEANDEAT=0x00000002;
const MA_NOACTIVATE=0x00000003;
const MA_NOACTIVATEANDEAT=0x00000004;
const ICON_SMALL=0x00000000;
const ICON_BIG=0x00000001;
procedure RegisterWindowMessage ascii(lpString:pstr):cardinal;
const SIZE_RESTORED=0x00000000;
const SIZE_MINIMIZED=0x00000001;
const SIZE_MAXIMIZED=0x00000002;
const SIZE_MAXSHOW=0x00000003;
const SIZE_MAXHIDE=0x00000004;
const SIZENORMAL=SIZE_RESTORED;
const SIZEICONIC=SIZE_MINIMIZED;
const SIZEFULLSCREEN=SIZE_MAXIMIZED;
const SIZEZOOMSHOW=SIZE_MAXSHOW;
const SIZEZOOMHIDE=SIZE_MAXHIDE;
type WINDOWPOS=record
       hwnd:HWND;
       hwndInsertAfter:HWND;
       x:integer;
       y:integer;
       cx:integer;
       cy:integer;
       flags:cardinal;
     end;
     pWINDOWPOS=pointer to WINDOWPOS;

type NCCALCSIZE_PARAMS=record
       rgrc:array[0..2]of RECT;
       lppos:pWINDOWPOS;
     end;
     pNCCALCSIZE_PARAMS=pointer to NCCALCSIZE_PARAMS;

const WVR_ALIGNTOP=0x00000010;
const WVR_ALIGNLEFT=0x00000020;
const WVR_ALIGNBOTTOM=0x00000040;
const WVR_ALIGNRIGHT=0x00000080;
const WVR_HREDRAW=0x00000100;
const WVR_VREDRAW=0x00000200;
const WVR_REDRAW=WVR_HREDRAW|WVR_VREDRAW;
const WVR_VALIDRECTS=0x00000400;
const MK_LBUTTON=0x00000001;
const MK_RBUTTON=0x00000002;
const MK_SHIFT=0x00000004;
const MK_CONTROL=0x00000008;
const MK_MBUTTON=0x00000010;
const TME_HOVER=0x00000001;
const TME_LEAVE=0x00000002;
const TME_QUERY=0x40000000;
const TME_CANCEL=0x80000000;
const HOVER_DEFAULT=0xFFFFFFFF;
type TRACKMOUSEEVENT=record
       cbSize:cardinal;
       dwFlags:cardinal;
       hwndTrack:HWND;
       dwHoverTime:cardinal;
     end;
     pTRACKMOUSEEVENT=pointer to TRACKMOUSEEVENT;

const WS_OVERLAPPED=0x00000000;
const WS_POPUP=0x80000000;
const WS_CHILD=0x40000000;
const WS_MINIMIZE=0x20000000;
const WS_VISIBLE=0x10000000;
const WS_DISABLED=0x08000000;
const WS_CLIPSIBLINGS=0x04000000;
const WS_CLIPCHILDREN=0x02000000;
const WS_MAXIMIZE=0x01000000;
const WS_CAPTION=0x00C00000;
const WS_BORDER=0x00800000;
const WS_DLGFRAME=0x00400000;
const WS_VSCROLL=0x00200000;
const WS_HSCROLL=0x00100000;
const WS_SYSMENU=0x00080000;
const WS_THICKFRAME=0x00040000;
const WS_GROUP=0x00020000;
const WS_TABSTOP=0x00010000;
const WS_MINIMIZEBOX=0x00020000;
const WS_MAXIMIZEBOX=0x00010000;
const WS_TILED=WS_OVERLAPPED;
const WS_ICONIC=WS_MINIMIZE;
const WS_SIZEBOX=WS_THICKFRAME;
const WS_OVERLAPPEDWINDOW=WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_THICKFRAME|WS_MINIMIZEBOX|WS_MAXIMIZEBOX;
const WS_POPUPWINDOW=WS_POPUP|WS_BORDER|WS_SYSMENU;
const WS_CHILDWINDOW=WS_CHILD;
const WS_TILEDWINDOW=WS_OVERLAPPEDWINDOW;
const WS_EX_DLGMODALFRAME=0x00000001;
const WS_EX_NOPARENTNOTIFY=0x00000004;
const WS_EX_TOPMOST=0x00000008;
const WS_EX_ACCEPTFILES=0x00000010;
const WS_EX_TRANSPARENT=0x00000020;
const WS_EX_MDICHILD=0x00000040;
const WS_EX_TOOLWINDOW=0x00000080;
const WS_EX_WINDOWEDGE=0x00000100;
const WS_EX_CLIENTEDGE=0x00000200;
const WS_EX_CONTEXTHELP=0x00000400;
const WS_EX_RIGHT=0x00001000;
const WS_EX_LEFT=0x00000000;
const WS_EX_RTLREADING=0x00002000;
const WS_EX_LTRREADING=0x00000000;
const WS_EX_LEFTSCROLLBAR=0x00004000;
const WS_EX_RIGHTSCROLLBAR=0x00000000;
const WS_EX_CONTROLPARENT=0x00010000;
const WS_EX_STATICEDGE=0x00020000;
const WS_EX_APPWINDOW=0x00040000;
const WS_EX_OVERLAPPEDWINDOW=WS_EX_WINDOWEDGE|WS_EX_CLIENTEDGE;
const WS_EX_PALETTEWINDOW=WS_EX_WINDOWEDGE|WS_EX_TOOLWINDOW|WS_EX_TOPMOST;
const CS_VREDRAW=0x00000001;
const CS_HREDRAW=0x00000002;
const CS_KEYCVTWINDOW=0x00000004;
const CS_DBLCLKS=0x00000008;
const CS_OWNDC=0x00000020;
const CS_CLASSDC=0x00000040;
const CS_PARENTDC=0x00000080;
const CS_NOKEYCVT=0x00000100;
const CS_NOCLOSE=0x00000200;
const CS_SAVEBITS=0x00000800;
const CS_BYTEALIGNCLIENT=0x00001000;
const CS_BYTEALIGNWINDOW=0x00002000;
const CS_GLOBALCLASS=0x00004000;
const CS_IME=0x00010000;
const PRF_CHECKVISIBLE=0x00000001;
const PRF_NONCLIENT=0x00000002;
const PRF_CLIENT=0x00000004;
const PRF_ERASEBKGND=0x00000008;
const PRF_CHILDREN=0x00000010;
const PRF_OWNED=0x00000020;
const BDR_RAISEDOUTER=0x00000001;
const BDR_SUNKENOUTER=0x00000002;
const BDR_RAISEDINNER=0x00000004;
const BDR_SUNKENINNER=0x00000008;
const BDR_OUTER=0x00000003;
const BDR_INNER=0x0000000C;
const BDR_RAISED=0x00000005;
const BDR_SUNKEN=0x0000000A;
const EDGE_RAISED=BDR_RAISEDOUTER|BDR_RAISEDINNER;
const EDGE_SUNKEN=BDR_SUNKENOUTER|BDR_SUNKENINNER;
const EDGE_ETCHED=BDR_SUNKENOUTER|BDR_RAISEDINNER;
const EDGE_BUMP=BDR_RAISEDOUTER|BDR_SUNKENINNER;
const BF_LEFT=0x00000001;
const BF_TOP=0x00000002;
const BF_RIGHT=0x00000004;
const BF_BOTTOM=0x00000008;
const BF_TOPLEFT=BF_TOP|BF_LEFT;
const BF_TOPRIGHT=BF_TOP|BF_RIGHT;
const BF_BOTTOMLEFT=BF_BOTTOM|BF_LEFT;
const BF_BOTTOMRIGHT=BF_BOTTOM|BF_RIGHT;
const BF_RECT=BF_LEFT|BF_TOP|BF_RIGHT|BF_BOTTOM;
const BF_DIAGONAL=0x00000010;
const BF_DIAGONAL_ENDTOPRIGHT=BF_DIAGONAL|BF_TOP|BF_RIGHT;
const BF_DIAGONAL_ENDTOPLEFT=BF_DIAGONAL|BF_TOP|BF_LEFT;
const BF_DIAGONAL_ENDBOTTOMLEFT=BF_DIAGONAL|BF_BOTTOM|BF_LEFT;
const BF_DIAGONAL_ENDBOTTOMRIGHT=BF_DIAGONAL|BF_BOTTOM|BF_RIGHT;
const BF_MIDDLE=0x00000800;
const BF_SOFT=0x00001000;
const BF_ADJUST=0x00002000;
const BF_FLAT=0x00004000;
const BF_MONO=0x00008000;

procedure DrawEdge(hdc:HDC; qrc:pRECT; edge:cardinal; grfFlags:cardinal):boolean;

const DFC_CAPTION=0x00000001;
const DFC_MENU=0x00000002;
const DFC_SCROLL=0x00000003;
const DFC_BUTTON=0x00000004;
const DFCS_CAPTIONCLOSE=0x00000000;
const DFCS_CAPTIONMIN=0x00000001;
const DFCS_CAPTIONMAX=0x00000002;
const DFCS_CAPTIONRESTORE=0x00000003;
const DFCS_CAPTIONHELP=0x00000004;
const DFCS_MENUARROW=0x00000000;
const DFCS_MENUCHECK=0x00000001;
const DFCS_MENUBULLET=0x00000002;
const DFCS_MENUARROWRIGHT=0x00000004;
const DFCS_SCROLLUP=0x00000000;
const DFCS_SCROLLDOWN=0x00000001;
const DFCS_SCROLLLEFT=0x00000002;
const DFCS_SCROLLRIGHT=0x00000003;
const DFCS_SCROLLCOMBOBOX=0x00000005;
const DFCS_SCROLLSIZEGRIP=0x00000008;
const DFCS_SCROLLSIZEGRIPRIGHT=0x00000010;
const DFCS_BUTTONCHECK=0x00000000;
const DFCS_BUTTONRADIOIMAGE=0x00000001;
const DFCS_BUTTONRADIOMASK=0x00000002;
const DFCS_BUTTONRADIO=0x00000004;
const DFCS_BUTTON3STATE=0x00000008;
const DFCS_BUTTONPUSH=0x00000010;
const DFCS_INACTIVE=0x00000100;
const DFCS_PUSHED=0x00000200;
const DFCS_CHECKED=0x00000400;
const DFCS_ADJUSTRECT=0x00002000;
const DFCS_FLAT=0x00004000;
const DFCS_MONO=0x00008000;

procedure DrawFrameControl(HDC, pRECT, cardinal, cardinal):boolean;

const DC_ACTIVE=0x00000001;
const DC_SMALLCAP=0x00000002;
const DC_ICON=0x00000004;
const DC_TEXT=0x00000008;
const DC_INBUTTON=0x00000010;

procedure DrawCaption(HWND, HDC, pRECT, cardinal):boolean;

const IDANI_OPEN=0x00000001;
const IDANI_CLOSE=0x00000002;
const IDANI_CAPTION=0x00000003;

procedure DrawAnimatedRects(hwnd:HWND; idAni:integer; lprcFrom:pRECT; lprcTo:pRECT):boolean;

const CF_TEXT=0x00000001;
const CF_BITMAP=0x00000002;
const CF_METAFILEPICT=0x00000003;
const CF_SYLK=0x00000004;
const CF_DIF=0x00000005;
const CF_TIFF=0x00000006;
const CF_OEMTEXT=0x00000007;
const CF_DIB=0x00000008;
const CF_PALETTE=0x00000009;
const CF_PENDATA=0x0000000A;
const CF_RIFF=0x0000000B;
const CF_WAVE=0x0000000C;
const CF_UNICODETEXT=0x0000000D;
const CF_ENHMETAFILE=0x0000000E;
const CF_HDROP=0x0000000F;
const CF_LOCALE=0x00000010;
const CF_MAX=0x00000011;
const CF_OWNERDISPLAY=0x00000080;
const CF_DSPTEXT=0x00000081;
const CF_DSPBITMAP=0x00000082;
const CF_DSPMETAFILEPICT=0x00000083;
const CF_DSPENHMETAFILE=0x0000008E;
const CF_PRIVATEFIRST=0x00000200;
const CF_PRIVATELAST=0x000002FF;
const CF_GDIOBJFIRST=0x00000300;
const CF_GDIOBJLAST=0x000003FF;
const FVIRTKEY=1;
const FNOINVERT=0x00000002;
const FSHIFT=0x00000004;
const FCONTROL=0x00000008;
const FALT=0x00000010;
type ACCEL=record
       fVirt:byte;
       key:word;
       cmd:word;
     end;
     pACCEL=pointer to ACCEL;

type PAINTSTRUCT=record
       hdc:HDC;
       fErase:boolean;
       rcPaint:RECT;
       fRestore:boolean;
       fIncUpdate:boolean;
       rgbReserved:array[0..31]of byte;
     end;
     pPAINTSTRUCT=pointer to PAINTSTRUCT;

type CREATESTRUCT=record
       lpCreateParams:address;
       hInstance:HINSTANCE;
       hMenu:HMENU;
       hwndParent:HWND;
       cy:integer;
       cx:integer;
       y:integer;
       x:integer;
       style:integer;
       lpszName:pstr;
       lpszClass:pstr;
       dwExStyle:cardinal;
     end;
     pCREATESTRUCT=pointer to CREATESTRUCT;

type WINDOWPLACEMENT=record
       length:cardinal;
       flags:cardinal;
       showCmd:cardinal;
       ptMinPosition:POINT;
       ptMaxPosition:POINT;
       rcNormalPosition:RECT;
     end;
     pWINDOWPLACEMENT=pointer to WINDOWPLACEMENT;

const HCBT_MOVESIZE=0x00000000;
const HCBT_MINMAX=0x00000001;
const HCBT_QS=0x00000002;
const HCBT_CREATEWND=0x00000003;
const HCBT_DESTROYWND=0x00000004;
const HCBT_ACTIVATE=0x00000005;
const HCBT_CLICKSKIPPED=0x00000006;
const HCBT_KEYSKIPPED=0x00000007;
const HCBT_SYSCOMMAND=0x00000008;
const HCBT_SETFOCUS=0x00000009;

type CBT_CREATEWND=record
       lpcs:pCREATESTRUCT;
       hwndInsertAfter:HWND;
     end;
     pCBT_CREATEWND=pointer to CBT_CREATEWND;

type CBTACTIVATESTRUCT=record
       fMouse:boolean;
       hWndActive:HWND;
     end;
     pCBTACTIVATESTRUCT=pointer to CBTACTIVATESTRUCT;

const WPF_SETMINPOSITION=0x00000001;
const WPF_RESTORETOMAXIMIZED=0x00000002;
type NMHDR=record
       hwndFrom:HWND;
       idFrom:cardinal;
       code:cardinal;
     end;
     pNMHDR=pointer to NMHDR;

type STYLESTRUCT=record
       styleOld:cardinal;
       styleNew:cardinal;
     end;
     pSTYLESTRUCT=pointer to STYLESTRUCT;

const ODT_MENU=0x00000001;
const ODT_LISTBOX=0x00000002;
const ODT_COMBOBOX=0x00000003;
const ODT_BUTTON=0x00000004;
const ODT_STATIC=0x00000005;
const ODA_DRAWENTIRE=0x00000001;
const ODA_SELECT=0x00000002;
const ODA_FOCUS=0x00000004;
const ODS_SELECTED=0x00000001;
const ODS_GRAYED=0x00000002;
const ODS_DISABLED=0x00000004;
const ODS_CHECKED=0x00000008;
const ODS_FOCUS=0x00000010;
const ODS_DEFAULT=0x00000020;
const ODS_COMBOBOXEDIT=0x00001000;
type MEASUREITEMSTRUCT=record
       CtlType:cardinal;
       CtlID:cardinal;
       itemID:cardinal;
       itemWidth:cardinal;
       itemHeight:cardinal;
       itemData:cardinal;
     end;
     pMEASUREITEMSTRUCT=pointer to MEASUREITEMSTRUCT;

type DRAWITEMSTRUCT=record
       CtlType:cardinal;
       CtlID:cardinal;
       itemID:cardinal;
       itemAction:cardinal;
       itemState:cardinal;
       hwndItem:HWND;
       hDC:HDC;
       rcItem:RECT;
       itemData:cardinal;
     end;
     pDRAWITEMSTRUCT=pointer to DRAWITEMSTRUCT;

type DELETEITEMSTRUCT=record
       CtlType:cardinal;
       CtlID:cardinal;
       itemID:cardinal;
       hwndItem:HWND;
       itemData:cardinal;
     end;
     pDELETEITEMSTRUCT=pointer to DELETEITEMSTRUCT;

type COMPAREITEMSTRUCT=record
       CtlType:cardinal;
       CtlID:cardinal;
       hwndItem:HWND;
       itemID1:cardinal;
       itemData1:cardinal;
       itemID2:cardinal;
       itemData2:cardinal;
       dwLocaleId:cardinal;
     end;
     pCOMPAREITEMSTRUCT=pointer to COMPAREITEMSTRUCT;

procedure GetMessage ascii(lpMsg:pMSG; hWnd:HWND; wMsgFilterMin:cardinal; wMsgFilterMax:cardinal):boolean;
procedure TranslateMessage(lpMsg:pMSG):boolean;
procedure DispatchMessage ascii(lpMsg:pMSG):integer;
procedure SetMessageQueue(cMessagesMax:integer):boolean;
procedure PeekMessage ascii(lpMsg:pMSG; hWnd:HWND; wMsgFilterMin:cardinal; wMsgFilterMax:cardinal; wRemoveMsg:cardinal):boolean;
const PM_NOREMOVE=0x00000000;
const PM_REMOVE=0x00000001;
const PM_NOYIELD=0x00000002;
procedure RegisterHotKey(hWnd:HWND; id:integer; fsModifiers:cardinal; vk:cardinal):boolean;
procedure UnregisterHotKey(hWnd:HWND; id:integer):boolean;
const MOD_ALT=0x00000001;
const MOD_CONTROL=0x00000002;
const MOD_SHIFT=0x00000004;
const MOD_WIN=0x00000008;
const IDHOT_SNAPWINDOW=-0x00000001;
const IDHOT_SNAPDESKTOP=-0x00000002;
const EW_RESTARTWINDOWS=0x00000042;
const EW_REBOOTSYSTEM=0x00000043;
const EW_EXITANDEXECAPP=0x00000044;
const ENDSESSION_LOGOFF=0x80000000;
const EWX_LOGOFF=0x00000000;
const EWX_SHUTDOWN=0x00000001;
const EWX_REBOOT=0x00000002;
const EWX_FORCE=0x00000004;
const EWX_POWEROFF=0x00000008;
procedure ExitWindowsEx(uFlags:cardinal; dwReserved:cardinal):boolean;
procedure SwapMouseButton(fSwap:boolean):boolean;
procedure GetMessagePos():cardinal;
procedure GetMessageTime():integer;
procedure GetMessageExtraInfo():integer;
procedure SetMessageExtraInfo(lParam:cardinal):cardinal;
procedure SendMessage ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):cardinal;
procedure SendMessageTimeout ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal; fuFlags:cardinal; uTimeout:cardinal; lpdwResult:pCARDINAL):cardinal;
procedure SendNotifyMessage ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):boolean;
procedure SendMessageCallback ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal; lpResultCallBack:pPROC; dwData:cardinal):boolean;
const BSM_ALLCOMPONENTS=0x00000000;
const BSM_VXDS=0x00000001;
const BSM_NETDRIVER=0x00000002;
const BSM_INSTALLABLEDRIVERS=0x00000004;
const BSM_APPLICATIONS=0x00000008;
const BSM_ALLDESKTOPS=0x00000010;
const BSF_QUERY=0x00000001;
const BSF_IGNORECURRENTTASK=0x00000002;
const BSF_FLUSHDISK=0x00000004;
const BSF_NOHANG=0x00000008;
const BSF_POSTMESSAGE=0x00000010;
const BSF_FORCEIFHUNG=0x00000020;
const BSF_NOTIMEOUTIFNOTHUNG=0x00000040;
type BROADCASTSYSMSG=record
       uiMessage:cardinal;
       wParam:cardinal;
       lParam:cardinal;
     end;
     pBROADCASTSYSMSG=pointer to BROADCASTSYSMSG;

procedure PostMessage ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):boolean;
procedure PostThreadMessage ascii(idThread:cardinal; Msg:cardinal; wParam:cardinal; lParam:cardinal):boolean;
const HWND_BROADCAST=0x0000FFFF;
procedure AttachThreadInput(idAttach:cardinal; idAttachTo:cardinal; fAttach:boolean):boolean;
procedure ReplyMessage(lResult:cardinal):boolean;
procedure WaitMessage():boolean;
procedure WaitForInputIdle(hProcess:HANDLE; dwMilliseconds:cardinal):cardinal;
procedure DefWindowProc ascii(hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):boolean;
procedure PostQuitMessage(nExitCode:integer);
procedure CallWindowProc ascii(lpPrevWndFunc:pPROC; hWnd:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):cardinal;
procedure InSendMessage():boolean;
procedure GetDoubleClickTime():cardinal;
procedure SetDoubleClickTime(cardinal):boolean;
procedure RegisterClass ascii(lpWndClass:pWNDCLASS):ATOM;
procedure UnregisterClass ascii(lpClassName:pstr; hInstance:HINSTANCE):boolean;
procedure GetClassInfo ascii(hInstance:HINSTANCE; lpClassName:pstr; lpWndClass:pWNDCLASS):boolean;
procedure RegisterClassEx ascii(pWNDCLASSEX):ATOM;
procedure GetClassInfoEx ascii(HINSTANCE; pstr; pWNDCLASSEX):boolean;
const CW_USEDEFAULT=0x80000000;
const HWND_DESKTOP=0x00000000;
procedure CreateWindowEx ascii(dwExStyle:cardinal; lpClassName:pstr; lpWindowName:pstr; dwStyle:cardinal; X,Y,nWidth,nHeight:integer; hWndParent:HWND; hMenu:HMENU; hInstance:HINSTANCE; lpParam:address):HWND;
procedure IsWindow(hWnd:HWND):boolean;
procedure IsMenu(hMenu:HMENU):boolean;
procedure IsChild(hWndParent:HWND; hWnd:HWND):boolean;
procedure DestroyWindow(hWnd:HWND):boolean;
procedure ShowWindow(hWnd:HWND; nCmdShow:integer):boolean;
procedure ShowWindowAsync(hWnd:HWND; nCmdShow:integer):boolean;
procedure FlashWindow(hWnd:HWND; bInvert:boolean):boolean;
procedure ShowOwnedPopups(hWnd:HWND; fShow:boolean):boolean;
procedure OpenIcon(hWnd:HWND):boolean;
procedure CloseWindow(hWnd:HWND):boolean;
procedure MoveWindow(hWnd:HWND; X,Y,nWidth,nHeight:integer; bRepaint:boolean):boolean;
procedure SetWindowPos(hWnd:HWND; hWndInsertAfter:HWND; X,Y,cx,cy:integer; uFlags:cardinal):boolean;
procedure GetWindowPlacement(hWnd:HWND; lpwndpl:pWINDOWPLACEMENT):boolean;
procedure SetWindowPlacement(hWnd:HWND; lpwndpl:pWINDOWPLACEMENT):boolean;
procedure BeginDeferWindowPos(nNumWindows:integer):HDWP;
procedure DeferWindowPos(hWinPosInfo:HDWP; hWnd:HWND; hWndInsertAfter:HWND; x,y,cx,cy:integer; uFlags:cardinal):HDWP;
procedure EndDeferWindowPos(hWinPosInfo:HDWP):boolean;
procedure IsWindowVisible(hWnd:HWND):boolean;
procedure IsIconic(hWnd:HWND):boolean;
procedure AnyPopup():boolean;
procedure BringWindowToTop(hWnd:HWND):boolean;
procedure IsZoomed(hWnd:HWND):boolean;
const SWP_NOSIZE=0x00000001;
const SWP_NOMOVE=0x00000002;
const SWP_NOZORDER=0x00000004;
const SWP_NOREDRAW=0x00000008;
const SWP_NOACTIVATE=0x00000010;
const SWP_FRAMECHANGED=0x00000020;
const SWP_SHOWWINDOW=0x00000040;
const SWP_HIDEWINDOW=0x00000080;
const SWP_NOCOPYBITS=0x00000100;
const SWP_NOOWNERZORDER=0x00000200;
const SWP_NOSENDCHANGING=0x00000400;
const SWP_DRAWFRAME=SWP_FRAMECHANGED;
const SWP_NOREPOSITION=SWP_NOOWNERZORDER;
const SWP_DEFERERASE=0x00002000;
const SWP_ASYNCWINDOWPOS=0x00004000;
const HWND_TOP=0x00000000;
const HWND_BOTTOM=0x00000001;
const HWND_TOPMOST=-0x00000001;
const HWND_NOTOPMOST=-0x00000002;
type DLGTEMPLATE=record
       style:cardinal;
       dwExtendedStyle:cardinal;
       cdit:word;
       x:word;
       y:word;
       cx:word;
       cy:word;
     end;
     pDLGTEMPLATE=pointer to DLGTEMPLATE;

type DLGITEMTEMPLATE=record
       style:cardinal;
       dwExtendedStyle:cardinal;
       x:word;
       y:word;
       cx:word;
       cy:word;
       id:word;
     end;
     pDLGITEMTEMPLATE=pointer to DLGITEMTEMPLATE;

procedure CreateDialogParam ascii(hInstance:HINSTANCE; lpTemplateName:pstr; hWndParent:HWND; lpDialogFunc:pPROC; dwInitParam:cardinal):HWND;
procedure CreateDialogIndirectParam ascii(hInstance:HINSTANCE; lpTemplate:pDLGTEMPLATE; hWndParent:HWND; lpDialogFunc:pPROC; dwInitParam:cardinal):HWND;
procedure DialogBoxParam ascii(hInstance:HINSTANCE; lpTemplateName:pstr; hWndParent:HWND; lpDialogFunc:pPROC; dwInitParam:cardinal):integer;
procedure DialogBoxIndirectParam ascii(hInstance:HINSTANCE; hDialogTemplate:pDLGTEMPLATE; hWndParent:HWND; lpDialogFunc:pPROC; dwInitParam:cardinal):integer;
procedure EndDialog(hDlg:HWND; nResult:integer):boolean;
procedure GetDlgItem(hDlg:HWND; nIDDlgItem:integer):HWND;
procedure SetDlgItemInt(hDlg:HWND; nIDDlgItem:integer; uValue:cardinal; bSigned:boolean):boolean;
procedure GetDlgItemInt(hDlg:HWND; nIDDlgItem:integer; lpTranslated:pBOOL; bSigned:boolean):cardinal;
procedure SetDlgItemText ascii(hDlg:HWND; nIDDlgItem:integer; lpString:pstr):boolean;
procedure GetDlgItemText ascii(hDlg:HWND; nIDDlgItem:integer; lpString:pstr; nMaxCount:integer):cardinal;
procedure CheckDlgButton(hDlg:HWND; nIDButton:integer; uCheck:cardinal):boolean;
procedure CheckRadioButton(hDlg:HWND; nIDFirstButton:integer; nIDLastButton:integer; nIDCheckButton:integer):boolean;
procedure IsDlgButtonChecked(hDlg:HWND; nIDButton:integer):cardinal;
procedure SendDlgItemMessage ascii(hDlg:HWND; nIDDlgItem:integer; Msg:cardinal; wParam:cardinal; lParam:cardinal):integer;
procedure GetNextDlgGroupItem(hDlg:HWND; hCtl:HWND; bPrevious:boolean):HWND;
procedure GetNextDlgTabItem(hDlg:HWND; hCtl:HWND; bPrevious:boolean):HWND;
procedure GetDlgCtrlID(hWnd:HWND):integer;
procedure GetDialogBaseUnits():integer;
procedure DefDlgProc ascii(hDlg:HWND; Msg:cardinal; wParam:cardinal; lParam:cardinal):cardinal;

const DLGWINDOWEXTRA=0x0000001E;

procedure CallMsgFilter ascii(lpMsg:pMSG; nCode:integer):boolean;
procedure OpenClipboard(hWndNewOwner:HWND):boolean;
procedure CloseClipboard():boolean;
procedure GetClipboardOwner():HWND;
procedure SetClipboardViewer(hWndNewViewer:HWND):HWND;
procedure GetClipboardViewer():HWND;
procedure ChangeClipboardChain(hWndRemove:HWND; hWndNewNext:HWND):boolean;
procedure SetClipboardData(uFormat:cardinal; hMem:HANDLE):HANDLE;
procedure GetClipboardData(uFormat:cardinal):HANDLE;
procedure RegisterClipboardFormat ascii(lpszFormat:pstr):cardinal;
procedure CountClipboardFormats():integer;
procedure EnumClipboardFormats(format:cardinal):cardinal;
procedure GetClipboardFormatName ascii(format:cardinal; lpszFormatName:pstr; cchMaxCount:integer):integer;
procedure EmptyClipboard():boolean;
procedure IsClipboardFormatAvailable(format:cardinal):boolean;
procedure GetPriorityClipboardFormat(paFormatPriorityList:pCARDINAL; cFormats:integer):integer;
procedure GetOpenClipboardWindow():HWND;
procedure CharToOem ascii(lpszSrc:pstr; lpszDst:pstr):boolean;
procedure OemToChar ascii(lpszSrc:pstr; lpszDst:pstr):boolean;
procedure CharToOemBuff ascii(lpszSrc:pstr; lpszDst:pstr; cchDstLength:cardinal):boolean;
procedure OemToCharBuff ascii(lpszSrc:pstr; lpszDst:pstr; cchDstLength:cardinal):boolean;
procedure CharUpper ascii(lpsz:pstr):pstr;
procedure CharUpperBuff ascii(lpsz:pstr; cchLength:cardinal):cardinal;
procedure CharLower ascii(lpsz:pstr):pstr;
procedure CharLowerBuff ascii(lpsz:pstr; cchLength:cardinal):cardinal;
procedure CharNext ascii(lpsz:pstr):pstr;
procedure CharPrev ascii(lpszStart:pstr; lpszCurrent:pstr):pstr;
procedure CharNextEx ascii(CodePage:word; lpCurrentChar:pstr; dwFlags:cardinal):pstr;
procedure CharPrevEx ascii(CodePage:word; lpStart:pstr; lpCurrentChar:pstr; dwFlags:cardinal):pstr;
procedure IsCharAlpha ascii(ch:char):boolean;
procedure IsCharAlphaNumeric ascii(ch:char):boolean;
procedure IsCharUpper ascii(ch:char):boolean;
procedure IsCharLower ascii(ch:char):boolean;
procedure SetFocus(hWnd:HWND):HWND;
procedure GetActiveWindow():HWND;
procedure GetFocus():HWND;
procedure GetKBCodePage():cardinal;
procedure GetKeyState(nVirtKey:integer):word;
procedure GetAsyncKeyState(vKey:integer):word;
procedure GetKeyboardState(lpKeyState:pBYTE):boolean;
procedure SetKeyboardState(lpKeyState:pBYTE):boolean;
procedure GetKeyNameText ascii(lParam:integer; lpString:pstr; nSize:integer):integer;
procedure GetKeyboardType(nTypeFlag:integer):integer;
procedure ToAscii(uVirtKey:cardinal; uScanCode:cardinal; lpKeyState:pBYTE; lpChar:pWORD; uFlags:cardinal):integer;
procedure ToAsciiEx(uVirtKey:cardinal; uScanCode:cardinal; lpKeyState:pBYTE; lpChar:pWORD; uFlags:cardinal; dwhkl:HKL):integer;
procedure ToUnicode(wVirtKey:cardinal; wScanCode:cardinal; lpKeyState:pBYTE; pwszBuff:address; cchBuff:integer; wFlags:cardinal):integer;
procedure OemKeyScan(wOemChar:word):cardinal;
procedure VkKeyScan ascii(ch:char):word;
procedure VkKeyScanEx ascii(ch:char; dwhkl:HKL):word;
procedure keybd_event(bVk:byte; bScan:byte; dwFlags:cardinal; dwExtraInfo:cardinal);
const MOUSEEVENTF_MOVE=0x00000001;
const MOUSEEVENTF_LEFTDOWN=0x00000002;
const MOUSEEVENTF_LEFTUP=0x00000004;
const MOUSEEVENTF_RIGHTDOWN=0x00000008;
const MOUSEEVENTF_RIGHTUP=0x00000010;
const MOUSEEVENTF_MIDDLEDOWN=0x00000020;
const MOUSEEVENTF_MIDDLEUP=0x00000040;
const MOUSEEVENTF_WHEEL=0x00000800;
const MOUSEEVENTF_ABSOLUTE=0x00008000;

procedure mouse_event(dwFlags:cardinal; dx:cardinal; dy:cardinal; dwData:cardinal; dwExtraInfo:cardinal);
procedure MapVirtualKey ascii(uCode:cardinal; uMapType:cardinal):cardinal;
procedure MapVirtualKeyEx ascii(uCode:cardinal; uMapType:cardinal; dwhkl:HKL):cardinal;
procedure GetInputState():boolean;
procedure GetQueueStatus(flags:cardinal):cardinal;
procedure GetCapture():HWND;
procedure SetCapture(hWnd:HWND):HWND;
procedure ReleaseCapture():boolean;
procedure MsgWaitForMultipleObjects(nCount:cardinal; pHandles:pHANDLE; fWaitAll:boolean; dwMilliseconds:cardinal; dwWakeMask:cardinal):cardinal;

const MWMO_WAITALL=0x00000001;
const MWMO_ALERTABLE=0x00000002;
const QS_KEY=0x00000001;
const QS_MOUSEMOVE=0x00000002;
const QS_MOUSEBUTTON=0x00000004;
const QS_POSTMESSAGE=0x00000008;
const QS_TIMER=0x00000010;
const QS_PAINT=0x00000020;
const QS_SENDMESSAGE=0x00000040;
const QS_HOTKEY=0x00000080;
const QS_ALLPOSTMESSAGE=0x00000100;
const QS_MOUSE=QS_MOUSEMOVE|QS_MOUSEBUTTON;
const QS_INPUT=QS_MOUSE|QS_KEY;
const QS_ALLEVENTS=QS_INPUT|QS_POSTMESSAGE|QS_TIMER|QS_PAINT|QS_HOTKEY;
const QS_ALLINPUT=QS_INPUT|QS_POSTMESSAGE|QS_TIMER|QS_PAINT|QS_HOTKEY|QS_SENDMESSAGE;

procedure SetTimer(hWnd:HWND; nIDEvent:cardinal; uElapse:cardinal; lpTimerFunc:pPROC):cardinal;
procedure KillTimer(hWnd:HWND; uIDEvent:cardinal):boolean;
procedure IsWindowUnicode(hWnd:HWND):boolean;
procedure EnableWindow(hWnd:HWND; bEnable:boolean):boolean;
procedure IsWindowEnabled(hWnd:HWND):boolean;
procedure LoadAccelerators ascii(hInstance:HINSTANCE; lpTableName:pstr):HACCEL;
procedure CreateAcceleratorTable ascii(pACCEL; integer):HACCEL;
procedure DestroyAcceleratorTable(hAccel:HACCEL):boolean;
procedure CopyAcceleratorTable ascii(hAccelSrc:HACCEL; lpAccelDst:pACCEL; cAccelEntries:integer):integer;
procedure TranslateAccelerator ascii(hWnd:HWND; hAccTable:HACCEL; lpMsg:pMSG):integer;
const SM_CXSCREEN=0x00000000;
const SM_CYSCREEN=0x00000001;
const SM_CXVSCROLL=0x00000002;
const SM_CYHSCROLL=0x00000003;
const SM_CYCAPTION=0x00000004;
const SM_CXBORDER=0x00000005;
const SM_CYBORDER=0x00000006;
const SM_CXDLGFRAME=0x00000007;
const SM_CYDLGFRAME=0x00000008;
const SM_CYVTHUMB=0x00000009;
const SM_CXHTHUMB=0x0000000A;
const SM_CXICON=0x0000000B;
const SM_CYICON=0x0000000C;
const SM_CXCURSOR=0x0000000D;
const SM_CYCURSOR=0x0000000E;
const SM_CYMENU=0x0000000F;
const SM_CXFULLSCREEN=0x00000010;
const SM_CYFULLSCREEN=0x00000011;
const SM_CYKANJIWINDOW=0x00000012;
const SM_MOUSEPRESENT=0x00000013;
const SM_CYVSCROLL=0x00000014;
const SM_CXHSCROLL=0x00000015;
const SM_DEBUG=0x00000016;
const SM_SWAPBUTTON=0x00000017;
const SM_RESERVED1=0x00000018;
const SM_RESERVED2=0x00000019;
const SM_RESERVED3=0x0000001A;
const SM_RESERVED4=0x0000001B;
const SM_CXMIN=0x0000001C;
const SM_CYMIN=0x0000001D;
const SM_CXSIZE=0x0000001E;
const SM_CYSIZE=0x0000001F;
const SM_CXFRAME=0x00000020;
const SM_CYFRAME=0x00000021;
const SM_CXMINTRACK=0x00000022;
const SM_CYMINTRACK=0x00000023;
const SM_CXDOUBLECLK=0x00000024;
const SM_CYDOUBLECLK=0x00000025;
const SM_CXICONSPACING=0x00000026;
const SM_CYICONSPACING=0x00000027;
const SM_MENUDROPALIGNMENT=0x00000028;
const SM_PENWINDOWS=0x00000029;
const SM_DBCSENABLED=0x0000002A;
const SM_CMOUSEBUTTONS=0x0000002B;
const SM_CXFIXEDFRAME=SM_CXDLGFRAME;
const SM_CYFIXEDFRAME=SM_CYDLGFRAME;
const SM_CXSIZEFRAME=SM_CXFRAME;
const SM_CYSIZEFRAME=SM_CYFRAME;
const SM_SECURE=0x0000002C;
const SM_CXEDGE=0x0000002D;
const SM_CYEDGE=0x0000002E;
const SM_CXMINSPACING=0x0000002F;
const SM_CYMINSPACING=0x00000030;
const SM_CXSMICON=0x00000031;
const SM_CYSMICON=0x00000032;
const SM_CYSMCAPTION=0x00000033;
const SM_CXSMSIZE=0x00000034;
const SM_CYSMSIZE=0x00000035;
const SM_CXMENUSIZE=0x00000036;
const SM_CYMENUSIZE=0x00000037;
const SM_ARRANGE=0x00000038;
const SM_CXMINIMIZED=0x00000039;
const SM_CYMINIMIZED=0x0000003A;
const SM_CXMAXTRACK=0x0000003B;
const SM_CYMAXTRACK=0x0000003C;
const SM_CXMAXIMIZED=0x0000003D;
const SM_CYMAXIMIZED=0x0000003E;
const SM_NETWORK=0x0000003F;
const SM_CLEANBOOT=0x00000043;
const SM_CXDRAG=0x00000044;
const SM_CYDRAG=0x00000045;
const SM_SHOWSOUNDS=0x00000046;
const SM_CXMENUCHECK=0x00000047;
const SM_CYMENUCHECK=0x00000048;
const SM_SLOWMACHINE=0x00000049;
const SM_MIDEASTENABLED=0x0000004A;
const SM_MOUSEWHEELPRESENT=0x0000004B;
const SM_CMETRICS=0x0000004C;
procedure GetSystemMetrics(nIndex:integer):integer;
procedure LoadMenu ascii(hInstance:HINSTANCE; lpMenuName:pstr):HMENU;
procedure LoadMenuIndirect ascii(lpMenuTemplate:pMENUTEMPLATE):HMENU;
procedure GetMenu(hWnd:HWND):HMENU;
procedure SetMenu(hWnd:HWND; hMenu:HMENU):boolean;
procedure ChangeMenu ascii(hMenu:HMENU; cmd:cardinal; lpszNewItem:pstr; cmdInsert:cardinal; flags:cardinal):boolean;
procedure HiliteMenuItem(hWnd:HWND; hMenu:HMENU; uIDHiliteItem:cardinal; uHilite:cardinal):boolean;
procedure GetMenuString ascii(hMenu:HMENU; uIDItem:cardinal; lpString:pstr; nMaxCount:integer; uFlag:cardinal):integer;
procedure GetMenuState(hMenu:HMENU; uId:cardinal; uFlags:cardinal):cardinal;
procedure DrawMenuBar(hWnd:HWND):boolean;
procedure GetSystemMenu(hWnd:HWND; bRevert:boolean):HMENU;
procedure CreateMenu():HMENU;
procedure CreatePopupMenu():HMENU;
procedure DestroyMenu(hMenu:HMENU):boolean;
procedure CheckMenuItem(hMenu:HMENU; uIDCheckItem:cardinal; uCheck:cardinal):cardinal;
procedure EnableMenuItem(hMenu:HMENU; uIDEnableItem:cardinal; uEnable:cardinal):boolean;
procedure GetSubMenu(hMenu:HMENU; nPos:integer):HMENU;
procedure GetMenuItemID(hMenu:HMENU; nPos:integer):cardinal;
procedure GetMenuItemCount(hMenu:HMENU):integer;
procedure InsertMenu ascii(hMenu:HMENU; uPosition:cardinal; uFlags:cardinal; uIDNewItem:cardinal; lpNewItem:pstr):boolean;
procedure AppendMenu ascii(hMenu:HMENU; uFlags:cardinal; uIDNewItem:cardinal; lpNewItem:pstr):boolean;
procedure ModifyMenu ascii(hMnu:HMENU; uPosition:cardinal; uFlags:cardinal; uIDNewItem:cardinal; lpNewItem:pstr):boolean;
procedure RemoveMenu(hMenu:HMENU; uPosition:cardinal; uFlags:cardinal):boolean;
procedure DeleteMenu(hMenu:HMENU; uPosition:cardinal; uFlags:cardinal):boolean;
procedure SetMenuItemBitmaps(hMenu:HMENU; uPosition:cardinal; uFlags:cardinal; hBitmapUnchecked:HBITMAP; hBitmapChecked:HBITMAP):boolean;
procedure GetMenuCheckMarkDimensions():integer;
procedure TrackPopupMenu(hMenu:HMENU; uFlags:cardinal; x:integer; y:integer; nReserved:integer; hWnd:HWND; prcRect:pRECT):boolean;

const MNC_IGNORE=0x00000000;
const MNC_CLOSE=0x00000001;
const MNC_EXECUTE=0x00000002;
const MNC_SELECT=0x00000003;
type TPMPARAMS=record
       cbSize:cardinal;
       rcExclude:RECT;
     end;
     pTPMPARAMS=pointer to TPMPARAMS;

procedure TrackPopupMenuEx(HMENU; cardinal; integer; integer; HWND; pTPMPARAMS):boolean;

const MIIM_STATE=0x00000001;
const MIIM_ID=0x00000002;
const MIIM_SUBMENU=0x00000004;
const MIIM_CHECKMARKS=0x00000008;
const MIIM_TYPE=0x00000010;
const MIIM_DATA=0x00000020;
type MENUITEMINFO=record
       cbSize:cardinal;
       fMask:cardinal;
       fType:cardinal;
       fState:cardinal;
       wID:cardinal;
       hSubMenu:HMENU;
       hbmpChecked:HBITMAP;
       hbmpUnchecked:HBITMAP;
       dwItemData:cardinal;
       dwTypeData:pstr;
       cch:cardinal;
     end;
     pMENUITEMINFO=pointer to MENUITEMINFO;

procedure InsertMenuItem ascii(HMENU; cardinal; boolean; pMENUITEMINFO):boolean;
procedure GetMenuItemInfo ascii(HMENU; cardinal; boolean; pMENUITEMINFO):boolean;
procedure SetMenuItemInfo ascii(HMENU; cardinal; boolean; pMENUITEMINFO):boolean;

const GMDI_USEDISABLED=0x00000001;
const GMDI_GOINTOPOPUPS=0x00000002;

procedure GetMenuDefaultItem(hMenu:HMENU; fByPos:cardinal; gmdiFlags:cardinal):cardinal;
procedure SetMenuDefaultItem(hMenu:HMENU; uItem:cardinal; fByPos:cardinal):boolean;
procedure GetMenuItemRect(hWnd:HWND; hMenu:HMENU; uItem:cardinal; lprcItem:pRECT):boolean;
procedure MenuItemFromPoint(hWnd:HWND; hMenu:HMENU; ptScreen:POINT):integer;

const TPM_LEFTBUTTON=0x00000000;
const TPM_RIGHTBUTTON=0x00000002;
const TPM_LEFTALIGN=0x00000000;
const TPM_CENTERALIGN=0x00000004;
const TPM_RIGHTALIGN=0x00000008;
const TPM_TOPALIGN=0x00000000;
const TPM_VCENTERALIGN=0x00000010;
const TPM_BOTTOMALIGN=0x00000020;
const TPM_HORIZONTAL=0x00000000;
const TPM_VERTICAL=0x00000040;
const TPM_NONOTIFY=0x00000080;
const TPM_RETURNCMD=0x00000100;
type DROPSTRUCT=record
       hwndSource:HWND;
       hwndSink:HWND;
       wFmt:cardinal;
       dwData:cardinal;
       ptDrop:POINT;
       dwControlData:cardinal;
     end;
     pDROPSTRUCT=pointer to DROPSTRUCT;

const DOF_EXECUTABLE=0x00008001;
const DOF_DOCUMENT=0x00008002;
const DOF_DIRECTORY=0x00008003;
const DOF_MULTIPLE=0x00008004;
const DOF_PROGMAN=0x00000001;
const DOF_SHELLDATA=0x00000002;
const DO_DROPFILE=0x454C4946;
const DO_PRINTFILE=0x544E5250;
procedure DragObject(HWND; HWND; cardinal; cardinal; HCURSOR):cardinal;
procedure DragDetect(HWND; POINT):boolean;
procedure DrawIcon(hDC:HDC; X:integer; Y:integer; hIcon:HICON):boolean;
const DT_TOP=0x00000000;
const DT_LEFT=0x00000000;
const DT_CENTER=0x00000001;
const DT_RIGHT=0x00000002;
const DT_VCENTER=0x00000004;
const DT_BOTTOM=0x00000008;
const DT_WORDBREAK=0x00000010;
const DT_SINGLELINE=0x00000020;
const DT_EXPANDTABS=0x00000040;
const DT_TABSTOP=0x00000080;
const DT_NOCLIP=0x00000100;
const DT_EXTERNALLEADING=0x00000200;
const DT_CALCRECT=0x00000400;
const DT_NOPREFIX=0x00000800;
const DT_INTERNAL=0x00001000;
const DT_EDITCONTROL=0x00002000;
const DT_PATH_ELLIPSIS=0x00004000;
const DT_END_ELLIPSIS=0x00008000;
const DT_MODIFYSTRING=0x00010000;
const DT_RTLREADING=0x00020000;
const DT_WORD_ELLIPSIS=0x00040000;
type DRAWTEXTPARAMS=record
       cbSize:cardinal;
       iTabLength:integer;
       iLeftMargin:integer;
       iRightMargin:integer;
       uiLengthDrawn:cardinal;
     end;
     pDRAWTEXTPARAMS=pointer to DRAWTEXTPARAMS;

procedure DrawText ascii(hDC:HDC; lpString:pstr; nCount:integer; lpRect:pRECT; uFormat:cardinal):integer;
procedure DrawTextEx ascii(HDC; pstr; integer; pRECT; cardinal; pDRAWTEXTPARAMS):integer;
procedure GrayString ascii(hDC:HDC; hBrush:HBRUSH; lpOutputFunc:pPROC; lpData:cardinal; nCount:integer; X:integer; Y:integer; nWidth:integer; nHeight:integer):boolean;

const DST_COMPLEX=0x00000000;
const DST_TEXT=0x00000001;
const DST_PREFIXTEXT=0x00000002;
const DST_ICON=0x00000003;
const DST_BITMAP=0x00000004;
const DSS_NORMAL=0x00000000;
const DSS_UNION=0x00000010;
const DSS_DISABLED=0x00000020;
const DSS_MONO=0x00000080;
const DSS_RIGHT=0x00008000;

procedure DrawState ascii(HDC; HBRUSH; pPROC; cardinal; cardinal; integer; integer; integer; integer; cardinal):boolean;
procedure TabbedTextOut ascii(hDC:HDC; X:integer; Y:integer; lpString:pstr; nCount:integer; nTabPositions:integer; lpnTabStopPositions:pINT; nTabOrigin:integer):integer;
procedure GetTabbedTextExtent ascii(hDC:HDC; lpString:pstr; nCount:integer; nTabPositions:integer; lpnTabStopPositions:pINT):cardinal;
procedure UpdateWindow(hWnd:HWND):boolean;
procedure SetActiveWindow(hWnd:HWND):HWND;
procedure GetForegroundWindow():HWND;
procedure PaintDesktop(hdc:HDC):boolean;
procedure SetForegroundWindow(hWnd:HWND):boolean;
procedure WindowFromDC(hDC:HDC):HWND;
procedure GetDC(hWnd:HWND):HDC;
procedure GetDCEx(hWnd:HWND; hrgnClip:HRGN; flags:cardinal):HDC;

const DCX_WINDOW=0x00000001;
const DCX_CACHE=0x00000002;
const DCX_NORESETATTRS=0x00000004;
const DCX_CLIPCHILDREN=0x00000008;
const DCX_CLIPSIBLINGS=0x00000010;
const DCX_PARENTCLIP=0x00000020;
const DCX_EXCLUDERGN=0x00000040;
const DCX_INTERSECTRGN=0x00000080;
const DCX_EXCLUDEUPDATE=0x00000100;
const DCX_INTERSECTUPDATE=0x00000200;
const DCX_LOCKWINDOWUPDATE=0x00000400;
const DCX_VALIDATE=0x00200000;
procedure GetWindowDC(hWnd:HWND):HDC;
procedure ReleaseDC(hWnd:HWND; hDC:HDC):integer;
procedure BeginPaint(hWnd:HWND; lpPaint:pPAINTSTRUCT):HDC;
procedure EndPaint(hWnd:HWND; lpPaint:pPAINTSTRUCT):boolean;
procedure GetUpdateRect(hWnd:HWND; lpRect:pRECT; bErase:boolean):boolean;
procedure GetUpdateRgn(hWnd:HWND; hRgn:HRGN; bErase:boolean):integer;
procedure SetWindowRgn(hWnd:HWND; hRgn:HRGN; bRedraw:boolean):integer;
procedure GetWindowRgn(hWnd:HWND; hRgn:HRGN):integer;
procedure ExcludeUpdateRgn(hDC:HDC; hWnd:HWND):integer;
procedure InvalidateRect(hWnd:HWND; lpRect:pRECT; bErase:boolean):boolean;
procedure ValidateRect(hWnd:HWND; lpRect:pRECT):boolean;
procedure InvalidateRgn(hWnd:HWND; hRgn:HRGN; bErase:boolean):boolean;
procedure ValidateRgn(hWnd:HWND; hRgn:HRGN):boolean;
procedure RedrawWindow(hWnd:HWND; lprcUpdate:pRECT; hrgnUpdate:HRGN; flags:cardinal):boolean;
const RDW_INVALIDATE=0x00000001;
const RDW_INTERNALPAINT=0x00000002;
const RDW_ERASE=0x00000004;
const RDW_VALIDATE=0x00000008;
const RDW_NOINTERNALPAINT=0x00000010;
const RDW_NOERASE=0x00000020;
const RDW_NOCHILDREN=0x00000040;
const RDW_ALLCHILDREN=0x00000080;
const RDW_UPDATENOW=0x00000100;
const RDW_ERASENOW=0x00000200;
const RDW_FRAME=0x00000400;
const RDW_NOFRAME=0x00000800;

procedure LockWindowUpdate(hWndLock:HWND):boolean;
procedure ScrollWindow(hWnd:HWND; XAmount:integer; YAmount:integer; lpRect:pRECT; lpClipRect:pRECT):boolean;
procedure ScrollDC(hDC:HDC; dx:integer; dy:integer; lprcScroll:pRECT; lprcClip:pRECT; hrgnUpdate:HRGN; lprcUpdate:pRECT):boolean;
procedure ScrollWindowEx(hWnd:HWND; dx:integer; dy:integer; prcScroll:pRECT; prcClip:pRECT; hrgnUpdate:HRGN; prcUpdate:pRECT; flags:cardinal):integer;

const SW_SCROLLCHILDREN=0x00000001;
const SW_INVALIDATE=0x00000002;
const SW_ERASE=0x00000004;

procedure SetScrollPos(hWnd:HWND; nBar:integer; nPos:integer; bRedraw:boolean):integer;
procedure GetScrollPos(hWnd:HWND; nBar:integer):integer;
procedure SetScrollRange(hWnd:HWND; nBar:integer; nMinPos:integer; nMaxPos:integer; bRedraw:boolean):boolean;
procedure GetScrollRange(hWnd:HWND; nBar:integer; lpMinPos:pINT; lpMaxPos:pINT):boolean;
procedure ShowScrollBar(hWnd:HWND; wBar:integer; bShow:boolean):boolean;
procedure EnableScrollBar(hWnd:HWND; wSBflags:cardinal; wArrows:cardinal):boolean;

const ESB_ENABLE_BOTH=0x00000000;
const ESB_DISABLE_BOTH=0x00000003;
const ESB_DISABLE_LEFT=0x00000001;
const ESB_DISABLE_RIGHT=0x00000002;
const ESB_DISABLE_UP=0x00000001;
const ESB_DISABLE_DOWN=0x00000002;
const ESB_DISABLE_LTUP=ESB_DISABLE_LEFT;
const ESB_DISABLE_RTDN=ESB_DISABLE_RIGHT;

procedure SetProp ascii(hWnd:HWND; lpString:pstr; hData:HANDLE):boolean;
procedure GetProp ascii(hWnd:HWND; lpString:pstr):HANDLE;
procedure RemoveProp ascii(hWnd:HWND; lpString:pstr):HANDLE;
procedure EnumPropsEx ascii(hWnd:HWND; lpEnumFunc:pPROC; lParam:cardinal):integer;
procedure EnumProps ascii(hWnd:HWND; lpEnumFunc:pPROC):integer;
procedure SetWindowText ascii(hWnd:HWND; lpString:pstr):boolean;
procedure GetWindowText ascii(hWnd:HWND; lpString:pstr; nMaxCount:integer):integer;
procedure GetWindowTextLength ascii(hWnd:HWND):integer;
procedure GetClientRect(hWnd:HWND; lpRect:pRECT):boolean;
procedure GetWindowRect(hWnd:HWND; lpRect:pRECT):boolean;
procedure AdjustWindowRect(lpRect:pRECT; dwStyle:cardinal; bMenu:boolean):boolean;
procedure AdjustWindowRectEx(lpRect:pRECT; dwStyle:cardinal; bMenu:boolean; dwExStyle:cardinal):boolean;

const HELPINFO_WINDOW=0x00000001;
const HELPINFO_MENUITEM=0x00000002;
type HELPINFO=record
       cbSize:cardinal;
       iContextType:integer;
       iCtrlId:integer;
       hItemHandle:HANDLE;
       dwContextId:cardinal;
       MousePos:POINT;
     end;
     pHELPINFO=pointer to HELPINFO;

procedure SetWindowContextHelpId(HWND; cardinal):boolean;
procedure GetWindowContextHelpId(HWND):cardinal;
procedure SetMenuContextHelpId(HMENU; cardinal):boolean;
procedure GetMenuContextHelpId(HMENU):cardinal;
const MB_OK=0x00000000;
const MB_OKCANCEL=0x00000001;
const MB_ABORTRETRYIGNORE=0x00000002;
const MB_YESNOCANCEL=0x00000003;
const MB_YESNO=0x00000004;
const MB_RETRYCANCEL=0x00000005;
const MB_ICONHAND=0x00000010;
const MB_ICONQUESTION=0x00000020;
const MB_ICONEXCLAMATION=0x00000030;
const MB_ICONASTERISK=0x00000040;
const MB_USERICON=0x00000080;
const MB_ICONWARNING=MB_ICONEXCLAMATION;
const MB_ICONERROR=MB_ICONHAND;
const MB_ICONINFORMATION=MB_ICONASTERISK;
const MB_ICONSTOP=MB_ICONHAND;
const MB_DEFBUTTON1=0x00000000;
const MB_DEFBUTTON2=0x00000100;
const MB_DEFBUTTON3=0x00000200;
const MB_DEFBUTTON4=0x00000300;
const MB_APPLMODAL=0x00000000;
const MB_SYSTEMMODAL=0x00001000;
const MB_TASKMODAL=0x00002000;
const MB_HELP=0x00004000;
const MB_NOFOCUS=0x00008000;
const MB_SETFOREGROUND=0x00010000;
const MB_DEFAULT_DESKTOP_ONLY=0x00020000;
const MB_TOPMOST=0x00040000;
const MB_RIGHT=0x00080000;
const MB_RTLREADING=0x00100000;
const MB_SERVICE_NOTIFICATION=0x00200000;
const MB_SERVICE_NOTIFICATION_NT3X=0x00040000;
const MB_TYPEMASK=0x0000000F;
const MB_ICONMASK=0x000000F0;
const MB_DEFMASK=0x00000F00;
const MB_MODEMASK=0x00003000;
const MB_MISCMASK=0x0000C000;
procedure MessageBox ascii(hWnd:HWND; lpText:pstr; lpCaption:pstr; uType:cardinal):integer;
procedure MessageBoxEx ascii(hWnd:HWND; lpText:pstr; lpCaption:pstr; uType:cardinal; wLanguageId:word):integer;
type MSGBOXPARAMS=record
       cbSize:cardinal;
       hwndOwner:HWND;
       hInstance:HINSTANCE;
       lpszText:pstr;
       lpszCaption:pstr;
       dwStyle:cardinal;
       lpszIcon:pstr;
       dwContextHelpId:cardinal;
       lpfnMsgBoxCallback:pPROC;
       dwLanguageId:cardinal;
     end;
     pMSGBOXPARAMS=pointer to MSGBOXPARAMS;

procedure MessageBoxIndirect ascii(pMSGBOXPARAMS):integer;
procedure MessageBeep(uType:cardinal):boolean;
procedure ShowCursor(bShow:boolean):integer;
procedure SetCursorPos(X:integer; Y:integer):boolean;
procedure SetCursor(hCursor:HCURSOR):HCURSOR;
procedure GetCursorPos(lpPoint:pPOINT):boolean;
procedure ClipCursor(lpRect:pRECT):boolean;
procedure GetClipCursor(lpRect:pRECT):boolean;
procedure GetCursor():HCURSOR;
procedure CreateCaret(hWnd:HWND; hBitmap:HBITMAP; nWidth:integer; nHeight:integer):boolean;
procedure GetCaretBlinkTime():cardinal;
procedure SetCaretBlinkTime(uMSeconds:cardinal):boolean;
procedure DestroyCaret():boolean;
procedure HideCaret(hWnd:HWND):boolean;
procedure ShowCaret(hWnd:HWND):boolean;
procedure SetCaretPos(X:integer; Y:integer):boolean;
procedure GetCaretPos(lpPoint:pPOINT):boolean;
procedure ClientToScreen(hWnd:HWND; lpPoint:pPOINT):boolean;
procedure ScreenToClient(hWnd:HWND; lpPoint:pPOINT):boolean;
procedure MapWindowPoints(hWndFrom:HWND; hWndTo:HWND; lpPoints:pPOINT; cPoints:cardinal):integer;
procedure WindowFromPoint(Point:POINT):HWND;
procedure ChildWindowFromPoint(hWndParent:HWND; Point:POINT):HWND;

const CWP_ALL=0x00000000;
const CWP_SKIPINVISIBLE=0x00000001;
const CWP_SKIPDISABLED=0x00000002;
const CWP_SKIPTRANSPARENT=0x00000004;

procedure ChildWindowFromPointEx(HWND; POINT; cardinal):HWND;

const CTLCOLOR_MSGBOX=0x00000000;
const CTLCOLOR_EDIT=0x00000001;
const CTLCOLOR_LISTBOX=0x00000002;
const CTLCOLOR_BTN=0x00000003;
const CTLCOLOR_DLG=0x00000004;
const CTLCOLOR_SCROLLBAR=0x00000005;
const CTLCOLOR_STATIC=0x00000006;
const CTLCOLOR_MAX=0x00000007;
const COLOR_SCROLLBAR=0x00000000;
const COLOR_BACKGROUND=0x00000001;
const COLOR_ACTIVECAPTION=0x00000002;
const COLOR_INACTIVECAPTION=0x00000003;
const COLOR_MENU=0x00000004;
const COLOR_WINDOW=0x00000005;
const COLOR_WINDOWFRAME=0x00000006;
const COLOR_MENUTEXT=0x00000007;
const COLOR_WINDOWTEXT=0x00000008;
const COLOR_CAPTIONTEXT=0x00000009;
const COLOR_ACTIVEBORDER=0x0000000A;
const COLOR_INACTIVEBORDER=0x0000000B;
const COLOR_APPWORKSPACE=0x0000000C;
const COLOR_HIGHLIGHT=0x0000000D;
const COLOR_HIGHLIGHTTEXT=0x0000000E;
const COLOR_BTNFACE=0x0000000F;
const COLOR_BTNSHADOW=0x00000010;
const COLOR_GRAYTEXT=0x00000011;
const COLOR_BTNTEXT=0x00000012;
const COLOR_INACTIVECAPTIONTEXT=0x00000013;
const COLOR_BTNHIGHLIGHT=0x00000014;
const COLOR_3DDKSHADOW=0x00000015;
const COLOR_3DLIGHT=0x00000016;
const COLOR_INFOTEXT=0x00000017;
const COLOR_INFOBK=0x00000018;
const COLOR_DESKTOP=COLOR_BACKGROUND;
const COLOR_3DFACE=COLOR_BTNFACE;
const COLOR_3DSHADOW=COLOR_BTNSHADOW;
const COLOR_3DHIGHLIGHT=COLOR_BTNHIGHLIGHT;
const COLOR_3DHILIGHT=COLOR_BTNHIGHLIGHT;
const COLOR_BTNHILIGHT=COLOR_BTNHIGHLIGHT;

procedure GetSysColor(nIndex:integer):cardinal;
procedure GetSysColorBrush(nIndex:integer):HBRUSH;
procedure SetSysColors(cElements:integer; lpaElements:pINT; lpaRgbValues:pCOLORREF):boolean;
procedure DrawFocusRect(hDC:HDC; lprc:pRECT):boolean;
procedure FillRect(hDC:HDC; lprc:pRECT; hbr:HBRUSH):integer;
procedure FrameRect(hDC:HDC; lprc:pRECT; hbr:HBRUSH):integer;
procedure InvertRect(hDC:HDC; lprc:pRECT):boolean;
procedure SetRect(lprc:pRECT; xLeft:integer; yTop:integer; xRight:integer; yBottom:integer):boolean;
procedure SetRectEmpty(lprc:pRECT):boolean;
procedure CopyRect(lprcDst:pRECT; lprcSrc:pRECT):boolean;
procedure InflateRect(lprc:pRECT; dx:integer; dy:integer):boolean;
procedure IntersectRect(lprcDst:pRECT; lprcSrc1:pRECT; lprcSrc2:pRECT):boolean;
procedure UnionRect(lprcDst:pRECT; lprcSrc1:pRECT; lprcSrc2:pRECT):boolean;
procedure SubtractRect(lprcDst:pRECT; lprcSrc1:pRECT; lprcSrc2:pRECT):boolean;
procedure OffsetRect(lprc:pRECT; dx:integer; dy:integer):boolean;
procedure IsRectEmpty(lprc:pRECT):boolean;
procedure EqualRect(lprc1:pRECT; lprc2:pRECT):boolean;
procedure PtInRect(lprc:pRECT; pt:POINT):boolean;
procedure GetWindowWord(hWnd:HWND; nIndex:integer):word;
procedure SetWindowWord(hWnd:HWND; nIndex:integer; wNewWord:word):word;
procedure GetWindowLong ascii(hWnd:HWND; nIndex:integer):integer;
procedure SetWindowLong ascii(hWnd:HWND; nIndex:integer; dwNewLong:integer):integer;
procedure GetClassWord(hWnd:HWND; nIndex:integer):word;
procedure SetClassWord(hWnd:HWND; nIndex:integer; wNewWord:word):word;
procedure GetClassLong ascii(hWnd:HWND; nIndex:integer):cardinal;
procedure SetClassLong ascii(hWnd:HWND; nIndex:integer; dwNewLong:integer):cardinal;
procedure GetDesktopWindow():HWND;
procedure GetParent(hWnd:HWND):HWND;
procedure SetParent(hWndChild:HWND; hWndNewParent:HWND):HWND;
procedure EnumChildWindows(hWndParent:HWND; lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure FindWindow ascii(lpClassName:pstr; lpWindowName:pstr):HWND;
procedure FindWindowEx ascii(HWND; HWND; pstr; pstr):HWND;
procedure EnumWindows(lpEnumFunc:pPROC; lParam:cardinal):boolean;
procedure EnumThreadWindows(dwThreadId:cardinal; lpfn:pPROC; lParam:cardinal):boolean;
procedure GetClassName ascii(hWnd:HWND; lpClassName:pstr; nMaxCount:integer):integer;
procedure GetTopWindow(hWnd:HWND):HWND;
procedure GetWindowThreadProcessId(hWnd:HWND; lpdwProcessId:pCARDINAL):cardinal;
procedure GetLastActivePopup(hWnd:HWND):HWND;

const GW_HWNDFIRST=0x00000000;
const GW_HWNDLAST=0x00000001;
const GW_HWNDNEXT=0x00000002;
const GW_HWNDPREV=0x00000003;
const GW_OWNER=0x00000004;
const GW_CHILD=0x00000005;
const GW_MAX=0x00000005;

procedure GetWindow(hWnd:HWND; uCmd:cardinal):HWND;
procedure SetWindowsHook ascii(nFilterType:integer; pfnFilterProc:pPROC):HHOOK;
procedure UnhookWindowsHook(nCode:integer; pfnFilterProc:pPROC):boolean;
procedure SetWindowsHookEx ascii(idHook:integer; lpfn:pPROC; hmod:HINSTANCE; dwThreadId:cardinal):HHOOK;
procedure UnhookWindowsHookEx(hhk:HHOOK):boolean;
procedure CallNextHookEx(hhk:HHOOK; nCode:integer; wParam:cardinal; lParam:cardinal):cardinal;

const MF_INSERT=0x00000000;
const MF_CHANGE=0x00000080;
const MF_APPEND=0x00000100;
const MF_DELETE=0x00000200;
const MF_REMOVE=0x00001000;
const MF_BYCOMMAND=0x00000000;
const MF_BYPOSITION=0x00000400;
const MF_SEPARATOR=0x00000800;
const MF_ENABLED=0x00000000;
const MF_GRAYED=0x00000001;
const MF_DISABLED=0x00000002;
const MF_UNCHECKED=0x00000000;
const MF_CHECKED=0x00000008;
const MF_USECHECKBITMAPS=0x00000200;
const MF_STRING=0x00000000;
const MF_BITMAP=0x00000004;
const MF_OWNERDRAW=0x00000100;
const MF_POPUP=0x00000010;
const MF_MENUBARBREAK=0x00000020;
const MF_MENUBREAK=0x00000040;
const MF_UNHILITE=0x00000000;
const MF_HILITE=0x00000080;
const MF_DEFAULT=0x00001000;
const MF_SYSMENU=0x00002000;
const MF_HELP=0x00004000;
const MF_RIGHTJUSTIFY=0x00004000;
const MF_MOUSESELECT=0x00008000;
const MF_END=0x00000080;
const MFT_STRING=MF_STRING;
const MFT_BITMAP=MF_BITMAP;
const MFT_MENUBARBREAK=MF_MENUBARBREAK;
const MFT_MENUBREAK=MF_MENUBREAK;
const MFT_OWNERDRAW=MF_OWNERDRAW;
const MFT_RADIOCHECK=0x00000200;
const MFT_SEPARATOR=MF_SEPARATOR;
const MFT_RIGHTORDER=0x00002000;
const MFT_RIGHTJUSTIFY=MF_RIGHTJUSTIFY;
const MFS_GRAYED=0x00000003;
const MFS_DISABLED=MFS_GRAYED;
const MFS_CHECKED=MF_CHECKED;
const MFS_HILITE=MF_HILITE;
const MFS_ENABLED=MF_ENABLED;
const MFS_UNCHECKED=MF_UNCHECKED;
const MFS_UNHILITE=MF_UNHILITE;
const MFS_DEFAULT=MF_DEFAULT;
procedure CheckMenuRadioItem(HMENU; cardinal; cardinal; cardinal; cardinal):boolean;
type MENUITEMTEMPLATEHEADER=record
       versionNumber:word;
       offset:word;
     end;
     pMENUITEMTEMPLATEHEADER=pointer to MENUITEMTEMPLATEHEADER;

type MENUITEMTEMPLATE=record
       mtOption:word;
       mtID:word;
       mtString:array[0..0]of word;
     end;
     pMENUITEMTEMPLATE=pointer to MENUITEMTEMPLATE;

const SC_SIZE=0x0000F000;
const SC_MOVE=0x0000F010;
const SC_MINIMIZE=0x0000F020;
const SC_MAXIMIZE=0x0000F030;
const SC_NEXTWINDOW=0x0000F040;
const SC_PREVWINDOW=0x0000F050;
const SC_CLOSE=0x0000F060;
const SC_VSCROLL=0x0000F070;
const SC_HSCROLL=0x0000F080;
const SC_MOUSEMENU=0x0000F090;
const SC_KEYMENU=0x0000F100;
const SC_ARRANGE=0x0000F110;
const SC_RESTORE=0x0000F120;
const SC_TASKLIST=0x0000F130;
const SC_SCREENSAVE=0x0000F140;
const SC_HOTKEY=0x0000F150;
const SC_DEFAULT=0x0000F160;
const SC_MONITORPOWER=0x0000F170;
const SC_CONTEXTHELP=0x0000F180;
const SC_SEPARATOR=0x0000F00F;
const SC_ICON=SC_MINIMIZE;
const SC_ZOOM=SC_MAXIMIZE;
procedure LoadBitmap ascii(hInstance:HINSTANCE; lpBitmapName:pstr):HBITMAP;
procedure LoadCursor ascii(hInstance:HINSTANCE; lpCursorName:pstr):HCURSOR;
procedure LoadCursorFromFile ascii(lpFileName:pstr):HCURSOR;
procedure CreateCursor(hInst:HINSTANCE; xHotSpot:integer; yHotSpot:integer; nWidth:integer; nHeight:integer; pvANDPlane:address; pvXORPlane:address):HCURSOR;
procedure DestroyCursor(hCursor:HCURSOR):boolean;
const IDC_ARROW=0x00007F00;
const IDC_IBEAM=0x00007F01;
const IDC_WAIT=0x00007F02;
const IDC_CROSS=0x00007F03;
const IDC_UPARROW=0x00007F04;
const IDC_SIZE=0x00007F80;
const IDC_ICON=0x00007F81;
const IDC_SIZENWSE=0x00007F82;
const IDC_SIZENESW=0x00007F83;
const IDC_SIZEWE=0x00007F84;
const IDC_SIZENS=0x00007F85;
const IDC_SIZEALL=0x00007F86;
const IDC_NO=0x00007F88;
const IDC_APPSTARTING=0x00007F8A;
const IDC_HELP=0x00007F8B;
procedure SetSystemCursor(hcur:HCURSOR; id:cardinal):boolean;
type ICONINFO=record
       fIcon:boolean;
       xHotspot:cardinal;
       yHotspot:cardinal;
       hbmMask:HBITMAP;
       hbmColor:HBITMAP;
     end;
     pICONINFO=pointer to ICONINFO;

procedure LoadIcon ascii(hInstance:HINSTANCE; lpIconName:pstr):HICON;
procedure CreateIcon(hInstance:HINSTANCE; nWidth:integer; nHeight:integer; cPlanes:byte; cBitsPixel:byte; lpbANDbits:pBYTE; lpbXORbits:pBYTE):HICON;
procedure DestroyIcon(hIcon:HICON):boolean;
procedure LookupIconIdFromDirectory(presbits:pBYTE; fIcon:boolean):integer;
procedure LookupIconIdFromDirectoryEx(presbits:pBYTE; fIcon:boolean; cxDesired:integer; cyDesired:integer; Flags:cardinal):integer;
procedure CreateIconFromResource(presbits:pBYTE; dwResSize:cardinal; fIcon:boolean; dwVer:cardinal):HICON;
procedure CreateIconFromResourceEx(presbits:pBYTE; dwResSize:cardinal; fIcon:boolean; dwVer:cardinal; cxDesired:integer; cyDesired:integer; Flags:cardinal):HICON;

type CURSORSHAPE=record
       xHotSpot:integer;
       yHotSpot:integer;
       cx:integer;
       cy:integer;
       cbWidth:integer;
       Planes:byte;
       BitsPixel:byte;
     end;
     pCURSORSHAPE=pointer to CURSORSHAPE;

const IMAGE_BITMAP=0x00000000;
const IMAGE_ICON=0x00000001;
const IMAGE_CURSOR=0x00000002;
const IMAGE_ENHMETAFILE=0x00000003;
const LR_DEFAULTCOLOR=0x00000000;
const LR_MONOCHROME=0x00000001;
const LR_COLOR=0x00000002;
const LR_COPYRETURNORG=0x00000004;
const LR_COPYDELETEORG=0x00000008;
const LR_LOADFROMFILE=0x00000010;
const LR_LOADTRANSPARENT=0x00000020;
const LR_DEFAULTSIZE=0x00000040;
const LR_VGACOLOR=0x00000080;
const LR_LOADMAP3DCOLORS=0x00001000;
const LR_CREATEDIBSECTION=0x00002000;
const LR_COPYFROMRESOURCE=0x00004000;
const LR_SHARED=0x00008000;
procedure LoadImage ascii(HINSTANCE; pstr; cardinal; integer; integer; cardinal):HANDLE;
procedure CopyImage(HANDLE; cardinal; integer; integer; cardinal):HANDLE;
const DI_MASK=0x00000001;
const DI_IMAGE=0x00000002;
const DI_NORMAL=0x00000003;
const DI_COMPAT=0x00000004;
const DI_DEFAULTSIZE=0x00000008;

procedure DrawIconEx(hdc:HDC; xLeft:integer; yTop:integer; hIcon:HICON; cxWidth:integer; cyWidth:integer; istepIfAniCur:cardinal; hbrFlickerFreeDraw:HBRUSH; diFlags:cardinal):boolean;
procedure CreateIconIndirect(piconinfo:pICONINFO):HICON;
procedure CopyIcon(hIcon:HICON):HICON;
procedure GetIconInfo(hIcon:HICON; piconinfo:pICONINFO):boolean;

const RES_ICON=0x00000001;
const RES_CURSOR=0x00000002;
const OBM_CLOSE=0x00007FF2;
const OBM_UPARROW=0x00007FF1;
const OBM_DNARROW=0x00007FF0;
const OBM_RGARROW=0x00007FEF;
const OBM_LFARROW=0x00007FEE;
const OBM_REDUCE=0x00007FED;
const OBM_ZOOM=0x00007FEC;
const OBM_RESTORE=0x00007FEB;
const OBM_REDUCED=0x00007FEA;
const OBM_ZOOMD=0x00007FE9;
const OBM_RESTORED=0x00007FE8;
const OBM_UPARROWD=0x00007FE7;
const OBM_DNARROWD=0x00007FE6;
const OBM_RGARROWD=0x00007FE5;
const OBM_LFARROWD=0x00007FE4;
const OBM_MNARROW=0x00007FE3;
const OBM_COMBO=0x00007FE2;
const OBM_UPARROWI=0x00007FE1;
const OBM_DNARROWI=0x00007FE0;
const OBM_RGARROWI=0x00007FDF;
const OBM_LFARROWI=0x00007FDE;
const OBM_OLD_CLOSE=0x00007FFF;
const OBM_SIZE=0x00007FFE;
const OBM_OLD_UPARROW=0x00007FFD;
const OBM_OLD_DNARROW=0x00007FFC;
const OBM_OLD_RGARROW=0x00007FFB;
const OBM_OLD_LFARROW=0x00007FFA;
const OBM_BTSIZE=0x00007FF9;
const OBM_CHECK=0x00007FF8;
const OBM_CHECKBOXES=0x00007FF7;
const OBM_BTNCORNERS=0x00007FF6;
const OBM_OLD_REDUCE=0x00007FF5;
const OBM_OLD_ZOOM=0x00007FF4;
const OBM_OLD_RESTORE=0x00007FF3;
const OCR_NORMAL=0x00007F00;
const OCR_IBEAM=0x00007F01;
const OCR_WAIT=0x00007F02;
const OCR_CROSS=0x00007F03;
const OCR_UP=0x00007F04;
const OCR_SIZE=0x00007F80;
const OCR_ICON=0x00007F81;
const OCR_SIZENWSE=0x00007F82;
const OCR_SIZENESW=0x00007F83;
const OCR_SIZEWE=0x00007F84;
const OCR_SIZENS=0x00007F85;
const OCR_SIZEALL=0x00007F86;
const OCR_ICOCUR=0x00007F87;
const OCR_NO=0x00007F88;
const OCR_APPSTARTING=0x00007F8A;
const OIC_SAMPLE=0x00007F00;
const OIC_HAND=0x00007F01;
const OIC_QUES=0x00007F02;
const OIC_BANG=0x00007F03;
const OIC_NOTE=0x00007F04;
const OIC_WINLOGO=0x00007F05;
const OIC_WARNING=OIC_BANG;
const OIC_ERROR=OIC_HAND;
const OIC_INFORMATION=OIC_NOTE;
const ORD_LANGDRIVER=0x00000001;
const IDI_APPLICATION=0x00007F00;
const IDI_HAND=0x00007F01;
const IDI_QUESTION=0x00007F02;
const IDI_EXCLAMATION=0x00007F03;
const IDI_ASTERISK=0x00007F04;
const IDI_WINLOGO=0x00007F05;
const IDI_WARNING=IDI_EXCLAMATION;
const IDI_ERROR=IDI_HAND;
const IDI_INFORMATION=IDI_ASTERISK;
procedure LoadString ascii(hInstance:HINSTANCE; uID:cardinal; lpBuffer:pstr; nBufferMax:integer):integer;
const IDOK=0x00000001;
const IDCANCEL=0x00000002;
const IDABORT=0x00000003;
const IDRETRY=0x00000004;
const IDIGNORE=0x00000005;
const IDYES=0x00000006;
const IDNO=0x00000007;
const IDCLOSE=0x00000008;
const IDHELP=0x00000009;
const ES_LEFT=0x00000000;
const ES_CENTER=0x00000001;
const ES_RIGHT=0x00000002;
const ES_MULTILINE=0x00000004;
const ES_UPPERCASE=0x00000008;
const ES_LOWERCASE=0x00000010;
const ES_PASSWORD=0x00000020;
const ES_AUTOVSCROLL=0x00000040;
const ES_AUTOHSCROLL=0x00000080;
const ES_NOHIDESEL=0x00000100;
const ES_OEMCONVERT=0x00000400;
const ES_READONLY=0x00000800;
const ES_WANTRETURN=0x00001000;
const ES_NUMBER=0x00002000;
const EN_SETFOCUS=0x00000100;
const EN_KILLFOCUS=0x00000200;
const EN_CHANGE=0x00000300;
const EN_UPDATE=0x00000400;
const EN_ERRSPACE=0x00000500;
const EN_MAXTEXT=0x00000501;
const EN_HSCROLL=0x00000601;
const EN_VSCROLL=0x00000602;
const EC_LEFTMARGIN=0x00000001;
const EC_RIGHTMARGIN=0x00000002;
const EC_USEFONTINFO=0x0000FFFF;
const EM_GETSEL=0x000000B0;
const EM_SETSEL=0x000000B1;
const EM_GETRECT=0x000000B2;
const EM_SETRECT=0x000000B3;
const EM_SETRECTNP=0x000000B4;
const EM_SCROLL=0x000000B5;
const EM_LINESCROLL=0x000000B6;
const EM_SCROLLCARET=0x000000B7;
const EM_GETMODIFY=0x000000B8;
const EM_SETMODIFY=0x000000B9;
const EM_GETLINECOUNT=0x000000BA;
const EM_LINEINDEX=0x000000BB;
const EM_SETHANDLE=0x000000BC;
const EM_GETHANDLE=0x000000BD;
const EM_GETTHUMB=0x000000BE;
const EM_LINELENGTH=0x000000C1;
const EM_REPLACESEL=0x000000C2;
const EM_GETLINE=0x000000C4;
const EM_LIMITTEXT=0x000000C5;
const EM_CANUNDO=0x000000C6;
const EM_UNDO=0x000000C7;
const EM_FMTLINES=0x000000C8;
const EM_LINEFROMCHAR=0x000000C9;
const EM_SETTABSTOPS=0x000000CB;
const EM_SETPASSWORDCHAR=0x000000CC;
const EM_EMPTYUNDOBUFFER=0x000000CD;
const EM_GETFIRSTVISIBLELINE=0x000000CE;
const EM_SETREADONLY=0x000000CF;
const EM_SETWORDBREAKPROC=0x000000D0;
const EM_GETWORDBREAKPROC=0x000000D1;
const EM_GETPASSWORDCHAR=0x000000D2;
const EM_SETMARGINS=0x000000D3;
const EM_GETMARGINS=0x000000D4;
const EM_SETLIMITTEXT=EM_LIMITTEXT;
const EM_GETLIMITTEXT=0x000000D5;
const EM_POSFROMCHAR=0x000000D6;
const EM_CHARFROMPOS=0x000000D7;
const WB_LEFT=0x00000000;
const WB_RIGHT=0x00000001;
const WB_ISDELIMITER=0x00000002;
const BS_PUSHBUTTON=0x00000000;
const BS_DEFPUSHBUTTON=0x00000001;
const BS_CHECKBOX=0x00000002;
const BS_AUTOCHECKBOX=0x00000003;
const BS_RADIOBUTTON=0x00000004;
const BS_3STATE=0x00000005;
const BS_AUTO3STATE=0x00000006;
const BS_GROUPBOX=0x00000007;
const BS_USERBUTTON=0x00000008;
const BS_AUTORADIOBUTTON=0x00000009;
const BS_OWNERDRAW=0x0000000B;
const BS_LEFTTEXT=0x00000020;
const BS_TEXT=0x00000000;
const BS_ICON=0x00000040;
const BS_BITMAP=0x00000080;
const BS_LEFT=0x00000100;
const BS_RIGHT=0x00000200;
const BS_CENTER=0x00000300;
const BS_TOP=0x00000400;
const BS_BOTTOM=0x00000800;
const BS_VCENTER=0x00000C00;
const BS_PUSHLIKE=0x00001000;
const BS_MULTILINE=0x00002000;
const BS_NOTIFY=0x00004000;
const BS_FLAT=0x00008000;
const BS_RIGHTBUTTON=BS_LEFTTEXT;
const BN_CLICKED=0x00000000;
const BN_PAINT=0x00000001;
const BN_HILITE=0x00000002;
const BN_UNHILITE=0x00000003;
const BN_DISABLE=0x00000004;
const BN_DOUBLECLICKED=0x00000005;
const BN_PUSHED=BN_HILITE;
const BN_UNPUSHED=BN_UNHILITE;
const BN_DBLCLK=BN_DOUBLECLICKED;
const BN_SETFOCUS=0x00000006;
const BN_KILLFOCUS=0x00000007;
const BM_GETCHECK=0x000000F0;
const BM_SETCHECK=0x000000F1;
const BM_GETSTATE=0x000000F2;
const BM_SETSTATE=0x000000F3;
const BM_SETSTYLE=0x000000F4;
const BM_CLICK=0x000000F5;
const BM_GETIMAGE=0x000000F6;
const BM_SETIMAGE=0x000000F7;
const BST_UNCHECKED=0x00000000;
const BST_CHECKED=0x00000001;
const BST_INDETERMINATE=0x00000002;
const BST_PUSHED=0x00000004;
const BST_FOCUS=0x00000008;
const SS_LEFT=0x00000000;
const SS_CENTER=0x00000001;
const SS_RIGHT=0x00000002;
const SS_ICON=0x00000003;
const SS_BLACKRECT=0x00000004;
const SS_GRAYRECT=0x00000005;
const SS_WHITERECT=0x00000006;
const SS_BLACKFRAME=0x00000007;
const SS_GRAYFRAME=0x00000008;
const SS_WHITEFRAME=0x00000009;
const SS_USERITEM=0x0000000A;
const SS_SIMPLE=0x0000000B;
const SS_LEFTNOWORDWRAP=0x0000000C;
const SS_OWNERDRAW=0x0000000D;
const SS_BITMAP=0x0000000E;
const SS_ENHMETAFILE=0x0000000F;
const SS_ETCHEDHORZ=0x00000010;
const SS_ETCHEDVERT=0x00000011;
const SS_ETCHEDFRAME=0x00000012;
const SS_TYPEMASK=0x0000001F;
const SS_NOPREFIX=0x00000080;
const SS_NOTIFY=0x00000100;
const SS_CENTERIMAGE=0x00000200;
const SS_RIGHTJUST=0x00000400;
const SS_REALSIZEIMAGE=0x00000800;
const SS_SUNKEN=0x00001000;
const SS_ENDELLIPSIS=0x00004000;
const SS_PATHELLIPSIS=0x00008000;
const SS_WORDELLIPSIS=0x0000C000;
const SS_ELLIPSISMASK=0x0000C000;
const STM_SETICON=0x00000170;
const STM_GETICON=0x00000171;
const STM_SETIMAGE=0x00000172;
const STM_GETIMAGE=0x00000173;
const STN_CLICKED=0x00000000;
const STN_DBLCLK=0x00000001;
const STN_ENABLE=0x00000002;
const STN_DISABLE=0x00000003;
const STM_MSGMAX=0x00000174;
const WC_DIALOG=0x00008002;
const DWL_MSGRESULT=0x00000000;
const DWL_DLGPROC=0x00000004;
const DWL_USER=0x00000008;

procedure IsDialogMessage ascii(hDlg:HWND; lpMsg:pMSG):boolean;
procedure MapDialogRect(hDlg:HWND; lpRect:pRECT):boolean;
procedure DlgDirList ascii(hDlg:HWND; lpPathSpec:pstr; nIDListBox:integer; nIDStaticPath:integer; uFileType:cardinal):integer;

const DDL_READWRITE=0x00000000;
const DDL_READONLY=0x00000001;
const DDL_HIDDEN=0x00000002;
const DDL_SYSTEM=0x00000004;
const DDL_DIRECTORY=0x00000010;
const DDL_ARCHIVE=0x00000020;
const DDL_POSTMSGS=0x00002000;
const DDL_DRIVES=0x00004000;
const DDL_EXCLUSIVE=0x00008000;
procedure DlgDirSelectEx ascii(hDlg:HWND; lpString:pstr; nCount:integer; nIDListBox:integer):boolean;
procedure DlgDirListComboBox ascii(hDlg:HWND; lpPathSpec:pstr; nIDComboBox:integer; nIDStaticPath:integer; uFiletype:cardinal):integer;
procedure DlgDirSelectComboBoxEx ascii(hDlg:HWND; lpString:pstr; nCount:integer; nIDComboBox:integer):boolean;
const DS_ABSALIGN=0x00000001;
const DS_SYSMODAL=0x00000002;
const DS_LOCALEDIT=0x00000020;
const DS_SETFONT=0x00000040;
const DS_MODALFRAME=0x00000080;
const DS_NOIDLEMSG=0x00000100;
const DS_SETFOREGROUND=0x00000200;
const DS_3DLOOK=0x00000004;
const DS_FIXEDSYS=0x00000008;
const DS_NOFAILCREATE=0x00000010;
const DS_CONTROL=0x00000400;
const DS_CENTER=0x00000800;
const DS_CENTERMOUSE=0x00001000;
const DS_CONTEXTHELP=0x00002000;
const DM_GETDEFID=WM_USER+0;
const DM_SETDEFID=WM_USER+1;
const DM_REPOSITION=WM_USER+2;
const PSM_PAGEINFO=WM_USER+100;
const PSM_SHEETINFO=WM_USER+101;
const PSI_SETACTIVE=0x00000001;
const PSI_KILLACTIVE=0x00000002;
const PSI_APPLY=0x00000003;
const PSI_RESET=0x00000004;
const PSI_HASHELP=0x00000005;
const PSI_HELP=0x00000006;
const PSI_CHANGED=0x00000001;
const PSI_GUISTART=0x00000002;
const PSI_REBOOT=0x00000003;
const PSI_GETSIBLINGS=0x00000004;
const DC_HASDEFID=0x0000534B;
const DLGC_WANTARROWS=0x00000001;
const DLGC_WANTTAB=0x00000002;
const DLGC_WANTALLKEYS=0x00000004;
const DLGC_WANTMESSAGE=0x00000004;
const DLGC_HASSETSEL=0x00000008;
const DLGC_DEFPUSHBUTTON=0x00000010;
const DLGC_UNDEFPUSHBUTTON=0x00000020;
const DLGC_RADIOBUTTON=0x00000040;
const DLGC_WANTCHARS=0x00000080;
const DLGC_STATIC=0x00000100;
const DLGC_BUTTON=0x00002000;
const LB_CTLCODE=0x00000000;
const LB_OKAY=0x00000000;
const LB_ERR=-0x00000001;
const LB_ERRSPACE=-0x00000002;
const LBN_ERRSPACE=-0x00000002;
const LBN_SELCHANGE=0x00000001;
const LBN_DBLCLK=0x00000002;
const LBN_SELCANCEL=0x00000003;
const LBN_SETFOCUS=0x00000004;
const LBN_KILLFOCUS=0x00000005;
const LB_ADDSTRING=0x00000180;
const LB_INSERTSTRING=0x00000181;
const LB_DELETESTRING=0x00000182;
const LB_SELITEMRANGEEX=0x00000183;
const LB_RESETCONTENT=0x00000184;
const LB_SETSEL=0x00000185;
const LB_SETCURSEL=0x00000186;
const LB_GETSEL=0x00000187;
const LB_GETCURSEL=0x00000188;
const LB_GETTEXT=0x00000189;
const LB_GETTEXTLEN=0x0000018A;
const LB_GETCOUNT=0x0000018B;
const LB_SELECTSTRING=0x0000018C;
const LB_DIR=0x0000018D;
const LB_GETTOPINDEX=0x0000018E;
const LB_FINDSTRING=0x0000018F;
const LB_GETSELCOUNT=0x00000190;
const LB_GETSELITEMS=0x00000191;
const LB_SETTABSTOPS=0x00000192;
const LB_GETHORIZONTALEXTENT=0x00000193;
const LB_SETHORIZONTALEXTENT=0x00000194;
const LB_SETCOLUMNWIDTH=0x00000195;
const LB_ADDFILE=0x00000196;
const LB_SETTOPINDEX=0x00000197;
const LB_GETITEMRECT=0x00000198;
const LB_GETITEMDATA=0x00000199;
const LB_SETITEMDATA=0x0000019A;
const LB_SELITEMRANGE=0x0000019B;
const LB_SETANCHORINDEX=0x0000019C;
const LB_GETANCHORINDEX=0x0000019D;
const LB_SETCARETINDEX=0x0000019E;
const LB_GETCARETINDEX=0x0000019F;
const LB_SETITEMHEIGHT=0x000001A0;
const LB_GETITEMHEIGHT=0x000001A1;
const LB_FINDSTRINGEXACT=0x000001A2;
const LB_SETLOCALE=0x000001A5;
const LB_GETLOCALE=0x000001A6;
const LB_SETCOUNT=0x000001A7;
const LB_INITSTORAGE=0x000001A8;
const LB_ITEMFROMPOINT=0x000001A9;
const LB_MSGMAX=0x000001B0;
const LBS_NOTIFY=0x00000001;
const LBS_SORT=0x00000002;
const LBS_NOREDRAW=0x00000004;
const LBS_MULTIPLESEL=0x00000008;
const LBS_OWNERDRAWFIXED=0x00000010;
const LBS_OWNERDRAWVARIABLE=0x00000020;
const LBS_HASSTRINGS=0x00000040;
const LBS_USETABSTOPS=0x00000080;
const LBS_NOINTEGRALHEIGHT=0x00000100;
const LBS_MULTICOLUMN=0x00000200;
const LBS_WANTKEYBOARDINPUT=0x00000400;
const LBS_EXTENDEDSEL=0x00000800;
const LBS_DISABLENOSCROLL=0x00001000;
const LBS_NODATA=0x00002000;
const LBS_NOSEL=0x00004000;
const LBS_STANDARD=LBS_NOTIFY|LBS_SORT|WS_VSCROLL|WS_BORDER;
const CB_OKAY=0x00000000;
const CB_ERR=-0x00000001;
const CB_ERRSPACE=-0x00000002;
const CBN_ERRSPACE=-0x00000001;
const CBN_SELCHANGE=0x00000001;
const CBN_DBLCLK=0x00000002;
const CBN_SETFOCUS=0x00000003;
const CBN_KILLFOCUS=0x00000004;
const CBN_EDITCHANGE=0x00000005;
const CBN_EDITUPDATE=0x00000006;
const CBN_DROPDOWN=0x00000007;
const CBN_CLOSEUP=0x00000008;
const CBN_SELENDOK=0x00000009;
const CBN_SELENDCANCEL=0x0000000A;
const CBS_SIMPLE=0x00000001;
const CBS_DROPDOWN=0x00000002;
const CBS_DROPDOWNLIST=0x00000003;
const CBS_OWNERDRAWFIXED=0x00000010;
const CBS_OWNERDRAWVARIABLE=0x00000020;
const CBS_AUTOHSCROLL=0x00000040;
const CBS_OEMCONVERT=0x00000080;
const CBS_SORT=0x00000100;
const CBS_HASSTRINGS=0x00000200;
const CBS_NOINTEGRALHEIGHT=0x00000400;
const CBS_DISABLENOSCROLL=0x00000800;
const CBS_UPPERCASE=0x00002000;
const CBS_LOWERCASE=0x00004000;
const CB_GETEDITSEL=0x00000140;
const CB_LIMITTEXT=0x00000141;
const CB_SETEDITSEL=0x00000142;
const CB_ADDSTRING=0x00000143;
const CB_DELETESTRING=0x00000144;
const CB_DIR=0x00000145;
const CB_GETCOUNT=0x00000146;
const CB_GETCURSEL=0x00000147;
const CB_GETLBTEXT=0x00000148;
const CB_GETLBTEXTLEN=0x00000149;
const CB_INSERTSTRING=0x0000014A;
const CB_RESETCONTENT=0x0000014B;
const CB_FINDSTRING=0x0000014C;
const CB_SELECTSTRING=0x0000014D;
const CB_SETCURSEL=0x0000014E;
const CB_SHOWDROPDOWN=0x0000014F;
const CB_GETITEMDATA=0x00000150;
const CB_SETITEMDATA=0x00000151;
const CB_GETDROPPEDCONTROLRECT=0x00000152;
const CB_SETITEMHEIGHT=0x00000153;
const CB_GETITEMHEIGHT=0x00000154;
const CB_SETEXTENDEDUI=0x00000155;
const CB_GETEXTENDEDUI=0x00000156;
const CB_GETDROPPEDSTATE=0x00000157;
const CB_FINDSTRINGEXACT=0x00000158;
const CB_SETLOCALE=0x00000159;
const CB_GETLOCALE=0x0000015A;
const CB_GETTOPINDEX=0x0000015B;
const CB_SETTOPINDEX=0x0000015C;
const CB_GETHORIZONTALEXTENT=0x0000015D;
const CB_SETHORIZONTALEXTENT=0x0000015E;
const CB_GETDROPPEDWIDTH=0x0000015F;
const CB_SETDROPPEDWIDTH=0x00000160;
const CB_INITSTORAGE=0x00000161;
const CB_MSGMAX=0x00000162;
const SBS_HORZ=0x00000000;
const SBS_VERT=0x00000001;
const SBS_TOPALIGN=0x00000002;
const SBS_LEFTALIGN=0x00000002;
const SBS_BOTTOMALIGN=0x00000004;
const SBS_RIGHTALIGN=0x00000004;
const SBS_SIZEBOXTOPLEFTALIGN=0x00000002;
const SBS_SIZEBOXBOTTOMRIGHTALIGN=0x00000004;
const SBS_SIZEBOX=0x00000008;
const SBS_SIZEGRIP=0x00000010;
const SBM_SETPOS=0x000000E0;
const SBM_GETPOS=0x000000E1;
const SBM_SETRANGE=0x000000E2;
const SBM_SETRANGEREDRAW=0x000000E6;
const SBM_GETRANGE=0x000000E3;
const SBM_ENABLE_ARROWS=0x000000E4;
const SBM_SETSCROLLINFO=0x000000E9;
const SBM_GETSCROLLINFO=0x000000EA;
const SIF_RANGE=0x00000001;
const SIF_PAGE=0x00000002;
const SIF_POS=0x00000004;
const SIF_DISABLENOSCROLL=0x00000008;
const SIF_TRACKPOS=0x00000010;
const SIF_ALL=SIF_RANGE|SIF_PAGE|SIF_POS|SIF_TRACKPOS;
type SCROLLINFO=record
       cbSize:cardinal;
       fMask:cardinal;
       nMin:integer;
       nMax:integer;
       nPage:cardinal;
       nPos:integer;
       nTrackPos:integer;
     end;
     pSCROLLINFO=pointer to SCROLLINFO;

procedure SetScrollInfo(HWND; integer; pSCROLLINFO; boolean):integer;
procedure GetScrollInfo(HWND; integer; pSCROLLINFO):boolean;

const MDIS_ALLCHILDSTYLES=0x00000001;
const MDITILE_VERTICAL=0x00000000;
const MDITILE_HORIZONTAL=0x00000001;
const MDITILE_SKIPDISABLED=0x00000002;
type MDICREATESTRUCT=record
       szClass:pstr;
       szTitle:pstr;
       hOwner:HANDLE;
       x:integer;
       y:integer;
       cx:integer;
       cy:integer;
       style:cardinal;
       lParam:cardinal;
     end;
     pMDICREATESTRUCT=pointer to MDICREATESTRUCT;

type CLIENTCREATESTRUCT=record
       hWindowMenu:HANDLE;
       idFirstChild:cardinal;
     end;
     pCLIENTCREATESTRUCT=pointer to CLIENTCREATESTRUCT;

procedure DefFrameProc ascii(hWnd:HWND; hWndMDIClient:HWND; uMsg:cardinal; wParam:cardinal; lParam:cardinal):cardinal;
procedure DefMDIChildProc ascii(hWnd:HWND; uMsg:cardinal; wParam:cardinal; lParam:cardinal):cardinal;
procedure TranslateMDISysAccel(hWndClient:HWND; lpMsg:pMSG):boolean;
procedure ArrangeIconicWindows(hWnd:HWND):cardinal;
procedure CreateMDIWindow ascii(lpClassName:pstr; lpWindowName:pstr; dwStyle:cardinal; X:integer; Y:integer; nWidth:integer; nHeight:integer; hWndParent:HWND; hInstance:HINSTANCE; lParam:cardinal):HWND;
procedure TileWindows(hwndParent:HWND; wHow:cardinal; lpRect:pRECT; cKids:cardinal; lpKids:pHWND):word;
procedure CascadeWindows(hwndParent:HWND; wHow:cardinal; lpRect:pRECT; cKids:cardinal; lpKids:pHWND):word;

type HELPPOLY=cardinal;
type MULTIKEYHELP=record
       mkSize:cardinal;
       mkKeylist:char;
       szKeyphrase:array[0..0]of char;
     end;
     pMULTIKEYHELP=pointer to MULTIKEYHELP;

type HELPWININFO=record
       wStructSize:integer;
       x:integer;
       y:integer;
       dx:integer;
       dy:integer;
       wMax:integer;
       rgchMember:array[0..1]of char;
     end;
     pHELPWININFO=pointer to HELPWININFO;

const HELP_CONTEXT=0x00000001;
const HELP_QUIT=0x00000002;
const HELP_INDEX=0x00000003;
const HELP_CONTENTS=0x00000003;
const HELP_HELPONHELP=0x00000004;
const HELP_SETINDEX=0x00000005;
const HELP_SETCONTENTS=0x00000005;
const HELP_CONTEXTPOPUP=0x00000008;
const HELP_FORCEFILE=0x00000009;
const HELP_KEY=0x00000101;
const HELP_COMMAND=0x00000102;
const HELP_PARTIALKEY=0x00000105;
const HELP_MULTIKEY=0x00000201;
const HELP_SETWINPOS=0x00000203;
const HELP_CONTEXTMENU=0x0000000A;
const HELP_FINDER=0x0000000B;
const HELP_WM_HELP=0x0000000C;
const HELP_SETPOPUP_POS=0x0000000D;
const HELP_TCARD=0x00008000;
const HELP_TCARD_DATA=0x00000010;
const HELP_TCARD_OTHER_CALLER=0x00000011;
const IDH_NO_HELP=0x00006F18;
const IDH_MISSING_CONTEXT=0x00006F19;
const IDH_GENERIC_HELP_BUTTON=0x00006F1A;
const IDH_OK=0x00006F1B;
const IDH_CANCEL=0x00006F1C;
const IDH_HELP=0x00006F1D;
procedure WinHelp ascii(hWndMain:HWND; lpszHelp:pstr; uCommand:cardinal; dwData:cardinal):boolean;
const SPI_GETBEEP=0x00000001;
const SPI_SETBEEP=0x00000002;
const SPI_GETMOUSE=0x00000003;
const SPI_SETMOUSE=0x00000004;
const SPI_GETBORDER=0x00000005;
const SPI_SETBORDER=0x00000006;
const SPI_GETKEYBOARDSPEED=0x0000000A;
const SPI_SETKEYBOARDSPEED=0x0000000B;
const SPI_LANGDRIVER=0x0000000C;
const SPI_ICONHORIZONTALSPACING=0x0000000D;
const SPI_GETSCREENSAVETIMEOUT=0x0000000E;
const SPI_SETSCREENSAVETIMEOUT=0x0000000F;
const SPI_GETSCREENSAVEACTIVE=0x00000010;
const SPI_SETSCREENSAVEACTIVE=0x00000011;
const SPI_GETGRIDGRANULARITY=0x00000012;
const SPI_SETGRIDGRANULARITY=0x00000013;
const SPI_SETDESKWALLPAPER=0x00000014;
const SPI_SETDESKPATTERN=0x00000015;
const SPI_GETKEYBOARDDELAY=0x00000016;
const SPI_SETKEYBOARDDELAY=0x00000017;
const SPI_ICONVERTICALSPACING=0x00000018;
const SPI_GETICONTITLEWRAP=0x00000019;
const SPI_SETICONTITLEWRAP=0x0000001A;
const SPI_GETMENUDROPALIGNMENT=0x0000001B;
const SPI_SETMENUDROPALIGNMENT=0x0000001C;
const SPI_SETDOUBLECLKWIDTH=0x0000001D;
const SPI_SETDOUBLECLKHEIGHT=0x0000001E;
const SPI_GETICONTITLELOGFONT=0x0000001F;
const SPI_SETDOUBLECLICKTIME=0x00000020;
const SPI_SETMOUSEBUTTONSWAP=0x00000021;
const SPI_SETICONTITLELOGFONT=0x00000022;
const SPI_GETFASTTASKSWITCH=0x00000023;
const SPI_SETFASTTASKSWITCH=0x00000024;
const SPI_SETDRAGFULLWINDOWS=0x00000025;
const SPI_GETDRAGFULLWINDOWS=0x00000026;
const SPI_GETNONCLIENTMETRICS=0x00000029;
const SPI_SETNONCLIENTMETRICS=0x0000002A;
const SPI_GETMINIMIZEDMETRICS=0x0000002B;
const SPI_SETMINIMIZEDMETRICS=0x0000002C;
const SPI_GETICONMETRICS=0x0000002D;
const SPI_SETICONMETRICS=0x0000002E;
const SPI_SETWORKAREA=0x0000002F;
const SPI_GETWORKAREA=0x00000030;
const SPI_SETPENWINDOWS=0x00000031;
const SPI_GETHIGHCONTRAST=0x00000042;
const SPI_SETHIGHCONTRAST=0x00000043;
const SPI_GETKEYBOARDPREF=0x00000044;
const SPI_SETKEYBOARDPREF=0x00000045;
const SPI_GETSCREENREADER=0x00000046;
const SPI_SETSCREENREADER=0x00000047;
const SPI_GETANIMATION=0x00000048;
const SPI_SETANIMATION=0x00000049;
const SPI_GETFONTSMOOTHING=0x0000004A;
const SPI_SETFONTSMOOTHING=0x0000004B;
const SPI_SETDRAGWIDTH=0x0000004C;
const SPI_SETDRAGHEIGHT=0x0000004D;
const SPI_SETHANDHELD=0x0000004E;
const SPI_GETLOWPOWERTIMEOUT=0x0000004F;
const SPI_GETPOWEROFFTIMEOUT=0x00000050;
const SPI_SETLOWPOWERTIMEOUT=0x00000051;
const SPI_SETPOWEROFFTIMEOUT=0x00000052;
const SPI_GETLOWPOWERACTIVE=0x00000053;
const SPI_GETPOWEROFFACTIVE=0x00000054;
const SPI_SETLOWPOWERACTIVE=0x00000055;
const SPI_SETPOWEROFFACTIVE=0x00000056;
const SPI_SETCURSORS=0x00000057;
const SPI_SETICONS=0x00000058;
const SPI_GETDEFAULTINPUTLANG=0x00000059;
const SPI_SETDEFAULTINPUTLANG=0x0000005A;
const SPI_SETLANGTOGGLE=0x0000005B;
const SPI_GETWINDOWSEXTENSION=0x0000005C;
const SPI_SETMOUSETRAILS=0x0000005D;
const SPI_GETMOUSETRAILS=0x0000005E;
const SPI_SCREENSAVERRUNNING=0x00000061;
const SPI_GETFILTERKEYS=0x00000032;
const SPI_SETFILTERKEYS=0x00000033;
const SPI_GETTOGGLEKEYS=0x00000034;
const SPI_SETTOGGLEKEYS=0x00000035;
const SPI_GETMOUSEKEYS=0x00000036;
const SPI_SETMOUSEKEYS=0x00000037;
const SPI_GETSHOWSOUNDS=0x00000038;
const SPI_SETSHOWSOUNDS=0x00000039;
const SPI_GETSTICKYKEYS=0x0000003A;
const SPI_SETSTICKYKEYS=0x0000003B;
const SPI_GETACCESSTIMEOUT=0x0000003C;
const SPI_SETACCESSTIMEOUT=0x0000003D;
const SPI_GETSERIALKEYS=0x0000003E;
const SPI_SETSERIALKEYS=0x0000003F;
const SPI_GETSOUNDSENTRY=0x00000040;
const SPI_SETSOUNDSENTRY=0x00000041;
const SPI_GETSNAPTODEFBUTTON=0x0000005F;
const SPI_SETSNAPTODEFBUTTON=0x00000060;
const SPI_GETMOUSEHOVERWIDTH=0x00000062;
const SPI_SETMOUSEHOVERWIDTH=0x00000063;
const SPI_GETMOUSEHOVERHEIGHT=0x00000064;
const SPI_SETMOUSEHOVERHEIGHT=0x00000065;
const SPI_GETMOUSEHOVERTIME=0x00000066;
const SPI_SETMOUSEHOVERTIME=0x00000067;
const SPI_GETWHEELSCROLLLINES=0x00000068;
const SPI_SETWHEELSCROLLLINES=0x00000069;
const SPIF_UPDATEINIFILE=0x00000001;
const SPIF_SENDWININICHANGE=0x00000002;
const SPIF_SENDCHANGE=SPIF_SENDWININICHANGE;
const METRICS_USEDEFAULT=-0x00000001;
type NONCLIENTMETRICS=record
       cbSize:cardinal;
       iBorderWidth:integer;
       iScrollWidth:integer;
       iScrollHeight:integer;
       iCaptionWidth:integer;
       iCaptionHeight:integer;
       lfCaptionFont:LOGFONT;
       iSmCaptionWidth:integer;
       iSmCaptionHeight:integer;
       lfSmCaptionFont:LOGFONT;
       iMenuWidth:integer;
       iMenuHeight:integer;
       lfMenuFont:LOGFONT;
       lfStatusFont:LOGFONT;
       lfMessageFont:LOGFONT;
     end;
     pNONCLIENTMETRICS=pointer to NONCLIENTMETRICS;

const ARW_BOTTOMLEFT=0x00000000;
const ARW_BOTTOMRIGHT=0x00000001;
const ARW_TOPLEFT=0x00000002;
const ARW_TOPRIGHT=0x00000003;
const ARW_STARTMASK=0x00000003;
const ARW_STARTRIGHT=0x00000001;
const ARW_STARTTOP=0x00000002;
const ARW_LEFT=0x00000000;
const ARW_RIGHT=0x00000000;
const ARW_UP=0x00000004;
const ARW_DOWN=0x00000004;
const ARW_HIDE=0x00000008;
const ARW_VALID=0x0000000F;
type MINIMIZEDMETRICS=record
       cbSize:cardinal;
       iWidth:integer;
       iHorzGap:integer;
       iVertGap:integer;
       iArrange:integer;
     end;
     pMINIMIZEDMETRICS=pointer to MINIMIZEDMETRICS;

type ICONMETRICS=record
       cbSize:cardinal;
       iHorzSpacing:integer;
       iVertSpacing:integer;
       iTitleWrap:integer;
       lfFont:LOGFONT;
     end;
     pICONMETRICS=pointer to ICONMETRICS;

type ANIMATIONINFO=record
       cbSize:cardinal;
       iMinAnimate:integer;
     end;
     pANIMATIONINFO=pointer to ANIMATIONINFO;

type SERIALKEYS=record
       cbSize:cardinal;
       dwFlags:cardinal;
       lpszActivePort:pstr;
       lpszPort:pstr;
       iBaudRate:cardinal;
       iPortState:cardinal;
       iActive:cardinal;
     end;
     pSERIALKEYS=pointer to SERIALKEYS;

const SERKF_SERIALKEYSON=0x00000001;
const SERKF_AVAILABLE=0x00000002;
const SERKF_INDICATOR=0x00000004;
type HIGHCONTRAST=record
       cbSize:cardinal;
       dwFlags:cardinal;
       lpszDefaultScheme:pstr;
     end;
     pHIGHCONTRAST=pointer to HIGHCONTRAST;

const HCF_HIGHCONTRASTON=0x00000001;
const HCF_AVAILABLE=0x00000002;
const HCF_HOTKEYACTIVE=0x00000004;
const HCF_CONFIRMHOTKEY=0x00000008;
const HCF_HOTKEYSOUND=0x00000010;
const HCF_INDICATOR=0x00000020;
const HCF_HOTKEYAVAILABLE=0x00000040;
const CDS_UPDATEREGISTRY=0x00000001;
const CDS_TEST=0x00000002;
const CDS_FULLSCREEN=0x00000004;
const CDS_GLOBAL=0x00000008;
const CDS_SET_PRIMARY=0x00000010;
const CDS_RESET=0x40000000;
const CDS_SETRECT=0x20000000;
const CDS_NORESET=0x10000000;
const DISP_CHANGE_SUCCESSFUL=0x00000000;
const DISP_CHANGE_RESTART=0x00000001;
const DISP_CHANGE_FAILED=-0x00000001;
const DISP_CHANGE_BADMODE=-0x00000002;
const DISP_CHANGE_NOTUPDATED=-0x00000003;
const DISP_CHANGE_BADFLAGS=-0x00000004;
const DISP_CHANGE_BADPARAM=-0x00000005;

procedure ChangeDisplaySettings ascii(lpDevMode:pDEVMODE; dwFlags:cardinal):integer;

const ENUM_CURRENT_SETTINGS=-0x00000001;
const ENUM_REGISTRY_SETTINGS=-0x00000002;

procedure EnumDisplaySettings ascii(lpszDeviceName:pstr; iModeNum:cardinal; lpDevMode:pDEVMODE):boolean;
procedure SystemParametersInfo ascii(uiAction:cardinal; uiParam:cardinal; pvParam:address; fWinIni:cardinal):boolean;

type FILTERKEYS=record
       cbSize:cardinal;
       dwFlags:cardinal;
       iWaitMSec:cardinal;
       iDelayMSec:cardinal;
       iRepeatMSec:cardinal;
       iBounceMSec:cardinal;
     end;
     pFILTERKEYS=pointer to FILTERKEYS;

const FKF_FILTERKEYSON=0x00000001;
const FKF_AVAILABLE=0x00000002;
const FKF_HOTKEYACTIVE=0x00000004;
const FKF_CONFIRMHOTKEY=0x00000008;
const FKF_HOTKEYSOUND=0x00000010;
const FKF_INDICATOR=0x00000020;
const FKF_CLICKON=0x00000040;

type STICKYKEYS=record
       cbSize:cardinal;
       dwFlags:cardinal;
     end;

//========================================================================
//                          ���� � ������� ������ Gdi32
//========================================================================

from Gdi32;

const R2_BLACK=0x00000001;
const R2_NOTMERGEPEN=0x00000002;
const R2_MASKNOTPEN=0x00000003;
const R2_NOTCOPYPEN=0x00000004;
const R2_MASKPENNOT=0x00000005;
const R2_NOT=0x00000006;
const R2_XORPEN=0x00000007;
const R2_NOTMASKPEN=0x00000008;
const R2_MASKPEN=0x00000009;
const R2_NOTXORPEN=0x0000000A;
const R2_NOP=0x0000000B;
const R2_MERGENOTPEN=0x0000000C;
const R2_COPYPEN=0x0000000D;
const R2_MERGEPENNOT=0x0000000E;
const R2_MERGEPEN=0x0000000F;
const R2_WHITE=0x00000010;
const R2_LAST=0x00000010;
const SRCCOPY=0x00CC0020;
const SRCPAINT=0x00EE0086;
const SRCAND=0x008800C6;
const SRCINVERT=0x00660046;
const SRCERASE=0x00440328;
const NOTSRCCOPY=0x00330008;
const NOTSRCERASE=0x001100A6;
const MERGECOPY=0x00C000CA;
const MERGEPAINT=0x00BB0226;
const PATCOPY=0x00F00021;
const PATPAINT=0x00FB0A09;
const PATINVERT=0x005A0049;
const DSTINVERT=0x00550009;
const BLACKNESS=0x00000042;
const WHITENESS=0x00FF0062;
const GDI_ERROR=0xFFFFFFFF;
const HGDI_ERROR=0xFFFFFFFF;
const ERROR=0x00000000;
const NULLREGION=0x00000001;
const SIMPLEREGION=0x00000002;
const COMPLEXREGION=0x00000003;
const RGN_ERROR=ERROR;
const RGN_AND=0x00000001;
const RGN_OR=0x00000002;
const RGN_XOR=0x00000003;
const RGN_DIFF=0x00000004;
const RGN_COPY=0x00000005;
const RGN_MIN=RGN_AND;
const RGN_MAX=RGN_COPY;
const BLACKONWHITE=0x00000001;
const WHITEONBLACK=0x00000002;
const COLORONCOLOR=0x00000003;
const HALFTONE=0x00000004;
const MAXSTRETCHBLTMODE=0x00000004;
const STRETCH_ANDSCANS=BLACKONWHITE;
const STRETCH_ORSCANS=WHITEONBLACK;
const STRETCH_DELETESCANS=COLORONCOLOR;
const STRETCH_HALFTONE=HALFTONE;
const ALTERNATE=0x00000001;
const WINDING=0x00000002;
const POLYFILL_LAST=0x00000002;
const TA_NOUPDATECP=0x00000000;
const TA_UPDATECP=0x00000001;
const TA_LEFT=0x00000000;
const TA_RIGHT=0x00000002;
const TA_CENTER=0x00000006;
const TA_TOP=0x00000000;
const TA_BOTTOM=0x00000008;
const TA_BASELINE=0x00000018;
const TA_RTLREADING=0x00000100;
const TA_MASK=TA_BASELINE+6+1+256;
const VTA_BASELINE=TA_BASELINE;
const VTA_LEFT=TA_BOTTOM;
const VTA_RIGHT=TA_TOP;
const VTA_CENTER=TA_CENTER;
const VTA_BOTTOM=TA_RIGHT;
const VTA_TOP=TA_LEFT;
const ETO_OPAQUE=0x00000002;
const ETO_CLIPPED=0x00000004;
const ETO_GLYPH_INDEX=0x00000010;
const ETO_RTLREADING=0x00000080;
const ETO_IGNORELANGUAGE=0x00001000;
const ASPECT_FILTERING=0x00000001;
const DCB_RESET=0x00000001;
const DCB_ACCUMULATE=0x00000002;
const DCB_DIRTY=DCB_ACCUMULATE;
const DCB_SET=DCB_RESET|DCB_ACCUMULATE;
const DCB_ENABLE=0x00000004;
const DCB_DISABLE=0x00000008;
const META_SETBKCOLOR=0x00000201;
const META_SETBKMODE=0x00000102;
const META_SETMAPMODE=0x00000103;
const META_SETROP2=0x00000104;
const META_SETRELABS=0x00000105;
const META_SETPOLYFILLMODE=0x00000106;
const META_SETSTRETCHBLTMODE=0x00000107;
const META_SETTEXTCHAREXTRA=0x00000108;
const META_SETTEXTCOLOR=0x00000209;
const META_SETTEXTJUSTIFICATION=0x0000020A;
const META_SETWINDOWORG=0x0000020B;
const META_SETWINDOWEXT=0x0000020C;
const META_SETVIEWPORTORG=0x0000020D;
const META_SETVIEWPORTEXT=0x0000020E;
const META_OFFSETWINDOWORG=0x0000020F;
const META_SCALEWINDOWEXT=0x00000410;
const META_OFFSETVIEWPORTORG=0x00000211;
const META_SCALEVIEWPORTEXT=0x00000412;
const META_LINETO=0x00000213;
const META_MOVETO=0x00000214;
const META_EXCLUDECLIPRECT=0x00000415;
const META_INTERSECTCLIPRECT=0x00000416;
const META_ARC=0x00000817;
const META_ELLIPSE=0x00000418;
const META_FLOODFILL=0x00000419;
const META_PIE=0x0000081A;
const META_RECTANGLE=0x0000041B;
const META_ROUNDRECT=0x0000061C;
const META_PATBLT=0x0000061D;
const META_SAVEDC=0x0000001E;
const META_SETPIXEL=0x0000041F;
const META_OFFSETCLIPRGN=0x00000220;
const META_TEXTOUT=0x00000521;
const META_BITBLT=0x00000922;
const META_STRETCHBLT=0x00000B23;
const META_POLYGON=0x00000324;
const META_POLYLINE=0x00000325;
const META_ESCAPE=0x00000626;
const META_RESTOREDC=0x00000127;
const META_FILLREGION=0x00000228;
const META_FRAMEREGION=0x00000429;
const META_INVERTREGION=0x0000012A;
const META_PAINTREGION=0x0000012B;
const META_SELECTCLIPREGION=0x0000012C;
const META_SELECTOBJECT=0x0000012D;
const META_SETTEXTALIGN=0x0000012E;
const META_CHORD=0x00000830;
const META_SETMAPPERFLAGS=0x00000231;
const META_EXTTEXTOUT=0x00000A32;
const META_SETDIBTODEV=0x00000D33;
const META_SELECTPALETTE=0x00000234;
const META_REALIZEPALETTE=0x00000035;
const META_ANIMATEPALETTE=0x00000436;
const META_SETPALENTRIES=0x00000037;
const META_POLYPOLYGON=0x00000538;
const META_RESIZEPALETTE=0x00000139;
const META_DIBBITBLT=0x00000940;
const META_DIBSTRETCHBLT=0x00000B41;
const META_DIBCREATEPATTERNBRUSH=0x00000142;
const META_STRETCHDIB=0x00000F43;
const META_EXTFLOODFILL=0x00000548;
const META_DELETEOBJECT=0x000001F0;
const META_CREATEPALETTE=0x000000F7;
const META_CREATEPATTERNBRUSH=0x000001F9;
const META_CREATEPENINDIRECT=0x000002FA;
const META_CREATEFONTINDIRECT=0x000002FB;
const META_CREATEBRUSHINDIRECT=0x000002FC;
const META_CREATEREGION=0x000006FF;
const NEWFRAME=0x00000001;
const ABORTDOC=0x00000002;
const NEXTBAND=0x00000003;
const SETCOLORTABLE=0x00000004;
const GETCOLORTABLE=0x00000005;
const FLUSHOUTPUT=0x00000006;
const DRAFTMODE=0x00000007;
const QUERYESCSUPPORT=0x00000008;
const SETABORTPROC=0x00000009;
const STARTDOC=0x0000000A;
const ENDDOC=0x0000000B;
const GETPHYSPAGESIZE=0x0000000C;
const GETPRINTINGOFFSET=0x0000000D;
const GETSCALINGFACTOR=0x0000000E;
const MFCOMMENT=0x0000000F;
const GETPENWIDTH=0x00000010;
const SETCOPYCOUNT=0x00000011;
const SELECTPAPERSOURCE=0x00000012;
const DEVICEDATA=0x00000013;
const PASSTHROUGH=0x00000013;
const GETTECHNOLGY=0x00000014;
const GETTECHNOLOGY=0x00000014;
const SETLINECAP=0x00000015;
const SETLINEJOIN=0x00000016;
const SETMITERLIMIT=0x00000017;
const BANDINFO=0x00000018;
const DRAWPATTERNRECT=0x00000019;
const GETVECTORPENSIZE=0x0000001A;
const GETVECTORBRUSHSIZE=0x0000001B;
const ENABLEDUPLEX=0x0000001C;
const GETSETPAPERBINS=0x0000001D;
const GETSETPRINTORIENT=0x0000001E;
const ENUMPAPERBINS=0x0000001F;
const SETDIBSCALING=0x00000020;
const EPSPRINTING=0x00000021;
const ENUMPAPERMETRICS=0x00000022;
const GETSETPAPERMETRICS=0x00000023;
const POSTSCRIPT_DATA=0x00000025;
const POSTSCRIPT_IGNORE=0x00000026;
const MOUSETRAILS=0x00000027;
const GETDEVICEUNITS=0x0000002A;
const GETEXTENDEDTEXTMETRICS=0x00000100;
const GETEXTENTTABLE=0x00000101;
const GETPAIRKERNTABLE=0x00000102;
const GETTRACKKERNTABLE=0x00000103;
const EXTTEXTOUT=0x00000200;
const GETFACENAME=0x00000201;
const DOWNLOADFACE=0x00000202;
const ENABLERELATIVEWIDTHS=0x00000300;
const ENABLEPAIRKERNING=0x00000301;
const SETKERNTRACK=0x00000302;
const SETALLJUSTVALUES=0x00000303;
const SETCHARSET=0x00000304;
const STRETCHBLT=0x00000800;
const GETSETSCREENPARAMS=0x00000C00;
const QUERYDIBSUPPORT=0x00000C01;
const BEGIN_PATH=0x00001000;
const CLIP_TO_PATH=0x00001001;
const END_PATH=0x00001002;
const EXT_DEVICE_CAPS=0x00001003;
const RESTORE_CTM=0x00001004;
const SAVE_CTM=0x00001005;
const SET_ARC_DIRECTION=0x00001006;
const SET_BACKGROUND_COLOR=0x00001007;
const SET_POLY_MODE=0x00001008;
const SET_SCREEN_ANGLE=0x00001009;
const SET_SPREAD=0x0000100A;
const TRANSFORM_CTM=0x0000100B;
const SET_CLIP_BOX=0x0000100C;
const SET_BOUNDS=0x0000100D;
const SET_MIRROR_MODE=0x0000100E;
const OPENCHANNEL=0x0000100E;
const DOWNLOADHEADER=0x0000100F;
const CLOSECHANNEL=0x00001010;
const POSTSCRIPT_PASSTHROUGH=0x00001013;
const ENCAPSULATED_POSTSCRIPT=0x00001014;
const QDI_SETDIBITS=0x00000001;
const QDI_GETDIBITS=0x00000002;
const QDI_DIBTOSCREEN=0x00000004;
const QDI_STRETCHDIB=0x00000008;
const SP_NOTREPORTED=0x00004000;
const SP_ERROR=-0x00000001;
const SP_APPABORT=-0x00000002;
const SP_USERABORT=-0x00000003;
const SP_OUTOFDISK=-0x00000004;
const SP_OUTOFMEMORY=-0x00000005;
const PR_JOBSTATUS=0x00000000;
const OBJ_PEN=0x00000001;
const OBJ_BRUSH=0x00000002;
const OBJ_DC=0x00000003;
const OBJ_METADC=0x00000004;
const OBJ_PAL=0x00000005;
const OBJ_FONT=0x00000006;
const OBJ_BITMAP=0x00000007;
const OBJ_REGION=0x00000008;
const OBJ_METAFILE=0x00000009;
const OBJ_MEMDC=0x0000000A;
const OBJ_EXTPEN=0x0000000B;
const OBJ_ENHMETADC=0x0000000C;
const OBJ_ENHMETAFILE=0x0000000D;
const MWT_IDENTITY=0x00000001;
const MWT_LEFTMULTIPLY=0x00000002;
const MWT_RIGHTMULTIPLY=0x00000003;
const MWT_MIN=MWT_IDENTITY;
const MWT_MAX=MWT_RIGHTMULTIPLY;
type XFORM=record
       eM11:real;
       eM12:real;
       eM21:real;
       eM22:real;
       eDx:real;
       eDy:real;
     end;
     pXFORM=pointer to XFORM;

type BITMAP=record
       bmType:integer;
       bmWidth:integer;
       bmHeight:integer;
       bmWidthBytes:integer;
       bmPlanes:word;
       bmBitsPixel:word;
       bmBits:address;
     end;
     pBITMAP=pointer to BITMAP;

type RGBTRIPLE=record
       rgbtBlue:byte;
       rgbtGreen:byte;
       rgbtRed:byte;
     end;
     pRGBTRIPLE=pointer to RGBTRIPLE;

type RGBQUAD=record
       rgbBlue:byte;
       rgbGreen:byte;
       rgbRed:byte;
       rgbReserved:byte;
     end;
     pRGBQUAD=pointer to RGBQUAD;

type LCSCSTYPE=integer;

const LCS_CALIBRATED_RGB=0x00000000;
const LCS_DEVICE_RGB=0x00000001;
const LCS_DEVICE_CMYK=0x00000002;

type LCSGAMUTMATCH=integer;

const LCS_GM_BUSINESS=0x00000001;
const LCS_GM_GRAPHICS=0x00000002;
const LCS_GM_IMAGES=0x00000004;
const CM_OUT_OF_GAMUT=0x000000FF;
const CM_IN_GAMUT=0x00000000;

type FXPT16DOT16=integer;
type FXPT2DOT30=integer;
type CIEXYZ=record
       ciexyzX:FXPT2DOT30;
       ciexyzY:FXPT2DOT30;
       ciexyzZ:FXPT2DOT30;
     end;
     pCIEXYZ=pointer to CIEXYZ;

type CIEXYZTRIPLE=record
       ciexyzRed:CIEXYZ;
       ciexyzGreen:CIEXYZ;
       ciexyzBlue:CIEXYZ;
     end;
     pCIEXYZTRIPLE=pointer to CIEXYZTRIPLE;

type LOGCOLORSPACE=record
       lcsSignature:cardinal;
       lcsVersion:cardinal;
       lcsSize:cardinal;
       lcsCSType:LCSCSTYPE;
       lcsIntent:LCSGAMUTMATCH;
       lcsEndpoints:CIEXYZTRIPLE;
       lcsGammaRed:cardinal;
       lcsGammaGreen:cardinal;
       lcsGammaBlue:cardinal;
       lcsFilename:array[0..MAX_PATH-1]of char;
     end;
     pLOGCOLORSPACE=pointer to LOGCOLORSPACE;

type BITMAPCOREHEADER=record
       bcSize:cardinal;
       bcWidth:word;
       bcHeight:word;
       bcPlanes:word;
       bcBitCount:word;
     end;
     pBITMAPCOREHEADER=pointer to BITMAPCOREHEADER;

type BITMAPINFOHEADER=record
       biSize:cardinal;
       biWidth:integer;
       biHeight:integer;
       biPlanes:word;
       biBitCount:word;
       biCompression:cardinal;
       biSizeImage:cardinal;
       biXPelsPerMeter:integer;
       biYPelsPerMeter:integer;
       biClrUsed:cardinal;
       biClrImportant:cardinal;
     end;
     pBITMAPINFOHEADER=pointer to BITMAPINFOHEADER;

type BITMAPV4HEADER=record
       bV4Size:cardinal;
       bV4Width:integer;
       bV4Height:integer;
       bV4Planes:word;
       bV4BitCount:word;
       bV4V4Compression:cardinal;
       bV4SizeImage:cardinal;
       bV4XPelsPerMeter:integer;
       bV4YPelsPerMeter:integer;
       bV4ClrUsed:cardinal;
       bV4ClrImportant:cardinal;
       bV4RedMask:cardinal;
       bV4GreenMask:cardinal;
       bV4BlueMask:cardinal;
       bV4AlphaMask:cardinal;
       bV4CSType:cardinal;
       bV4Endpoints:CIEXYZTRIPLE;
       bV4GammaRed:cardinal;
       bV4GammaGreen:cardinal;
       bV4GammaBlue:cardinal;
     end;
     pBITMAPV4HEADER=pointer to BITMAPV4HEADER;

const BI_RGB=0x00000000;
const BI_RLE8=0x00000001;
const BI_RLE4=0x00000002;
const BI_BITFIELDS=0x00000003;
type BITMAPINFO=record
       bmiHeader:BITMAPINFOHEADER;

       bmiColors:array[0..0]of RGBQUAD;
     end;
     pBITMAPINFO=pointer to BITMAPINFO;

type BITMAPCOREINFO=record
       bmciHeader:BITMAPCOREHEADER;
       bmciColors:array[0..0]of RGBTRIPLE;
     end;
     pBITMAPCOREINFO=pointer to BITMAPCOREINFO;

type BITMAPFILEHEADER=record
       bfType:word;
       bfSize:cardinal;
       bfReserved1:word;
       bfReserved2:word;
       bfOffBits:cardinal;
     end;
     pBITMAPFILEHEADER=pointer to BITMAPFILEHEADER;

type FONTSIGNATURE=record
       fsUsb:array[0..3]of cardinal;
       fsCsb:array[0..1]of cardinal;
     end;
     pFONTSIGNATURE=pointer to FONTSIGNATURE;

type CHARSETINFO=record
       ciCharset:cardinal;
       ciACP:cardinal;
       fs:FONTSIGNATURE;
     end;
     pCHARSETINFO=pointer to CHARSETINFO;

const TCI_SRCCHARSET=0x00000001;
const TCI_SRCCODEPAGE=0x00000002;
const TCI_SRCFONTSIG=0x00000003;
type LOCALESIGNATURE=record
       lsUsb:array[0..3]of cardinal;
       lsCsbDefault:array[0..1]of cardinal;
       lsCsbSupported:array[0..1]of cardinal;
     end;
     pLOCALESIGNATURE=pointer to LOCALESIGNATURE;

type HANDLETABLE=record
       objectHandle:array[0..0]of HGDIOBJ;
     end;
     pHANDLETABLE=pointer to HANDLETABLE;

type METARECORD=record
       rdSize:cardinal;
       rdFunction:word;
       rdParm:array[0..0]of word;
     end;
     pMETARECORD=pointer to METARECORD;

type METAFILEPICT=record
       mm:integer;
       xExt:integer;
       yExt:integer;
       hMF:HMETAFILE;
     end;
     pMETAFILEPICT=pointer to METAFILEPICT;

type METAHEADER=record
       mtType:word;
       mtHeaderSize:word;
       mtVersion:word;
       mtSize:cardinal;
       mtNoObjects:word;
       mtMaxRecord:cardinal;
       mtNoParameters:word;
     end;
     pMETAHEADER=pointer to METAHEADER;

type ENHMETARECORD=record
       iType:cardinal;
       nSize:cardinal;
       dParm:array[0..0]of cardinal;
     end;
     pENHMETARECORD=pointer to ENHMETARECORD;

type ENHMETAHEADER=record
       iType:cardinal;
       nSize:cardinal;
       rclBounds:RECT;
       rclFrame:RECT;
       dSignature:cardinal;
       nVersion:cardinal;
       nBytes:cardinal;
       nRecords:cardinal;
       nHandles:word;
       sReserved:word;
       nDescription:cardinal;
       offDescription:cardinal;
       nPalEntries:cardinal;
       szlDevice:LARGE_INTEGER;
       szlMillimeters:LARGE_INTEGER;
       cbPixelFormat:cardinal;
       offPixelFormat:cardinal;
       bOpenGL:cardinal;
     end;
     pENHMETAHEADER=pointer to ENHMETAHEADER;

const TMPF_FIXED_PITCH=0x00000001;
const TMPF_VECTOR=0x00000002;
const TMPF_DEVICE=0x00000008;
const TMPF_TRUETYPE=0x00000004;
type BCHAR=byte;
type TEXTMETRIC=record
       tmHeight:integer;
       tmAscent:integer;
       tmDescent:integer;
       tmInternalLeading:integer;
       tmExternalLeading:integer;
       tmAveCharWidth:integer;
       tmMaxCharWidth:integer;
       tmWeight:integer;
       tmOverhang:integer;
       tmDigitizedAspectX:integer;
       tmDigitizedAspectY:integer;
       tmFirstChar:byte;
       tmLastChar:byte;
       tmDefaultChar:byte;
       tmBreakChar:byte;
       tmItalic:byte;
       tmUnderlined:byte;
       tmStruckOut:byte;
       tmPitchAndFamily:byte;
       tmCharSet:byte;
     end;
     pTEXTMETRIC=pointer to TEXTMETRIC;

const NTM_REGULAR=0x00000040;
const NTM_BOLD=0x00000020;
const NTM_ITALIC=0x00000001;
type NEWTEXTMETRIC=record
       tmHeight:integer;
       tmAscent:integer;
       tmDescent:integer;
       tmInternalLeading:integer;
       tmExternalLeading:integer;
       tmAveCharWidth:integer;
       tmMaxCharWidth:integer;
       tmWeight:integer;
       tmOverhang:integer;
       tmDigitizedAspectX:integer;
       tmDigitizedAspectY:integer;
       tmFirstChar:byte;
       tmLastChar:byte;
       tmDefaultChar:byte;
       tmBreakChar:byte;
       tmItalic:byte;
       tmUnderlined:byte;
       tmStruckOut:byte;
       tmPitchAndFamily:byte;
       tmCharSet:byte;
       ntmFlags:cardinal;
       ntmSizeEM:cardinal;
       ntmCellHeight:cardinal;
       ntmAvgWidth:cardinal;
     end;
     pNEWTEXTMETRIC=pointer to NEWTEXTMETRIC;

type NEWTEXTMETRICEX=record
       ntmTm:NEWTEXTMETRIC;
       ntmFontSig:FONTSIGNATURE;
     end;
     pNEWTEXTMETRICEX=pointer to NEWTEXTMETRICEX;

type PELARRAY=record
       paXCount:integer;
       paYCount:integer;
       paXExt:integer;
       paYExt:integer;
       paRGBs:byte;
     end;
     pPELARRAY=pointer to PELARRAY;

type LOGBRUSH=record
       lbStyle:cardinal;
       lbColor:COLORREF;
       lbHatch:integer;
     end;
     pLOGBRUSH=pointer to LOGBRUSH;

type LOGPEN=record
       lopnStyle:cardinal;
       lopnWidth:POINT;
       lopnColor:COLORREF;
     end;
     pLOGPEN=pointer to LOGPEN;

type EXTLOGPEN=record
       elpPenStyle:cardinal;
       elpWidth:cardinal;
       elpBrushStyle:cardinal;
       elpColor:COLORREF;
       elpHatch:integer;
       elpNumEntries:cardinal;
       elpStyleEntry:array[0..0]of cardinal;
     end;
     pEXTLOGPEN=pointer to EXTLOGPEN;

type PALETTEENTRY=record
       peRed:byte;
       peGreen:byte;
       peBlue:byte;
       peFlags:byte;
     end;
     pPALETTEENTRY=pointer to PALETTEENTRY;

type LOGPALETTE=record
       palVersion:word;
       palNumEntries:word;
       palPalEntry:array[0..0]of PALETTEENTRY;
     end;
     pLOGPALETTE=pointer to LOGPALETTE;

type ENUMLOGFONT=record
       elfLogFont:LOGFONT;
       elfFullName:array[0..LF_FULLFACESIZE-1]of byte;
       elfStyle:array[0..LF_FACESIZE-1]of byte;
     end;
     pENUMLOGFONT=pointer to ENUMLOGFONT;

type ENUMLOGFONTEX=record
       elfLogFont:LOGFONT;
       elfFullName:array[0..LF_FULLFACESIZE-1]of byte;
       elfStyle:array[0..LF_FACESIZE-1]of byte;
       elfScript:array[0..LF_FACESIZE-1]of byte;
     end;
     pENUMLOGFONTEX=pointer to ENUMLOGFONTEX;

const OUT_DEFAULT_PRECIS=0x00000000;
const OUT_STRING_PRECIS=0x00000001;
const OUT_CHARACTER_PRECIS=0x00000002;
const OUT_STROKE_PRECIS=0x00000003;
const OUT_TT_PRECIS=0x00000004;
const OUT_DEVICE_PRECIS=0x00000005;
const OUT_RASTER_PRECIS=0x00000006;
const OUT_TT_ONLY_PRECIS=0x00000007;
const OUT_OUTLINE_PRECIS=0x00000008;
const OUT_SCREEN_OUTLINE_PRECIS=0x00000009;
const CLIP_DEFAULT_PRECIS=0x00000000;
const CLIP_CHARACTER_PRECIS=0x00000001;
const CLIP_STROKE_PRECIS=0x00000002;
const CLIP_MASK=0x0000000F;
const CLIP_LH_ANGLES=0x00000010;
const CLIP_TT_ALWAYS=0x00000020;
const CLIP_EMBEDDED=0x00000080;
const DEFAULT_QUALITY=0x00000000;
const DRAFT_QUALITY=0x00000001;
const PROOF_QUALITY=0x00000002;
const NONANTIALIASED_QUALITY=0x00000003;
const ANTIALIASED_QUALITY=0x00000004;
const DEFAULT_PITCH=0x00000000;
const FIXED_PITCH=0x00000001;
const VARIABLE_PITCH=0x00000002;
const MONO_FONT=0x00000008;
const ANSI_CHARSET=0x00000000;
const DEFAULT_CHARSET=0x00000001;
const SYMBOL_CHARSET=0x00000002;
const SHIFTJIS_CHARSET=0x00000080;
const HANGEUL_CHARSET=0x00000081;
const GB2312_CHARSET=0x00000086;
const CHINESEBIG5_CHARSET=0x00000088;
const OEM_CHARSET=0x000000FF;
const JOHAB_CHARSET=0x00000082;
const HEBREW_CHARSET=0x000000B1;
const ARABIC_CHARSET=0x000000B2;
const GREEK_CHARSET=0x000000A1;
const TURKISH_CHARSET=0x000000A2;
const VIETNAMESE_CHARSET=0x000000A3;
const THAI_CHARSET=0x000000DE;
const EASTEUROPE_CHARSET=0x000000EE;
const RUSSIAN_CHARSET=0x000000CC;
const MAC_CHARSET=0x0000004D;
const BALTIC_CHARSET=0x000000BA;
const FS_LATIN1=0x00000001;
const FS_LATIN2=0x00000002;
const FS_CYRILLIC=0x00000004;
const FS_GREEK=0x00000008;
const FS_TURKISH=0x00000010;
const FS_HEBREW=0x00000020;
const FS_ARABIC=0x00000040;
const FS_BALTIC=0x00000080;
const FS_VIETNAMESE=0x00000100;
const FS_THAI=0x00010000;
const FS_JISJAPAN=0x00020000;
const FS_CHINESESIMP=0x00040000;
const FS_WANSUNG=0x00080000;
const FS_CHINESETRAD=0x00100000;
const FS_JOHAB=0x00200000;
const FS_SYMBOL=0x80000000;
const FF_DONTCARE=0x00000000;
const FF_ROMAN=0x00000010;
const FF_SWISS=0x00000020;
const FF_MODERN=0x00000030;
const FF_SCRIPT=0x00000040;
const FF_DECORATIVE=0x00000050;
const FW_DONTCARE=0x00000000;
const FW_THIN=0x00000064;
const FW_EXTRALIGHT=0x000000C8;
const FW_LIGHT=0x0000012C;
const FW_NORMAL=0x00000190;
const FW_MEDIUM=0x000001F4;
const FW_SEMIBOLD=0x00000258;
const FW_BOLD=0x000002BC;
const FW_EXTRABOLD=0x00000320;
const FW_HEAVY=0x00000384;
const FW_ULTRALIGHT=FW_EXTRALIGHT;
const FW_REGULAR=FW_NORMAL;
const FW_DEMIBOLD=FW_SEMIBOLD;
const FW_ULTRABOLD=FW_EXTRABOLD;
const FW_BLACK=FW_HEAVY;
const PANOSE_COUNT=0x0000000A;
const PAN_FAMILYTYPE_INDEX=0x00000000;
const PAN_SERIFSTYLE_INDEX=0x00000001;
const PAN_WEIGHT_INDEX=0x00000002;
const PAN_PROPORTION_INDEX=0x00000003;
const PAN_CONTRAST_INDEX=0x00000004;
const PAN_STROKEVARIATION_INDEX=0x00000005;
const PAN_ARMSTYLE_INDEX=0x00000006;
const PAN_LETTERFORM_INDEX=0x00000007;
const PAN_MIDLINE_INDEX=0x00000008;
const PAN_XHEIGHT_INDEX=0x00000009;
const PAN_CULTURE_LATIN=0x00000000;
type PANOSE=record
       bFamilyType:byte;
       bSerifStyle:byte;
       bWeight:byte;
       bProportion:byte;
       bContrast:byte;
       bStrokeVariation:byte;
       bArmStyle:byte;
       bLetterform:byte;
       bMidline:byte;
       bXHeight:byte;
     end;
     pPANOSE=pointer to PANOSE;

const PAN_ANY=0x00000000;
const PAN_NO_FIT=0x00000001;
const PAN_FAMILY_TEXT_DISPLAY=0x00000002;
const PAN_FAMILY_SCRIPT=0x00000003;
const PAN_FAMILY_DECORATIVE=0x00000004;
const PAN_FAMILY_PICTORIAL=0x00000005;
const PAN_SERIF_COVE=0x00000002;
const PAN_SERIF_OBTUSE_COVE=0x00000003;
const PAN_SERIF_SQUARE_COVE=0x00000004;
const PAN_SERIF_OBTUSE_SQUARE_COVE=0x00000005;
const PAN_SERIF_SQUARE=0x00000006;
const PAN_SERIF_THIN=0x00000007;
const PAN_SERIF_BONE=0x00000008;
const PAN_SERIF_EXAGGERATED=0x00000009;
const PAN_SERIF_TRIANGLE=0x0000000A;
const PAN_SERIF_NORMAL_SANS=0x0000000B;
const PAN_SERIF_OBTUSE_SANS=0x0000000C;
const PAN_SERIF_PERP_SANS=0x0000000D;
const PAN_SERIF_FLARED=0x0000000E;
const PAN_SERIF_ROUNDED=0x0000000F;
const PAN_WEIGHT_VERY_LIGHT=0x00000002;
const PAN_WEIGHT_LIGHT=0x00000003;
const PAN_WEIGHT_THIN=0x00000004;
const PAN_WEIGHT_BOOK=0x00000005;
const PAN_WEIGHT_MEDIUM=0x00000006;
const PAN_WEIGHT_DEMI=0x00000007;
const PAN_WEIGHT_BOLD=0x00000008;
const PAN_WEIGHT_HEAVY=0x00000009;
const PAN_WEIGHT_BLACK=0x0000000A;
const PAN_WEIGHT_NORD=0x0000000B;
const PAN_PROP_OLD_STYLE=0x00000002;
const PAN_PROP_MODERN=0x00000003;
const PAN_PROP_EVEN_WIDTH=0x00000004;
const PAN_PROP_EXPANDED=0x00000005;
const PAN_PROP_CONDENSED=0x00000006;
const PAN_PROP_VERY_EXPANDED=0x00000007;
const PAN_PROP_VERY_CONDENSED=0x00000008;
const PAN_PROP_MONOSPACED=0x00000009;
const PAN_CONTRAST_NONE=0x00000002;
const PAN_CONTRAST_VERY_LOW=0x00000003;
const PAN_CONTRAST_LOW=0x00000004;
const PAN_CONTRAST_MEDIUM_LOW=0x00000005;
const PAN_CONTRAST_MEDIUM=0x00000006;
const PAN_CONTRAST_MEDIUM_HIGH=0x00000007;
const PAN_CONTRAST_HIGH=0x00000008;
const PAN_CONTRAST_VERY_HIGH=0x00000009;
const PAN_STROKE_GRADUAL_DIAG=0x00000002;
const PAN_STROKE_GRADUAL_TRAN=0x00000003;
const PAN_STROKE_GRADUAL_VERT=0x00000004;
const PAN_STROKE_GRADUAL_HORZ=0x00000005;
const PAN_STROKE_RAPID_VERT=0x00000006;
const PAN_STROKE_RAPID_HORZ=0x00000007;
const PAN_STROKE_INSTANT_VERT=0x00000008;
const PAN_STRAIGHT_ARMS_HORZ=0x00000002;
const PAN_STRAIGHT_ARMS_WEDGE=0x00000003;
const PAN_STRAIGHT_ARMS_VERT=0x00000004;
const PAN_STRAIGHT_ARMS_SINGLE_SERIF=0x00000005;
const PAN_STRAIGHT_ARMS_DOUBLE_SERIF=0x00000006;
const PAN_BENT_ARMS_HORZ=0x00000007;
const PAN_BENT_ARMS_WEDGE=0x00000008;
const PAN_BENT_ARMS_VERT=0x00000009;
const PAN_BENT_ARMS_SINGLE_SERIF=0x0000000A;
const PAN_BENT_ARMS_DOUBLE_SERIF=0x0000000B;
const PAN_LETT_NORMAL_CONTACT=0x00000002;
const PAN_LETT_NORMAL_WEIGHTED=0x00000003;
const PAN_LETT_NORMAL_BOXED=0x00000004;
const PAN_LETT_NORMAL_FLATTENED=0x00000005;
const PAN_LETT_NORMAL_ROUNDED=0x00000006;
const PAN_LETT_NORMAL_OFF_CENTER=0x00000007;
const PAN_LETT_NORMAL_SQUARE=0x00000008;
const PAN_LETT_OBLIQUE_CONTACT=0x00000009;
const PAN_LETT_OBLIQUE_WEIGHTED=0x0000000A;
const PAN_LETT_OBLIQUE_BOXED=0x0000000B;
const PAN_LETT_OBLIQUE_FLATTENED=0x0000000C;
const PAN_LETT_OBLIQUE_ROUNDED=0x0000000D;
const PAN_LETT_OBLIQUE_OFF_CENTER=0x0000000E;
const PAN_LETT_OBLIQUE_SQUARE=0x0000000F;
const PAN_MIDLINE_STANDARD_TRIMMED=0x00000002;
const PAN_MIDLINE_STANDARD_POINTED=0x00000003;
const PAN_MIDLINE_STANDARD_SERIFED=0x00000004;
const PAN_MIDLINE_HIGH_TRIMMED=0x00000005;
const PAN_MIDLINE_HIGH_POINTED=0x00000006;
const PAN_MIDLINE_HIGH_SERIFED=0x00000007;
const PAN_MIDLINE_CONSTANT_TRIMMED=0x00000008;
const PAN_MIDLINE_CONSTANT_POINTED=0x00000009;
const PAN_MIDLINE_CONSTANT_SERIFED=0x0000000A;
const PAN_MIDLINE_LOW_TRIMMED=0x0000000B;
const PAN_MIDLINE_LOW_POINTED=0x0000000C;
const PAN_MIDLINE_LOW_SERIFED=0x0000000D;
const PAN_XHEIGHT_CONSTANT_SMALL=0x00000002;
const PAN_XHEIGHT_CONSTANT_STD=0x00000003;
const PAN_XHEIGHT_CONSTANT_LARGE=0x00000004;
const PAN_XHEIGHT_DUCKING_SMALL=0x00000005;
const PAN_XHEIGHT_DUCKING_STD=0x00000006;
const PAN_XHEIGHT_DUCKING_LARGE=0x00000007;
const ELF_VENDOR_SIZE=0x00000004;
type EXTLOGFONT=record
       elfLogFont:LOGFONT;
       elfFullName:array[0..LF_FULLFACESIZE-1]of byte;
       elfStyle:array[0..LF_FACESIZE-1]of byte;
       elfVersion:cardinal;
       elfStyleSize:cardinal;
       elfMatch:cardinal;
       elfReserved:cardinal;
       elfVendorId:array[0..ELF_VENDOR_SIZE-1]of byte;
       elfCulture:cardinal;
       elfPanose:PANOSE;
     end;
     pEXTLOGFONT=pointer to EXTLOGFONT;

const ELF_VERSION=0x00000000;
const ELF_CULTURE_LATIN=0x00000000;
const RASTER_FONTTYPE=0x00000001;
const DEVICE_FONTTYPE=0x00000002;
const TRUETYPE_FONTTYPE=0x00000004;
const PC_RESERVED=0x00000001;
const PC_EXPLICIT=0x00000002;
const PC_NOCOLLAPSE=0x00000004;
const TRANSPARENT=0x00000001;
const OPAQUE=0x00000002;
const BKMODE_LAST=0x00000002;
const GM_COMPATIBLE=0x00000001;
const GM_ADVANCED=0x00000002;
const GM_LAST=0x00000002;
const PT_CLOSEFIGURE=0x00000001;
const PT_LINETO=0x00000002;
const PT_BEZIERTO=0x00000004;
const PT_MOVETO=0x00000006;
const MM_TEXT=0x00000001;
const MM_LOMETRIC=0x00000002;
const MM_HIMETRIC=0x00000003;
const MM_LOENGLISH=0x00000004;
const MM_HIENGLISH=0x00000005;
const MM_TWIPS=0x00000006;
const MM_ISOTROPIC=0x00000007;
const MM_ANISOTROPIC=0x00000008;
const MM_MIN=MM_TEXT;
const MM_MAX=MM_ANISOTROPIC;
const MM_MAX_FIXEDSCALE=MM_TWIPS;
const ABSOLUTE=0x00000001;
const RELATIVE=0x00000002;
const WHITE_BRUSH=0x00000000;
const LTGRAY_BRUSH=0x00000001;
const GRAY_BRUSH=0x00000002;
const DKGRAY_BRUSH=0x00000003;
const BLACK_BRUSH=0x00000004;
const NULL_BRUSH=0x00000005;
const HOLLOW_BRUSH=NULL_BRUSH;
const WHITE_PEN=0x00000006;
const BLACK_PEN=0x00000007;
const NULL_PEN=0x00000008;
const OEM_FIXED_FONT=0x0000000A;
const ANSI_FIXED_FONT=0x0000000B;
const ANSI_VAR_FONT=0x0000000C;
const SYSTEM_FONT=0x0000000D;
const DEVICE_DEFAULT_FONT=0x0000000E;
const DEFAULT_PALETTE=0x0000000F;
const SYSTEM_FIXED_FONT=0x00000010;
const DEFAULT_GUI_FONT=0x00000011;
const STOCK_LAST=0x00000011;
const CLR_INVALID=0xFFFFFFFF;
const BS_SOLID=0x00000000;
const BS_NULL=0x00000001;
const BS_HOLLOW=BS_NULL;
const BS_HATCHED=0x00000002;
const BS_PATTERN=0x00000003;
const BS_INDEXED=0x00000004;
const BS_DIBPATTERN=0x00000005;
const BS_DIBPATTERNPT=0x00000006;
const BS_PATTERN8X8=0x00000007;
const BS_DIBPATTERN8X8=0x00000008;
const BS_MONOPATTERN=0x00000009;
const HS_HORIZONTAL=0x00000000;
const HS_VERTICAL=0x00000001;
const HS_FDIAGONAL=0x00000002;
const HS_BDIAGONAL=0x00000003;
const HS_CROSS=0x00000004;
const HS_DIAGCROSS=0x00000005;
const PS_SOLID=0x00000000;
const PS_DASH=0x00000001;
const PS_DOT=0x00000002;
const PS_DASHDOT=0x00000003;
const PS_DASHDOTDOT=0x00000004;
const PS_NULL=0x00000005;
const PS_INSIDEFRAME=0x00000006;
const PS_USERSTYLE=0x00000007;
const PS_ALTERNATE=0x00000008;
const PS_STYLE_MASK=0x0000000F;
const PS_ENDCAP_ROUND=0x00000000;
const PS_ENDCAP_SQUARE=0x00000100;
const PS_ENDCAP_FLAT=0x00000200;
const PS_ENDCAP_MASK=0x00000F00;
const PS_JOIN_ROUND=0x00000000;
const PS_JOIN_BEVEL=0x00001000;
const PS_JOIN_MITER=0x00002000;
const PS_JOIN_MASK=0x0000F000;
const PS_COSMETIC=0x00000000;
const PS_GEOMETRIC=0x00010000;
const PS_TYPE_MASK=0x000F0000;
const AD_COUNTERCLOCKWISE=0x00000001;
const AD_CLOCKWISE=0x00000002;
const DRIVERVERSION=0x00000000;
const TECHNOLOGY=0x00000002;
const HORZSIZE=0x00000004;
const VERTSIZE=0x00000006;
const HORZRES=0x00000008;
const VERTRES=0x0000000A;
const BITSPIXEL=0x0000000C;
const PLANES=0x0000000E;
const NUMBRUSHES=0x00000010;
const NUMPENS=0x00000012;
const NUMMARKERS=0x00000014;
const NUMFONTS=0x00000016;
const NUMCOLORS=0x00000018;
const PDEVICESIZE=0x0000001A;
const CURVECAPS=0x0000001C;
const LINECAPS=0x0000001E;
const POLYGONALCAPS=0x00000020;
const TEXTCAPS=0x00000022;
const CLIPCAPS=0x00000024;
const RASTERCAPS=0x00000026;
const ASPECTX=0x00000028;
const ASPECTY=0x0000002A;
const ASPECTXY=0x0000002C;
const LOGPIXELSX=0x00000058;
const LOGPIXELSY=0x0000005A;
const SIZEPALETTE=0x00000068;
const NUMRESERVED=0x0000006A;
const COLORRES=0x0000006C;
const PHYSICALWIDTH=0x0000006E;
const PHYSICALHEIGHT=0x0000006F;
const PHYSICALOFFSETX=0x00000070;
const PHYSICALOFFSETY=0x00000071;
const SCALINGFACTORX=0x00000072;
const SCALINGFACTORY=0x00000073;
const VREFRESH=0x00000074;
const DESKTOPVERTRES=0x00000075;
const DESKTOPHORZRES=0x00000076;
const BLTALIGNMENT=0x00000077;
const DT_PLOTTER=0x00000000;
const DT_RASDISPLAY=0x00000001;
const DT_RASPRINTER=0x00000002;
const DT_RASCAMERA=0x00000003;
const DT_CHARSTREAM=0x00000004;
const DT_METAFILE=0x00000005;
const DT_DISPFILE=0x00000006;
const CC_NONE=0x00000000;
const CC_CIRCLES=0x00000001;
const CC_PIE=0x00000002;
const CC_CHORD=0x00000004;
const CC_ELLIPSES=0x00000008;
const CC_WIDE=0x00000010;
const CC_STYLED=0x00000020;
const CC_WIDESTYLED=0x00000040;
const CC_INTERIORS=0x00000080;
const CC_ROUNDRECT=0x00000100;
const LC_NONE=0x00000000;
const LC_POLYLINE=0x00000002;
const LC_MARKER=0x00000004;
const LC_POLYMARKER=0x00000008;
const LC_WIDE=0x00000010;
const LC_STYLED=0x00000020;
const LC_WIDESTYLED=0x00000040;
const LC_INTERIORS=0x00000080;
const PC_NONE=0x00000000;
const PC_POLYGON=0x00000001;
const PC_RECTANGLE=0x00000002;
const PC_WINDPOLYGON=0x00000004;
const PC_TRAPEZOID=0x00000004;
const PC_SCANLINE=0x00000008;
const PC_WIDE=0x00000010;
const PC_STYLED=0x00000020;
const PC_WIDESTYLED=0x00000040;
const PC_INTERIORS=0x00000080;
const PC_POLYPOLYGON=0x00000100;
const PC_PATHS=0x00000200;
const CP_NONE=0x00000000;
const CP_RECTANGLE=0x00000001;
const CP_REGION=0x00000002;
const TC_OP_CHARACTER=0x00000001;
const TC_OP_STROKE=0x00000002;
const TC_CP_STROKE=0x00000004;
const TC_CR_90=0x00000008;
const TC_CR_ANY=0x00000010;
const TC_SF_X_YINDEP=0x00000020;
const TC_SA_DOUBLE=0x00000040;
const TC_SA_INTEGER=0x00000080;
const TC_SA_CONTIN=0x00000100;
const TC_EA_DOUBLE=0x00000200;
const TC_IA_ABLE=0x00000400;
const TC_UA_ABLE=0x00000800;
const TC_SO_ABLE=0x00001000;
const TC_RA_ABLE=0x00002000;
const TC_VA_ABLE=0x00004000;
const TC_RESERVED=0x00008000;
const TC_SCROLLBLT=0x00010000;
const RC_NONE=0;
const RC_BITBLT=0x00000001;
const RC_BANDING=0x00000002;
const RC_SCALING=0x00000004;
const RC_BITMAP64=0x00000008;
const RC_GDI20_OUTPUT=0x00000010;
const RC_GDI20_STATE=0x00000020;
const RC_SAVEBITMAP=0x00000040;
const RC_DI_BITMAP=0x00000080;
const RC_PALETTE=0x00000100;
const RC_DIBTODEV=0x00000200;
const RC_BIGFONT=0x00000400;
const RC_STRETCHBLT=0x00000800;
const RC_FLOODFILL=0x00001000;
const RC_STRETCHDIB=0x00002000;
const RC_OP_DX_OUTPUT=0x00004000;
const RC_DEVBITS=0x00008000;
const DIB_RGB_COLORS=0x00000000;
const DIB_PAL_COLORS=0x00000001;
const SYSPAL_ERROR=0x00000000;
const SYSPAL_STATIC=0x00000001;
const SYSPAL_NOSTATIC=0x00000002;
const CBM_INIT=0x00000004;
const FLOODFILLBORDER=0x00000000;
const FLOODFILLSURFACE=0x00000001;

const DM_SPECVERSION=0x00000401;
const DM_ORIENTATION=0x00000001;
const DM_PAPERSIZE=0x00000002;
const DM_PAPERLENGTH=0x00000004;
const DM_PAPERWIDTH=0x00000008;
const DM_SCALE=0x00000010;
const DM_COPIES=0x00000100;
const DM_DEFAULTSOURCE=0x00000200;
const DM_PRINTQUALITY=0x00000400;
const DM_COLOR=0x00000800;
const DM_DUPLEX=0x00001000;
const DM_YRESOLUTION=0x00002000;
const DM_TTOPTION=0x00004000;
const DM_COLLATE=0x00008000;
const DM_FORMNAME=0x00010000;
const DM_LOGPIXELS=0x00020000;
const DM_BITSPERPEL=0x00040000;
const DM_PELSWIDTH=0x00080000;
const DM_PELSHEIGHT=0x00100000;
const DM_DISPLAYFLAGS=0x00200000;
const DM_DISPLAYFREQUENCY=0x00400000;
const DM_PANNINGWIDTH=0x00800000;
const DM_PANNINGHEIGHT=0x01000000;
const DM_ICMMETHOD=0x02000000;
const DM_ICMINTENT=0x04000000;
const DM_MEDIATYPE=0x08000000;
const DM_DITHERTYPE=0x10000000;
const DM_ICCMANUFACTURER=0x20000000;
const DM_ICCMODEL=0x40000000;
const DMORIENT_PORTRAIT=0x00000001;
const DMORIENT_LANDSCAPE=0x00000002;
const DMPAPER_LETTER=0x00000001;
const DMPAPER_FIRST=DMPAPER_LETTER;
const DMPAPER_LETTERSMALL=0x00000002;
const DMPAPER_TABLOID=0x00000003;
const DMPAPER_LEDGER=0x00000004;
const DMPAPER_LEGAL=0x00000005;
const DMPAPER_STATEMENT=0x00000006;
const DMPAPER_EXECUTIVE=0x00000007;
const DMPAPER_A3=0x00000008;
const DMPAPER_A4=0x00000009;
const DMPAPER_A4SMALL=0x0000000A;
const DMPAPER_A5=0x0000000B;
const DMPAPER_B4=0x0000000C;
const DMPAPER_B5=0x0000000D;
const DMPAPER_FOLIO=0x0000000E;
const DMPAPER_QUARTO=0x0000000F;
const DMPAPER_10X14=0x00000010;
const DMPAPER_11X17=0x00000011;
const DMPAPER_NOTE=0x00000012;
const DMPAPER_ENV_9=0x00000013;
const DMPAPER_ENV_10=0x00000014;
const DMPAPER_ENV_11=0x00000015;
const DMPAPER_ENV_12=0x00000016;
const DMPAPER_ENV_14=0x00000017;
const DMPAPER_CSHEET=0x00000018;
const DMPAPER_DSHEET=0x00000019;
const DMPAPER_ESHEET=0x0000001A;
const DMPAPER_ENV_DL=0x0000001B;
const DMPAPER_ENV_C5=0x0000001C;
const DMPAPER_ENV_C3=0x0000001D;
const DMPAPER_ENV_C4=0x0000001E;
const DMPAPER_ENV_C6=0x0000001F;
const DMPAPER_ENV_C65=0x00000020;
const DMPAPER_ENV_B4=0x00000021;
const DMPAPER_ENV_B5=0x00000022;
const DMPAPER_ENV_B6=0x00000023;
const DMPAPER_ENV_ITALY=0x00000024;
const DMPAPER_ENV_MONARCH=0x00000025;
const DMPAPER_ENV_PERSONAL=0x00000026;
const DMPAPER_FANFOLD_US=0x00000027;
const DMPAPER_FANFOLD_STD_GERMAN=0x00000028;
const DMPAPER_FANFOLD_LGL_GERMAN=0x00000029;
const DMPAPER_ISO_B4=0x0000002A;
const DMPAPER_JAPANESE_POSTCARD=0x0000002B;
const DMPAPER_9X11=0x0000002C;
const DMPAPER_10X11=0x0000002D;
const DMPAPER_15X11=0x0000002E;
const DMPAPER_ENV_INVITE=0x0000002F;
const DMPAPER_RESERVED_48=0x00000030;
const DMPAPER_RESERVED_49=0x00000031;
const DMPAPER_LETTER_EXTRA=0x00000032;
const DMPAPER_LEGAL_EXTRA=0x00000033;
const DMPAPER_TABLOID_EXTRA=0x00000034;
const DMPAPER_A4_EXTRA=0x00000035;
const DMPAPER_LETTER_TRANSVERSE=0x00000036;
const DMPAPER_A4_TRANSVERSE=0x00000037;
const DMPAPER_LETTER_EXTRA_TRANSVERSE=0x00000038;
const DMPAPER_A_PLUS=0x00000039;
const DMPAPER_B_PLUS=0x0000003A;
const DMPAPER_LETTER_PLUS=0x0000003B;
const DMPAPER_A4_PLUS=0x0000003C;
const DMPAPER_A5_TRANSVERSE=0x0000003D;
const DMPAPER_B5_TRANSVERSE=0x0000003E;
const DMPAPER_A3_EXTRA=0x0000003F;
const DMPAPER_A5_EXTRA=0x00000040;
const DMPAPER_B5_EXTRA=0x00000041;
const DMPAPER_A2=0x00000042;
const DMPAPER_A3_TRANSVERSE=0x00000043;
const DMPAPER_A3_EXTRA_TRANSVERSE=0x00000044;
const DMPAPER_LAST=DMPAPER_A3_EXTRA_TRANSVERSE;
const DMPAPER_USER=0x00000100;
const DMBIN_UPPER=0x00000001;
const DMBIN_FIRST=DMBIN_UPPER;
const DMBIN_ONLYONE=0x00000001;
const DMBIN_LOWER=0x00000002;
const DMBIN_MIDDLE=0x00000003;
const DMBIN_MANUAL=0x00000004;
const DMBIN_ENVELOPE=0x00000005;
const DMBIN_ENVMANUAL=0x00000006;
const DMBIN_AUTO=0x00000007;
const DMBIN_TRACTOR=0x00000008;
const DMBIN_SMALLFMT=0x00000009;
const DMBIN_LARGEFMT=0x0000000A;
const DMBIN_LARGECAPACITY=0x0000000B;
const DMBIN_CASSETTE=0x0000000E;
const DMBIN_FORMSOURCE=0x0000000F;
const DMBIN_LAST=DMBIN_FORMSOURCE;
const DMBIN_USER=0x00000100;
const DMRES_DRAFT=-0x00000001;
const DMRES_LOW=-0x00000002;
const DMRES_MEDIUM=-0x00000003;
const DMRES_HIGH=-0x00000004;
const DMCOLOR_MONOCHROME=0x00000001;
const DMCOLOR_COLOR=0x00000002;
const DMDUP_SIMPLEX=0x00000001;
const DMDUP_VERTICAL=0x00000002;
const DMDUP_HORIZONTAL=0x00000003;
const DMTT_BITMAP=0x00000001;
const DMTT_DOWNLOAD=0x00000002;
const DMTT_SUBDEV=0x00000003;
const DMTT_DOWNLOAD_OUTLINE=0x00000004;
const DMCOLLATE_FALSE=0x00000000;
const DMCOLLATE_TRUE=0x00000001;
const DMDISPLAYFLAGS_TEXTMODE=0x00000004;
const DMICMMETHOD_NONE=0x00000001;
const DMICMMETHOD_SYSTEM=0x00000002;
const DMICMMETHOD_DRIVER=0x00000003;
const DMICMMETHOD_DEVICE=0x00000004;
const DMICMMETHOD_USER=0x00000100;
const DMICM_SATURATE=0x00000001;
const DMICM_CONTRAST=0x00000002;
const DMICM_COLORMETRIC=0x00000003;
const DMICM_USER=0x00000100;
const DMMEDIA_STANDARD=0x00000001;
const DMMEDIA_TRANSPARENCY=0x00000002;
const DMMEDIA_GLOSSY=0x00000003;
const DMMEDIA_USER=0x00000100;
const DMDITHER_NONE=0x00000001;
const DMDITHER_COARSE=0x00000002;
const DMDITHER_FINE=0x00000003;
const DMDITHER_LINEART=0x00000004;
const DMDITHER_GRAYSCALE=0x00000005;
const DMDITHER_USER=0x00000100;
const RDH_RECTANGLES=0x00000001;
type RGNDATAHEADER=record
       dwSize:cardinal;
       iType:cardinal;
       nCount:cardinal;
       nRgnSize:cardinal;
       rcBound:RECT;
     end;
     pRGNDATAHEADER=pointer to RGNDATAHEADER;

type RGNDATA=record
       rdh:RGNDATAHEADER;
       Buffer:array[0..0]of char;
     end;
     pRGNDATA=pointer to RGNDATA;

type ABC=record
       abcA:integer;
       abcB:cardinal;
       abcC:integer;
     end;
     pABC=pointer to ABC;

type ABCFLOAT=record
       abcfA:real;
       abcfB:real;
       abcfC:real;
     end;
     pABCFLOAT=pointer to ABCFLOAT;

type OUTLINETEXTMETRIC=record
       otmSize:cardinal;
       otmTextMetrics:TEXTMETRIC;
       otmFiller:byte;
       otmPanoseNumber:PANOSE;
       otmfsSelection:cardinal;
       otmfsType:cardinal;
       otmsCharSlopeRise:integer;
       otmsCharSlopeRun:integer;
       otmItalicAngle:integer;
       otmEMSquare:cardinal;
       otmAscent:integer;
       otmDescent:integer;
       otmLineGap:cardinal;
       otmsCapEmHeight:cardinal;
       otmsXHeight:cardinal;
       otmrcFontBox:RECT;
       otmMacAscent:integer;
       otmMacDescent:integer;
       otmMacLineGap:cardinal;
       otmusMinimumPPEM:cardinal;
       otmptSubscriptSize:POINT;
       otmptSubscriptOffset:POINT;
       otmptSuperscriptSize:POINT;
       otmptSuperscriptOffset:POINT;
       otmsStrikeoutSize:cardinal;
       otmsStrikeoutPosition:integer;
       otmsUnderscoreSize:integer;
       otmsUnderscorePosition:integer;
       otmpFamilyName:pstr;
       otmpFaceName:pstr;
       otmpStyleName:pstr;
       otmpFullName:pstr;
     end;
     pOUTLINETEXTMETRIC=pointer to OUTLINETEXTMETRIC;

type POLYTEXT=record
       x:integer;
       y:integer;
       n:cardinal;
       lpstr:pstr;
       uiFlags:cardinal;
       rcl:RECT;
       pdx:pINT;
     end;
     pPOLYTEXT=pointer to POLYTEXT;

type FIXED=record
       fract:word;
       value:word;
     end;
     pFIXED=pointer to FIXED;

type MAT2=record
       eM11:FIXED;
       eM12:FIXED;
       eM21:FIXED;
       eM22:FIXED;
     end;
     pMAT2=pointer to MAT2;

type GLYPHMETRICS=record
       gmBlackBoxX:cardinal;
       gmBlackBoxY:cardinal;
       gmptGlyphOrigin:POINT;
       gmCellIncX:word;
       gmCellIncY:word;
     end;
     pGLYPHMETRICS=pointer to GLYPHMETRICS;

const GGO_METRICS=0x00000000;
const GGO_BITMAP=0x00000001;
const GGO_NATIVE=0x00000002;
const GGO_GRAY2_BITMAP=0x00000004;
const GGO_GRAY4_BITMAP=0x00000005;
const GGO_GRAY8_BITMAP=0x00000006;
const GGO_GLYPH_INDEX=0x00000080;
const TT_POLYGON_TYPE=0x00000018;
const TT_PRIM_LINE=0x00000001;
const TT_PRIM_QSPLINE=0x00000002;
type POINTFX=record
       x:FIXED;
       y:FIXED;
     end;
     pPOINTFX=pointer to POINTFX;

type TTPOLYCURVE=record
       wType:word;
       cpfx:word;
       apfx:array[0..0]of POINTFX;
     end;
     pTTPOLYCURVE=pointer to TTPOLYCURVE;

type TTPOLYGONHEADER=record
       cb:cardinal;
       dwType:cardinal;
       pfxStart:POINTFX;
     end;
     pTTPOLYGONHEADER=pointer to TTPOLYGONHEADER;

const GCP_DBCS=0x00000001;
const GCP_REORDER=0x00000002;
const GCP_USEKERNING=0x00000008;
const GCP_GLYPHSHAPE=0x00000010;
const GCP_LIGATE=0x00000020;
const GCP_DIACRITIC=0x00000100;
const GCP_KASHIDA=0x00000400;
const GCP_ERROR=0x00008000;
const FLI_MASK=0x0000103B;
const GCP_JUSTIFY=0x00010000;
const FLI_GLYPHS=0x00040000;
const GCP_CLASSIN=0x00080000;
const GCP_MAXEXTENT=0x00100000;
const GCP_JUSTIFYIN=0x00200000;
const GCP_DISPLAYZWG=0x00400000;
const GCP_SYMSWAPOFF=0x00800000;
const GCP_NUMERICOVERRIDE=0x01000000;
const GCP_NEUTRALOVERRIDE=0x02000000;
const GCP_NUMERICSLATIN=0x04000000;
const GCP_NUMERICSLOCAL=0x08000000;
const GCPCLASS_LATIN=0x00000001;
const GCPCLASS_HEBREW=0x00000002;
const GCPCLASS_ARABIC=0x00000002;
const GCPCLASS_NEUTRAL=0x00000003;
const GCPCLASS_LOCALNUMBER=0x00000004;
const GCPCLASS_LATINNUMBER=0x00000005;
const GCPCLASS_LATINNUMERICTERMINATOR=0x00000006;
const GCPCLASS_LATINNUMERICSEPARATOR=0x00000007;
const GCPCLASS_NUMERICSEPARATOR=0x00000008;
const GCPCLASS_PREBOUNDLTR=0x00000080;
const GCPCLASS_PREBOUNDRTL=0x00000040;
const GCPCLASS_POSTBOUNDLTR=0x00000020;
const GCPCLASS_POSTBOUNDRTL=0x00000010;
const GCPGLYPH_LINKBEFORE=0x00008000;
const GCPGLYPH_LINKAFTER=0x00004000;
type GCP_RESULTS=record
       lStructSize:cardinal;
       lpOutString:pstr;
       lpOrder:pCARDINAL;
       lpDx:pINT;
       lpCaretPos:pINT;
       lpClass:pstr;
       lpGlyphs:address;
       nGlyphs:cardinal;
       nMaxFit:integer;
     end;
     pGCP_RESULTS=pointer to GCP_RESULTS;

type RASTERIZER_STATUS=record
       nSize:word;
       wFlags:word;
       nLanguageID:word;
     end;
     pRASTERIZER_STATUS=pointer to RASTERIZER_STATUS;

const TT_AVAILABLE=0x00000001;
const TT_ENABLED=0x00000002;
type PIXELFORMATDESCRIPTOR=record
       nSize:word;
       nVersion:word;
       dwFlags:cardinal;
       iPixelType:byte;
       cColorBits:byte;
       cRedBits:byte;
       cRedShift:byte;
       cGreenBits:byte;
       cGreenShift:byte;
       cBlueBits:byte;
       cBlueShift:byte;
       cAlphaBits:byte;
       cAlphaShift:byte;
       cAccumBits:byte;
       cAccumRedBits:byte;
       cAccumGreenBits:byte;
       cAccumBlueBits:byte;
       cAccumAlphaBits:byte;
       cDepthBits:byte;
       cStencilBits:byte;
       cAuxBuffers:byte;
       iLayerType:byte;
       bReserved:byte;
       dwLayerMask:cardinal;
       dwVisibleMask:cardinal;
       dwDamageMask:cardinal;
     end;
     pPIXELFORMATDESCRIPTOR=pointer to PIXELFORMATDESCRIPTOR;

const PFD_TYPE_RGBA=0x00000000;
const PFD_TYPE_COLORINDEX=0x00000001;
const PFD_MAIN_PLANE=0x00000000;
const PFD_OVERLAY_PLANE=0x00000001;
const PFD_UNDERLAY_PLANE=-0x00000001;
const PFD_DOUBLEBUFFER=0x00000001;
const PFD_STEREO=0x00000002;
const PFD_DRAW_TO_WINDOW=0x00000004;
const PFD_DRAW_TO_BITMAP=0x00000008;
const PFD_SUPPORT_GDI=0x00000010;
const PFD_SUPPORT_OPENGL=0x00000020;
const PFD_GENERIC_FORMAT=0x00000040;
const PFD_NEED_PALETTE=0x00000080;
const PFD_NEED_SYSTEM_PALETTE=0x00000100;
const PFD_SWAP_EXCHANGE=0x00000200;
const PFD_SWAP_COPY=0x00000400;
const PFD_SWAP_LAYER_BUFFERS=0x00000800;
const PFD_GENERIC_ACCELERATED=0x00001000;
const PFD_DEPTH_DONTCARE=0x20000000;
const PFD_DOUBLEBUFFER_DONTCARE=0x40000000;
const PFD_STEREO_DONTCARE=0x80000000;

procedure AddFontResource ascii(pstr):integer;
procedure AnimatePalette(HPALETTE; cardinal; cardinal; pPALETTEENTRY):boolean;
procedure Arc(HDC; integer; integer; integer; integer; integer; integer; integer; integer):boolean;
procedure BitBlt(HDC; integer; integer; integer; integer; HDC; integer; integer; cardinal):boolean;
procedure CancelDC(HDC):boolean;
procedure Chord(HDC; integer; integer; integer; integer; integer; integer; integer; integer):boolean;
procedure ChoosePixelFormat(HDC; pPIXELFORMATDESCRIPTOR):integer;
procedure CloseMetaFile(HDC):HMETAFILE;
procedure CombineRgn(HRGN; HRGN; HRGN; integer):integer;
procedure CopyMetaFile ascii(HMETAFILE; pstr):HMETAFILE;
procedure CreateBitmap(integer; integer; cardinal; cardinal; address):HBITMAP;
procedure CreateBitmapIndirect(pBITMAP):HBITMAP;
procedure CreateBrushIndirect(pLOGBRUSH):HBRUSH;
procedure CreateCompatibleBitmap(HDC; integer; integer):HBITMAP;
procedure CreateDiscardableBitmap(HDC; integer; integer):HBITMAP;
procedure CreateCompatibleDC(HDC):HDC;
procedure CreateDC ascii(pstr; pstr; pstr; pDEVMODE):HDC;
procedure CreateDIBitmap(HDC; pBITMAPINFOHEADER; cardinal; address; pBITMAPINFO; cardinal):HBITMAP;
procedure CreateDIBPatternBrush(HGLOBAL; cardinal):HBRUSH;
procedure CreateDIBPatternBrushPt(address; cardinal):HBRUSH;
procedure CreateEllipticRgn(integer; integer; integer; integer):HRGN;
procedure CreateEllipticRgnIndirect(pRECT):HRGN;
procedure CreateFontIndirect ascii(pLOGFONT):HFONT;
procedure CreateFont ascii(integer; integer; integer; integer; integer; cardinal; cardinal; cardinal; cardinal; cardinal; cardinal; cardinal; cardinal; pstr):HFONT;
procedure CreateHatchBrush(integer; COLORREF):HBRUSH;
procedure CreateIC ascii(pstr; pstr; pstr; pDEVMODE):HDC;
procedure CreateMetaFile ascii(pstr):HDC;
procedure CreatePalette(pLOGPALETTE):HPALETTE;
procedure CreatePen(integer; integer; COLORREF):HPEN;
procedure CreatePenIndirect(pLOGPEN):HPEN;
procedure CreatePolyPolygonRgn(pPOINT; pINT; integer; integer):HRGN;
procedure CreatePatternBrush(HBITMAP):HBRUSH;
procedure CreateRectRgn(integer; integer; integer; integer):HRGN;
procedure CreateRectRgnIndirect(pRECT):HRGN;
procedure CreateRoundRectRgn(integer; integer; integer; integer; integer; integer):HRGN;
procedure CreateScalableFontResource ascii(cardinal; pstr; pstr; pstr):boolean;
procedure CreateSolidBrush(COLORREF):HBRUSH;
procedure DeleteDC(HDC):boolean;
procedure DeleteMetaFile(HMETAFILE):boolean;
procedure DeleteObject(HGDIOBJ):boolean;
procedure DescribePixelFormat(HDC; integer; cardinal; pPIXELFORMATDESCRIPTOR):integer;

const DM_UPDATE=0x00000001;
const DM_COPY=0x00000002;
const DM_PROMPT=0x00000004;
const DM_MODIFY=0x00000008;
const DM_IN_BUFFER=DM_MODIFY;
const DM_IN_PROMPT=DM_PROMPT;
const DM_OUT_BUFFER=DM_COPY;
const DM_OUT_DEFAULT=DM_UPDATE;
const DC_FIELDS=0x00000001;
const DC_PAPERS=0x00000002;
const DC_PAPERSIZE=0x00000003;
const DC_MINEXTENT=0x00000004;
const DC_MAXEXTENT=0x00000005;
const DC_BINS=0x00000006;
const DC_DUPLEX=0x00000007;
const DC_SIZE=0x00000008;
const DC_EXTRA=0x00000009;
const DC_VERSION=0x0000000A;
const DC_DRIVER=0x0000000B;
const DC_BINNAMES=0x0000000C;
const DC_ENUMRESOLUTIONS=0x0000000D;
const DC_FILEDEPENDENCIES=0x0000000E;
const DC_TRUETYPE=0x0000000F;
const DC_PAPERNAMES=0x00000010;
const DC_ORIENTATION=0x00000011;
const DC_COPIES=0x00000012;
const DC_BINADJUST=0x00000013;
const DC_EMF_COMPLIANT=0x00000014;
const DC_DATATYPE_PRODUCED=0x00000015;
const DC_COLLATE=0x00000016;
const DCTT_BITMAP=0x00000001;
const DCTT_DOWNLOAD=0x00000002;
const DCTT_SUBDEV=0x00000004;
const DCTT_DOWNLOAD_OUTLINE=0x00000008;
const DCBA_FACEUPNONE=0x00000000;
const DCBA_FACEUPCENTER=0x00000001;
const DCBA_FACEUPLEFT=0x00000002;
const DCBA_FACEUPRIGHT=0x00000003;
const DCBA_FACEDOWNNONE=0x00000100;
const DCBA_FACEDOWNCENTER=0x00000101;
const DCBA_FACEDOWNLEFT=0x00000102;
const DCBA_FACEDOWNRIGHT=0x00000103;

procedure DrawEscape(HDC; integer; integer; pstr):integer;
procedure Ellipse(HDC; integer; integer; integer; integer):boolean;
procedure EnumFontFamiliesEx ascii(HDC; pLOGFONT; pPROC; cardinal; cardinal):integer;
procedure EnumFontFamilies ascii(HDC; pstr; pPROC; cardinal):integer;
procedure EnumFonts ascii(HDC; pstr; pPROC; cardinal):integer;
procedure EnumObjects(HDC; integer; pPROC; address):integer;
procedure EqualRgn(HRGN; HRGN):boolean;
procedure Escape(HDC; integer; integer; pstr; address):integer;
procedure ExtEscape(HDC; integer; integer; pstr; integer; pstr):integer;
procedure ExcludeClipRect(HDC; integer; integer; integer; integer):integer;
procedure ExtCreateRegion(pXFORM; cardinal; pRGNDATA):HRGN;
procedure ExtFloodFill(HDC; integer; integer; COLORREF; cardinal):boolean;
procedure FillRgn(HDC; HRGN; HBRUSH):boolean;
procedure FloodFill(HDC; integer; integer; COLORREF):boolean;
procedure FrameRgn(HDC; HRGN; HBRUSH; integer; integer):boolean;
procedure GetROP2(HDC):integer;
procedure GetAspectRatioFilterEx(HDC; pSIZE):boolean;
procedure GetBkColor(HDC):COLORREF;
procedure GetBkMode(HDC):integer;
procedure GetBitmapBits(HBITMAP; integer; address):integer;
procedure GetBitmapDimensionEx(HBITMAP; pSIZE):boolean;
procedure GetBoundsRect(HDC; pRECT; cardinal):cardinal;
procedure GetBrushOrgEx(HDC; pPOINT):boolean;
procedure GetCharWidth ascii(HDC; cardinal; cardinal; pINT):boolean;
procedure GetCharWidth32 ascii(HDC; cardinal; cardinal; pINT):boolean;
procedure GetCharWidthFloat ascii(HDC; cardinal; cardinal; pREAL):boolean;
procedure GetCharABCWidths ascii(HDC; cardinal; cardinal; pABC):boolean;
procedure GetCharABCWidthsFloat ascii(HDC; cardinal; cardinal; pABCFLOAT):boolean;
procedure GetClipBox(HDC; pRECT):integer;
procedure GetClipRgn(HDC; HRGN):integer;
procedure GetMetaRgn(HDC; HRGN):integer;
procedure GetCurrentObject(HDC; cardinal):HGDIOBJ;
procedure GetCurrentPositionEx(HDC; pPOINT):boolean;
procedure GetDeviceCaps(HDC; integer):integer;
procedure GetDIBits(HDC; HBITMAP; cardinal; cardinal; address; pBITMAPINFO; cardinal):integer;
procedure GetFontData(HDC; cardinal; cardinal; address; cardinal):cardinal;
procedure GetGlyphOutline ascii(HDC; cardinal; cardinal; pGLYPHMETRICS; cardinal; address; pMAT2):cardinal;
procedure GetGraphicsMode(HDC):integer;
procedure GetMapMode(HDC):integer;
procedure GetMetaFileBitsEx(HMETAFILE; cardinal; address):cardinal;
procedure GetMetaFile ascii(pstr):HMETAFILE;
procedure GetNearestColor(HDC; COLORREF):COLORREF;
procedure GetNearestPaletteIndex(HPALETTE; COLORREF):cardinal;
procedure GetObjectType(h:HGDIOBJ):cardinal;
procedure GetOutlineTextMetrics ascii(HDC; cardinal; pOUTLINETEXTMETRIC):cardinal;
procedure GetPaletteEntries(HPALETTE; cardinal; cardinal; pPALETTEENTRY):cardinal;
procedure GetPixel(HDC; integer; integer):COLORREF;
procedure GetPixelFormat(HDC):integer;
procedure GetPolyFillMode(HDC):integer;
procedure GetRasterizerCaps(pRASTERIZER_STATUS; cardinal):boolean;
procedure GetRegionData(HRGN; cardinal; pRGNDATA):cardinal;
procedure GetRgnBox(HRGN; pRECT):integer;
procedure GetStockObject(integer):HGDIOBJ;
procedure GetStretchBltMode(HDC):integer;
procedure GetSystemPaletteEntries(HDC; cardinal; cardinal; pPALETTEENTRY):cardinal;
procedure GetSystemPaletteUse(HDC):cardinal;
procedure GetTextCharacterExtra(HDC):integer;
procedure GetTextAlign(HDC):cardinal;
procedure GetTextColor(HDC):COLORREF;
procedure GetTextExtentPoint ascii(HDC; pstr; integer; pSIZE):boolean;
procedure GetTextExtentPoint32 ascii(HDC; pstr; integer; pSIZE):boolean;
procedure GetTextExtentExPoint ascii(HDC; pstr; integer; integer; pINT; pINT; pSIZE):boolean;
procedure GetTextCharset(hdc:HDC):integer;
procedure GetTextCharsetInfo(hdc:HDC; lpSig:pFONTSIGNATURE; dwFlags:cardinal):integer;
procedure TranslateCharsetInfo(lpSrc:pCARDINAL; lpCs:pCHARSETINFO; dwFlags:cardinal):boolean;
procedure GetFontLanguageInfo(HDC):cardinal;
procedure GetCharacterPlacement ascii(HDC; pstr; integer; integer; pGCP_RESULTS; cardinal):cardinal;
procedure GetViewportExtEx(HDC; pSIZE):boolean;
procedure GetViewportOrgEx(HDC; pPOINT):boolean;
procedure GetWindowExtEx(HDC; pSIZE):boolean;
procedure GetWindowOrgEx(HDC; pPOINT):boolean;
procedure IntersectClipRect(HDC; integer; integer; integer; integer):integer;
procedure InvertRgn(HDC; HRGN):boolean;
procedure LineDDA(integer; integer; integer; integer; pPROC; cardinal):boolean;
procedure LineTo(HDC; integer; integer):boolean;
procedure MaskBlt(HDC; integer; integer; integer; integer; HDC; integer; integer; HBITMAP; integer; integer; cardinal):boolean;
procedure PlgBlt(HDC; pPOINT; HDC; integer; integer; integer; integer; HBITMAP; integer; integer):boolean;
procedure OffsetClipRgn(HDC; integer; integer):integer;
procedure OffsetRgn(HRGN; integer; integer):integer;
procedure PatBlt(HDC; integer; integer; integer; integer; cardinal):boolean;
procedure Pie(HDC; integer; integer; integer; integer; integer; integer; integer; integer):boolean;
procedure PlayMetaFile(HDC; HMETAFILE):boolean;
procedure PaintRgn(HDC; HRGN):boolean;
procedure PolyPolygon(HDC; pPOINT; pINT; integer):boolean;
procedure PtInRegion(HRGN; integer; integer):boolean;
procedure PtVisible(HDC; integer; integer):boolean;
procedure RectInRegion(HRGN; pRECT):boolean;
procedure RectVisible(HDC; pRECT):boolean;
procedure Rectangle(HDC; integer; integer; integer; integer):boolean;
procedure RestoreDC(HDC; integer):boolean;
procedure ResetDC ascii(HDC; pDEVMODE):HDC;
procedure RealizePalette(HDC):cardinal;
procedure RemoveFontResource ascii(pstr):boolean;
procedure RoundRect(HDC; integer; integer; integer; integer; integer; integer):boolean;
procedure ResizePalette(HPALETTE; cardinal):boolean;
procedure SaveDC(HDC):integer;
procedure SelectClipRgn(HDC; HRGN):integer;
procedure ExtSelectClipRgn(HDC; HRGN; integer):integer;
procedure SetMetaRgn(HDC):integer;
procedure SelectObject(HDC; HGDIOBJ):HGDIOBJ;
procedure SelectPalette(HDC; HPALETTE; boolean):HPALETTE;
procedure SetBkColor(HDC; COLORREF):COLORREF;
procedure SetBkMode(HDC; integer):integer;
procedure SetBitmapBits(HBITMAP; cardinal; address):integer;
procedure SetBoundsRect(HDC; pRECT; cardinal):cardinal;
procedure SetDIBits(HDC; HBITMAP; cardinal; cardinal; address; pBITMAPINFO; cardinal):integer;
procedure SetDIBitsToDevice(HDC; integer; integer; cardinal; cardinal; integer; integer; cardinal; cardinal; address; pBITMAPINFO; cardinal):integer;
procedure SetMapperFlags(HDC; cardinal):cardinal;
procedure SetGraphicsMode(hdc:HDC; iMode:integer):integer;
procedure SetMapMode(HDC; integer):integer;
procedure SetMetaFileBitsEx(cardinal; pBYTE):HMETAFILE;
procedure SetPaletteEntries(HPALETTE; cardinal; cardinal; pPALETTEENTRY):cardinal;
procedure SetPixel(HDC; integer; integer; COLORREF):COLORREF;
procedure SetPixelV(HDC; integer; integer; COLORREF):boolean;
procedure SetPixelFormat(HDC; integer; pPIXELFORMATDESCRIPTOR):boolean;
procedure SetPolyFillMode(HDC; integer):integer;
procedure StretchBlt(HDC; integer; integer; integer; integer; HDC; integer; integer; integer; integer; cardinal):boolean;
procedure SetRectRgn(HRGN; integer; integer; integer; integer):boolean;
procedure StretchDIBits(HDC; integer; integer; integer; integer; integer; integer; integer; integer; address; pBITMAPINFO; cardinal; cardinal):integer;
procedure SetROP2(HDC; integer):integer;
procedure SetStretchBltMode(HDC; integer):integer;
procedure SetSystemPaletteUse(HDC; cardinal):cardinal;
procedure SetTextCharacterExtra(HDC; integer):integer;
procedure SetTextColor(HDC; COLORREF):COLORREF;
procedure SetTextAlign(HDC; cardinal):cardinal;
procedure SetTextJustification(HDC; integer; integer):boolean;
procedure UpdateColors(HDC):boolean;
procedure PlayMetaFileRecord(HDC; pHANDLETABLE; pMETARECORD; cardinal):boolean;
procedure EnumMetaFile(HDC; HMETAFILE; pPROC; cardinal):boolean;
procedure CloseEnhMetaFile(HDC):HENHMETAFILE;
procedure CopyEnhMetaFile ascii(HENHMETAFILE; pstr):HENHMETAFILE;
procedure CreateEnhMetaFile ascii(HDC; pstr; pRECT; pstr):HDC;
procedure DeleteEnhMetaFile(HENHMETAFILE):boolean;
procedure EnumEnhMetaFile(HDC; HENHMETAFILE; pPROC; address; pRECT):boolean;
procedure GetEnhMetaFile ascii(pstr):HENHMETAFILE;
procedure GetEnhMetaFileBits(HENHMETAFILE; cardinal; pBYTE):cardinal;
procedure GetEnhMetaFileDescription ascii(HENHMETAFILE; cardinal; pstr):cardinal;
procedure GetEnhMetaFileHeader(HENHMETAFILE; cardinal; pENHMETAHEADER):cardinal;
procedure GetEnhMetaFilePaletteEntries(HENHMETAFILE; cardinal; pPALETTEENTRY):cardinal;
procedure GetWinMetaFileBits(HENHMETAFILE; cardinal; pBYTE; integer; HDC):cardinal;
procedure PlayEnhMetaFile(HDC; HENHMETAFILE; pRECT):boolean;
procedure PlayEnhMetaFileRecord(HDC; pHANDLETABLE; pENHMETARECORD; cardinal):boolean;
procedure SetEnhMetaFileBits(cardinal; pBYTE):HENHMETAFILE;
procedure SetWinMetaFileBits(cardinal; pBYTE; HDC; pMETAFILEPICT):HENHMETAFILE;
procedure GdiComment(HDC; cardinal; pBYTE):boolean;
procedure GetTextMetrics ascii(HDC; pTEXTMETRIC):boolean;

type DIBSECTION=record
       dsBm:BITMAP;
       dsBmih:BITMAPINFOHEADER;
       dsBitfields:array[0..2]of cardinal;
       dshSection:HANDLE;
       dsOffset:cardinal;
     end;
     pDIBSECTION=pointer to DIBSECTION;

procedure AngleArc(HDC; integer; integer; cardinal; real; real):boolean;
procedure PolyPolyline(HDC; pPOINT; pCARDINAL; cardinal):boolean;
procedure GetWorldTransform(HDC; pXFORM):boolean;
procedure SetWorldTransform(HDC; pXFORM):boolean;
procedure ModifyWorldTransform(HDC; pXFORM; cardinal):boolean;
procedure CombineTransform(pXFORM; pXFORM; pXFORM):boolean;
procedure CreateDIBSection(HDC; pBITMAPINFO; cardinal; address; HANDLE; cardinal):HBITMAP;
procedure GetDIBColorTable(HDC; cardinal; cardinal; pRGBQUAD):cardinal;
procedure SetDIBColorTable(HDC; cardinal; cardinal; pRGBQUAD):cardinal;

const CA_NEGATIVE=0x00000001;
const CA_LOG_FILTER=0x00000002;
const ILLUMINANT_DEVICE_DEFAULT=0x00000000;
const ILLUMINANT_A=0x00000001;
const ILLUMINANT_B=0x00000002;
const ILLUMINANT_C=0x00000003;
const ILLUMINANT_D50=0x00000004;
const ILLUMINANT_D55=0x00000005;
const ILLUMINANT_D65=0x00000006;
const ILLUMINANT_D75=0x00000007;
const ILLUMINANT_F2=0x00000008;
const ILLUMINANT_MAX_INDEX=ILLUMINANT_F2;
const ILLUMINANT_TUNGSTEN=ILLUMINANT_A;
const ILLUMINANT_DAYLIGHT=ILLUMINANT_C;
const ILLUMINANT_FLUORESCENT=ILLUMINANT_F2;
const ILLUMINANT_NTSC=ILLUMINANT_C;
const RGB_GAMMA_MIN=0x000009C4;
const RGB_GAMMA_MAX=0x0000FDE8;
const REFERENCE_WHITE_MIN=0x00001770;
const REFERENCE_WHITE_MAX=0x00002710;
const REFERENCE_BLACK_MIN=0x00000000;
const REFERENCE_BLACK_MAX=0x00000FA0;
const COLOR_ADJ_MIN=-0x00000064;
const COLOR_ADJ_MAX=0x00000064;
type COLORADJUSTMENT=record
       caSize:word;
       caFlags:word;
       caIlluminantIndex:word;
       caRedGamma:word;
       caGreenGamma:word;
       caBlueGamma:word;
       caReferenceBlack:word;
       caReferenceWhite:word;
       caContrast:word;
       caBrightness:word;
       caColorfulness:word;
       caRedGreenTint:word;
     end;
     pCOLORADJUSTMENT=pointer to COLORADJUSTMENT;

procedure SetColorAdjustment(HDC; pCOLORADJUSTMENT):boolean;
procedure GetColorAdjustment(HDC; pCOLORADJUSTMENT):boolean;
procedure CreateHalftonePalette(HDC):HPALETTE;

type DOCINFO=record
       cbSize:integer;
       lpszDocName:pstr;
       lpszOutput:pstr;
       lpszDatatype:pstr;
       fwType:cardinal;
     end;
     pDOCINFO=pointer to DOCINFO;

const DI_APPBANDING=0x00000001;

procedure StartDoc ascii(HDC; pDOCINFO):integer;
procedure EndDoc(HDC):integer;
procedure StartPage(HDC):integer;
procedure EndPage(HDC):integer;
procedure AbortDoc(HDC):integer;
procedure SetAbortProc(HDC; pPROC):integer;
procedure AbortPath(HDC):boolean;
procedure ArcTo(HDC; integer; integer; integer; integer; integer; integer; integer; integer):boolean;
procedure BeginPath(HDC):boolean;
procedure CloseFigure(HDC):boolean;
procedure EndPath(HDC):boolean;
procedure FillPath(HDC):boolean;
procedure FlattenPath(HDC):boolean;
procedure GetPath(HDC; pPOINT; pBYTE; integer):integer;
procedure PathToRegion(HDC):HRGN;
procedure PolyDraw(HDC; pPOINT; pBYTE; integer):boolean;
procedure SelectClipPath(HDC; integer):boolean;
procedure SetArcDirection(HDC; integer):integer;
procedure SetMiterLimit(HDC; real; pREAL):boolean;
procedure StrokeAndFillPath(HDC):boolean;
procedure StrokePath(HDC):boolean;
procedure WidenPath(HDC):boolean;
procedure ExtCreatePen(cardinal; cardinal; pLOGBRUSH; cardinal; pCARDINAL):HPEN;
procedure GetMiterLimit(HDC; pREAL):boolean;
procedure GetArcDirection(HDC):integer;
procedure GetObject ascii(HGDIOBJ; integer; address):integer;
procedure MoveToEx(HDC; integer; integer; pPOINT):boolean;
procedure TextOut ascii(HDC; integer; integer; pstr; integer):boolean;
procedure ExtTextOut ascii(HDC; integer; integer; cardinal; pRECT; pstr; cardinal; pINT):boolean;
procedure PolyTextOut ascii(HDC; pPOLYTEXT; integer):boolean;
procedure CreatePolygonRgn(pPOINT; integer; integer):HRGN;
procedure DPtoLP(HDC; pPOINT; integer):boolean;
procedure LPtoDP(HDC; pPOINT; integer):boolean;
procedure Polygon(HDC; pPOINT; integer):boolean;
procedure Polyline(HDC; pPOINT; integer):boolean;
procedure PolyBezier(HDC; pPOINT; cardinal):boolean;
procedure PolyBezierTo(HDC; pPOINT; cardinal):boolean;
procedure PolylineTo(HDC; pPOINT; cardinal):boolean;
procedure SetViewportExtEx(HDC; integer; integer; pSIZE):boolean;
procedure SetViewportOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure SetWindowExtEx(HDC; integer; integer; pSIZE):boolean;
procedure SetWindowOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure OffsetViewportOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure OffsetWindowOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure ScaleViewportExtEx(HDC; integer; integer; integer; integer; pSIZE):boolean;
procedure ScaleWindowExtEx(HDC; integer; integer; integer; integer; pSIZE):boolean;
procedure SetBitmapDimensionEx(HBITMAP; integer; integer; pSIZE):boolean;
procedure SetBrushOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure GetTextFace ascii(HDC; integer; pstr):integer;

const FONTMAPPER_MAX=0x0000000A;
type KERNINGPAIR=record
       wFirst:word;
       wSecond:word;
       iKernAmount:integer;
     end;
     pKERNINGPAIR=pointer to KERNINGPAIR;

procedure GetKerningPairs ascii(HDC; cardinal; pKERNINGPAIR):cardinal;
procedure GetDCOrgEx(HDC; pPOINT):boolean;
procedure FixBrushOrgEx(HDC; integer; integer; pPOINT):boolean;
procedure UnrealizeObject(HGDIOBJ):boolean;
procedure GdiFlush():boolean;
procedure GdiSetBatchLimit(cardinal):cardinal;
procedure GdiGetBatchLimit():cardinal;
const ICM_OFF=0x00000001;
const ICM_ON=0x00000002;
const ICM_QUERY=0x00000003;
procedure SetICMMode(HDC; integer):integer;
procedure CheckColorsInGamut(HDC; address; address; cardinal):boolean;
procedure GetColorSpace(HDC):HANDLE;
procedure GetLogColorSpace ascii(HCOLORSPACE; pLOGCOLORSPACE; cardinal):boolean;
procedure CreateColorSpace ascii(pLOGCOLORSPACE):HCOLORSPACE;
procedure SetColorSpace(HDC; HCOLORSPACE):boolean;
procedure DeleteColorSpace(HCOLORSPACE):boolean;
procedure GetICMProfile ascii(HDC; pCARDINAL; pstr):boolean;
procedure SetICMProfile ascii(HDC; pstr):boolean;
procedure GetDeviceGammaRamp(HDC; address):boolean;
procedure SetDeviceGammaRamp(HDC; address):boolean;
procedure ColorMatchToTarget(HDC; HDC; cardinal):boolean;
procedure EnumICMProfiles ascii(HDC; pPROC; cardinal):integer;

const ENHMETA_SIGNATURE=0x464D4520;
const ENHMETA_STOCK_OBJECT=0x80000000;
const EMR_HEADER=0x00000001;
const EMR_POLYBEZIER=0x00000002;
const EMR_POLYGON=0x00000003;
const EMR_POLYLINE=0x00000004;
const EMR_POLYBEZIERTO=0x00000005;
const EMR_POLYLINETO=0x00000006;
const EMR_POLYPOLYLINE=0x00000007;
const EMR_POLYPOLYGON=0x00000008;
const EMR_SETWINDOWEXTEX=0x00000009;
const EMR_SETWINDOWORGEX=0x0000000A;
const EMR_SETVIEWPORTEXTEX=0x0000000B;
const EMR_SETVIEWPORTORGEX=0x0000000C;
const EMR_SETBRUSHORGEX=0x0000000D;
const EMR_EOF=0x0000000E;
const EMR_SETPIXELV=0x0000000F;
const EMR_SETMAPPERFLAGS=0x00000010;
const EMR_SETMAPMODE=0x00000011;
const EMR_SETBKMODE=0x00000012;
const EMR_SETPOLYFILLMODE=0x00000013;
const EMR_SETROP2=0x00000014;
const EMR_SETSTRETCHBLTMODE=0x00000015;
const EMR_SETTEXTALIGN=0x00000016;
const EMR_SETCOLORADJUSTMENT=0x00000017;
const EMR_SETTEXTCOLOR=0x00000018;
const EMR_SETBKCOLOR=0x00000019;
const EMR_OFFSETCLIPRGN=0x0000001A;
const EMR_MOVETOEX=0x0000001B;
const EMR_SETMETARGN=0x0000001C;
const EMR_EXCLUDECLIPRECT=0x0000001D;
const EMR_INTERSECTCLIPRECT=0x0000001E;
const EMR_SCALEVIEWPORTEXTEX=0x0000001F;
const EMR_SCALEWINDOWEXTEX=0x00000020;
const EMR_SAVEDC=0x00000021;
const EMR_RESTOREDC=0x00000022;
const EMR_SETWORLDTRANSFORM=0x00000023;
const EMR_MODIFYWORLDTRANSFORM=0x00000024;
const EMR_SELECTOBJECT=0x00000025;
const EMR_CREATEPEN=0x00000026;
const EMR_CREATEBRUSHINDIRECT=0x00000027;
const EMR_DELETEOBJECT=0x00000028;
const EMR_ANGLEARC=0x00000029;
const EMR_ELLIPSE=0x0000002A;
const EMR_RECTANGLE=0x0000002B;
const EMR_ROUNDRECT=0x0000002C;
const EMR_ARC=0x0000002D;
const EMR_CHORD=0x0000002E;
const EMR_PIE=0x0000002F;
const EMR_SELECTPALETTE=0x00000030;
const EMR_CREATEPALETTE=0x00000031;
const EMR_SETPALETTEENTRIES=0x00000032;
const EMR_RESIZEPALETTE=0x00000033;
const EMR_REALIZEPALETTE=0x00000034;
const EMR_EXTFLOODFILL=0x00000035;
const EMR_LINETO=0x00000036;
const EMR_ARCTO=0x00000037;
const EMR_POLYDRAW=0x00000038;
const EMR_SETARCDIRECTION=0x00000039;
const EMR_SETMITERLIMIT=0x0000003A;
const EMR_BEGINPATH=0x0000003B;
const EMR_ENDPATH=0x0000003C;
const EMR_CLOSEFIGURE=0x0000003D;
const EMR_FILLPATH=0x0000003E;
const EMR_STROKEANDFILLPATH=0x0000003F;
const EMR_STROKEPATH=0x00000040;
const EMR_FLATTENPATH=0x00000041;
const EMR_WIDENPATH=0x00000042;
const EMR_SELECTCLIPPATH=0x00000043;
const EMR_ABORTPATH=0x00000044;
const EMR_GDICOMMENT=0x00000046;
const EMR_FILLRGN=0x00000047;
const EMR_FRAMERGN=0x00000048;
const EMR_INVERTRGN=0x00000049;
const EMR_PAINTRGN=0x0000004A;
const EMR_EXTSELECTCLIPRGN=0x0000004B;
const EMR_BITBLT=0x0000004C;
const EMR_STRETCHBLT=0x0000004D;
const EMR_MASKBLT=0x0000004E;
const EMR_PLGBLT=0x0000004F;
const EMR_SETDIBITSTODEVICE=0x00000050;
const EMR_STRETCHDIBITS=0x00000051;
const EMR_EXTCREATEFONTINDIRECTW=0x00000052;
const EMR_EXTTEXTOUT=0x00000053;
const EMR_POLYBEZIER16=0x00000055;
const EMR_POLYGON16=0x00000056;
const EMR_POLYLINE16=0x00000057;
const EMR_POLYBEZIERTO16=0x00000058;
const EMR_POLYLINETO16=0x00000059;
const EMR_POLYPOLYLINE16=0x0000005A;
const EMR_POLYPOLYGON16=0x0000005B;
const EMR_POLYDRAW16=0x0000005C;
const EMR_CREATEMONOBRUSH=0x0000005D;
const EMR_CREATEDIBPATTERNBRUSHPT=0x0000005E;
const EMR_EXTCREATEPEN=0x0000005F;
const EMR_POLYTEXTOUT=0x00000060;
const EMR_SETICMMODE=0x00000062;
const EMR_CREATECOLORSPACE=0x00000063;
const EMR_SETCOLORSPACE=0x00000064;
const EMR_DELETECOLORSPACE=0x00000065;
const EMR_GLSRECORD=0x00000066;
const EMR_GLSBOUNDEDRECORD=0x00000067;
const EMR_PIXELFORMAT=0x00000068;
const EMR_MIN=0x00000001;
const EMR_MAX=0x00000068;
type EMR=record
       iType:cardinal;
       nSize:cardinal;
     end;
     pEMR=pointer to EMR;

type EMRTEXT=record
       ptlReference:POINT;
       nChars:cardinal;
       offString:cardinal;
       fOptions:cardinal;
       rcl:RECT;
       offDx:cardinal;
     end;
     pEMRTEXT=pointer to EMRTEXT;

type EMRABORTPATH=record
       emr:EMR;
     end;
     pEMRABORTPATH=pointer to EMRABORTPATH;

type EMRSELECTCLIPPATH=record
       emr:EMR;
       iMode:cardinal;
     end;
     pEMRSELECTCLIPPATH=pointer to EMRSELECTCLIPPATH;

type EMRSETMITERLIMIT=record
       emr:EMR;
       eMiterLimit:real;
     end;
     pEMRSETMITERLIMIT=pointer to EMRSETMITERLIMIT;

type EMRRESTOREDC=record
       emr:EMR;
       iRelative:integer;
     end;
     pEMRRESTOREDC=pointer to EMRRESTOREDC;

type EMRSETARCDIRECTION=record
       emr:EMR;
       iArcDirection:cardinal;
     end;
     pEMRSETARCDIRECTION=pointer to EMRSETARCDIRECTION;

type EMRSETMAPPERFLAGS=record
       emr:EMR;
       dwFlags:cardinal;
     end;
     pEMRSETMAPPERFLAGS=pointer to EMRSETMAPPERFLAGS;

type EMRSETBKCOLOR=record
       emr:EMR;
       crColor:COLORREF;
     end;
     pEMRSETBKCOLOR=pointer to EMRSETBKCOLOR;

type EMRSELECTOBJECT=record
       emr:EMR;
       ihObject:cardinal;
     end;
     pEMRSELECTOBJECT=pointer to EMRSELECTOBJECT;

type EMRSELECTCOLORSPACE=record
       emr:EMR;
       ihCS:cardinal;
     end;
     pEMRSELECTCOLORSPACE=pointer to EMRSELECTCOLORSPACE;

type EMRSELECTPALETTE=record
       emr:EMR;
       ihPal:cardinal;
     end;
     pEMRSELECTPALETTE=pointer to EMRSELECTPALETTE;

type EMRRESIZEPALETTE=record
       emr:EMR;
       ihPal:cardinal;
       cEntries:cardinal;
     end;
     pEMRRESIZEPALETTE=pointer to EMRRESIZEPALETTE;

type EMRSETPALETTEENTRIES=record
       emr:EMR;
       ihPal:cardinal;
       iStart:cardinal;
       cEntries:cardinal;
       aPalEntries:array[0..0]of PALETTEENTRY;
     end;
     pEMRSETPALETTEENTRIES=pointer to EMRSETPALETTEENTRIES;

type EMRSETCOLORADJUSTMENT=record
       emr:EMR;
       ColorAdjustment:COLORADJUSTMENT;
     end;
     pEMRSETCOLORADJUSTMENT=pointer to EMRSETCOLORADJUSTMENT;

type EMRGDICOMMENT=record
       emr:EMR;
       cbData:cardinal;
       Data:array[0..0]of byte;
     end;
     pEMRGDICOMMENT=pointer to EMRGDICOMMENT;

type EMREOF=record
       emr:EMR;
       nPalEntries:cardinal;
       offPalEntries:cardinal;
       nSizeLast:cardinal;
     end;
     pEMREOF=pointer to EMREOF;

type EMRLINETO=record
       emr:EMR;
       ptl:POINT;
     end;
     pEMRLINETO=pointer to EMRLINETO;

type EMROFFSETCLIPRGN=record
       emr:EMR;
       ptlOffset:POINT;
     end;
     pEMROFFSETCLIPRGN=pointer to EMROFFSETCLIPRGN;

type EMRFILLPATH=record
       emr:EMR;
       rclBounds:RECT;
     end;
     pEMRFILLPATH=pointer to EMRFILLPATH;

type EMREXCLUDECLIPRECT=record
       emr:EMR;
       rclClip:RECT;
     end;
     pEMREXCLUDECLIPRECT=pointer to EMREXCLUDECLIPRECT;

type EMRSETVIEWPORTORGEX=record
       emr:EMR;
       ptlOrigin:POINT;
     end;
     pEMRSETVIEWPORTORGEX=pointer to EMRSETVIEWPORTORGEX;

type EMRSETVIEWPORTEXTEX=record
       emr:EMR;
       szlExtent:LARGE_INTEGER;
     end;
     pEMRSETVIEWPORTEXTEX=pointer to EMRSETVIEWPORTEXTEX;

type EMRSCALEVIEWPORTEXTEX=record
       emr:EMR;
       xNum:integer;
       xDenom:integer;
       yNum:integer;
       yDenom:integer;
     end;
     pEMRSCALEVIEWPORTEXTEX=pointer to EMRSCALEVIEWPORTEXTEX;

type EMRSETWORLDTRANSFORM=record
       emr:EMR;
       xform:XFORM;
     end;
     pEMRSETWORLDTRANSFORM=pointer to EMRSETWORLDTRANSFORM;

type EMRMODIFYWORLDTRANSFORM=record
       emr:EMR;
       xform:XFORM;
       iMode:cardinal;
     end;
     pEMRMODIFYWORLDTRANSFORM=pointer to EMRMODIFYWORLDTRANSFORM;

type EMRSETPIXELV=record
       emr:EMR;
       ptlPixel:POINT;
       crColor:COLORREF;
     end;
     pEMRSETPIXELV=pointer to EMRSETPIXELV;

type EMREXTFLOODFILL=record
       emr:EMR;
       ptlStart:POINT;
       crColor:COLORREF;
       iMode:cardinal;
     end;
     pEMREXTFLOODFILL=pointer to EMREXTFLOODFILL;

type EMRELLIPSE=record
       emr:EMR;
       rclBox:RECT;
     end;
     pEMRELLIPSE=pointer to EMRELLIPSE;

type EMRROUNDRECT=record
       emr:EMR;
       rclBox:RECT;
       szlCorner:LARGE_INTEGER;
     end;
     pEMRROUNDRECT=pointer to EMRROUNDRECT;

type EMRARC=record
       emr:EMR;
       rclBox:RECT;
       ptlStart:POINT;
       ptlEnd:POINT;
     end;
     pEMRARC=pointer to EMRARC;

type EMRANGLEARC=record
       emr:EMR;
       ptlCenter:POINT;
       nRadius:cardinal;
       eStartAngle:real;
       eSweepAngle:real;
     end;
     pEMRANGLEARC=pointer to EMRANGLEARC;

type EMRPOLYLINE=record
       emr:EMR;
       rclBounds:RECT;
       cptl:cardinal;
       aptl:array[0..0]of POINT;
     end;
     pEMRPOLYLINE=pointer to EMRPOLYLINE;

type EMRPOLYLINE16=record
       emr:EMR;
       rclBounds:RECT;
       cpts:cardinal;
       apts:array[0..0]of POINTS;
     end;
     pEMRPOLYLINE16=pointer to EMRPOLYLINE16;

type EMRPOLYDRAW=record
       emr:EMR;
       rclBounds:RECT;
       cptl:cardinal;
       aptl:array[0..0]of POINT;
       abTypes:array[0..0]of byte;
     end;
     pEMRPOLYDRAW=pointer to EMRPOLYDRAW;

type EMRPOLYDRAW16=record
       emr:EMR;
       rclBounds:RECT;
       cpts:cardinal;
       apts:array[0..0]of POINTS;
       abTypes:array[0..0]of byte;
     end;
     pEMRPOLYDRAW16=pointer to EMRPOLYDRAW16;

type EMRPOLYPOLYLINE=record
       emr:EMR;
       rclBounds:RECT;
       nPolys:cardinal;
       cptl:cardinal;
       aPolyCounts:array[0..0]of cardinal;
       aptl:array[0..0]of POINT;
     end;
     pEMRPOLYPOLYLINE=pointer to EMRPOLYPOLYLINE;

type EMRPOLYPOLYLINE16=record
       emr:EMR;
       rclBounds:RECT;
       nPolys:cardinal;
       cpts:cardinal;
       aPolyCounts:array[0..0]of cardinal;
       apts:array[0..0]of POINTS;
     end;
     pEMRPOLYPOLYLINE16=pointer to EMRPOLYPOLYLINE16;

type EMRINVERTRGN=record
       emr:EMR;
       rclBounds:RECT;
       cbRgnData:cardinal;
       RgnData:array[0..0]of byte;
     end;
     pEMRINVERTRGN=pointer to EMRINVERTRGN;

type EMRFILLRGN=record
       emr:EMR;
       rclBounds:RECT;
       cbRgnData:cardinal;
       ihBrush:cardinal;
       RgnData:array[0..0]of byte;
     end;
     pEMRFILLRGN=pointer to EMRFILLRGN;


type EMRFRAMERGN=record
       emr:EMR;
       rclBounds:RECT;
       cbRgnData:cardinal;
       ihBrush:cardinal;
       szlStroke:LARGE_INTEGER;
       RgnData:array[0..0]of byte;
     end;
     pEMRFRAMERGN=pointer to EMRFRAMERGN;

type EMREXTSELECTCLIPRGN=record
       emr:EMR;
       cbRgnData:cardinal;
       iMode:cardinal;
       RgnData:array[0..0]of byte;
     end;
     pEMREXTSELECTCLIPRGN=pointer to EMREXTSELECTCLIPRGN;

type EMREXTTEXTOUT=record
       emr:EMR;
       rclBounds:RECT;
       iGraphicsMode:cardinal;
       exScale:real;
       eyScale:real;
       emrtext:EMRTEXT;
     end;
     pEMREXTTEXTOUT=pointer to EMREXTTEXTOUT;

type EMRPOLYTEXTOUT=record
       emr:EMR;
       rclBounds:RECT;
       iGraphicsMode:cardinal;
       exScale:real;
       eyScale:real;
       cStrings:integer;
       aemrtext:array[0..0]of EMRTEXT;
     end;
     pEMRPOLYTEXTOUT=pointer to EMRPOLYTEXTOUT;

type EMRBITBLT=record
       emr:EMR;
       rclBounds:RECT;
       xDest:integer;
       yDest:integer;
       cxDest:integer;
       cyDest:integer;
       dwRop:cardinal;
       xSrc:integer;
       ySrc:integer;
       xformSrc:XFORM;
       crBkColorSrc:COLORREF;
       iUsageSrc:cardinal;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
     end;
     pEMRBITBLT=pointer to EMRBITBLT;

type EMRSTRETCHBLT=record
       emr:EMR;
       rclBounds:RECT;
       xDest:integer;
       yDest:integer;
       cxDest:integer;
       cyDest:integer;
       dwRop:cardinal;
       xSrc:integer;
       ySrc:integer;
       xformSrc:XFORM;
       crBkColorSrc:COLORREF;
       iUsageSrc:cardinal;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
       cxSrc:integer;
       cySrc:integer;
     end;
     pEMRSTRETCHBLT=pointer to EMRSTRETCHBLT;

type EMRMASKBLT=record
       emr:EMR;
       rclBounds:RECT;
       xDest:integer;
       yDest:integer;
       cxDest:integer;
       cyDest:integer;
       dwRop:cardinal;
       xSrc:integer;
       ySrc:integer;
       xformSrc:XFORM;
       crBkColorSrc:COLORREF;
       iUsageSrc:cardinal;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
       xMask:integer;
       yMask:integer;
       iUsageMask:cardinal;
       offBmiMask:cardinal;
       cbBmiMask:cardinal;
       offBitsMask:cardinal;
       cbBitsMask:cardinal;
     end;
     pEMRMASKBLT=pointer to EMRMASKBLT;

type EMRPLGBLT=record
       emr:EMR;
       rclBounds:RECT;
       aptlDest:array[0..2]of POINT;
       xSrc:integer;
       ySrc:integer;
       cxSrc:integer;
       cySrc:integer;
       xformSrc:XFORM;
       crBkColorSrc:COLORREF;
       iUsageSrc:cardinal;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
       xMask:integer;
       yMask:integer;
       iUsageMask:cardinal;
       offBmiMask:cardinal;
       cbBmiMask:cardinal;
       offBitsMask:cardinal;
       cbBitsMask:cardinal;
     end;
     pEMRPLGBLT=pointer to EMRPLGBLT;

type EMRSETDIBITSTODEVICE=record
       emr:EMR;
       rclBounds:RECT;
       xDest:integer;
       yDest:integer;
       xSrc:integer;
       ySrc:integer;
       cxSrc:integer;
       cySrc:integer;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
       iUsageSrc:cardinal;
       iStartScan:cardinal;
       cScans:cardinal;
     end;
     pEMRSETDIBITSTODEVICE=pointer to EMRSETDIBITSTODEVICE;

type EMRSTRETCHDIBITS=record
       emr:EMR;
       rclBounds:RECT;
       xDest:integer;
       yDest:integer;
       xSrc:integer;
       ySrc:integer;
       cxSrc:integer;
       cySrc:integer;
       offBmiSrc:cardinal;
       cbBmiSrc:cardinal;
       offBitsSrc:cardinal;
       cbBitsSrc:cardinal;
       iUsageSrc:cardinal;
       dwRop:cardinal;
       cxDest:integer;
       cyDest:integer;
     end;
     pEMRSTRETCHDIBITS=pointer to EMRSTRETCHDIBITS;

type EMREXTCREATEFONTINDIRECT=record
       emr:EMR;
       ihFont:cardinal;
       elfw:EXTLOGFONT;
     end;
     pEMREXTCREATEFONTINDIRECT=pointer to EMREXTCREATEFONTINDIRECT;

type EMRCREATEPALETTE=record
       emr:EMR;
       ihPal:cardinal;
       lgpl:LOGPALETTE;
     end;
     pEMRCREATEPALETTE=pointer to EMRCREATEPALETTE;

type EMRCREATEPEN=record
       emr:EMR;
       ihPen:cardinal;
       lopn:LOGPEN;
     end;
     pEMRCREATEPEN=pointer to EMRCREATEPEN;

type EMREXTCREATEPEN=record
       emr:EMR;
       ihPen:cardinal;
       offBmi:cardinal;
       cbBmi:cardinal;
       offBits:cardinal;
       cbBits:cardinal;
       elp:EXTLOGPEN;
     end;
     pEMREXTCREATEPEN=pointer to EMREXTCREATEPEN;

type EMRCREATEBRUSHINDIRECT=record
       emr:EMR;
       ihBrush:cardinal;
       lb:LOGBRUSH;
     end;
     pEMRCREATEBRUSHINDIRECT=pointer to EMRCREATEBRUSHINDIRECT;

type EMRCREATEMONOBRUSH=record
       emr:EMR;
       ihBrush:cardinal;
       iUsage:cardinal;
       offBmi:cardinal;
       cbBmi:cardinal;
       offBits:cardinal;
       cbBits:cardinal;
     end;
     pEMRCREATEMONOBRUSH=pointer to EMRCREATEMONOBRUSH;

type EMRCREATEDIBPATTERNBRUSHPT=record
       emr:EMR;
       ihBrush:cardinal;
       iUsage:cardinal;
       offBmi:cardinal;
       cbBmi:cardinal;
       offBits:cardinal;
       cbBits:cardinal;
     end;
     pEMRCREATEDIBPATTERNBRUSHPT=pointer to EMRCREATEDIBPATTERNBRUSHPT;

type EMRFORMAT=record
       dSignature:cardinal;
       nVersion:cardinal;
       cbData:cardinal;
       offData:cardinal;
     end;
     pEMRFORMAT=pointer to EMRFORMAT;

type EMRGLSRECORD=record
       emr:EMR;
       cbData:cardinal;
       Data:array[0..0]of byte;
     end;
     pEMRGLSRECORD=pointer to EMRGLSRECORD;

type EMRGLSBOUNDEDRECORD=record
       emr:EMR;
       rclBounds:RECT;
       cbData:cardinal;
       Data:array[0..0]of byte;
     end;
     pEMRGLSBOUNDEDRECORD=pointer to EMRGLSBOUNDEDRECORD;

type EMRPIXELFORMAT=record
       emr:EMR;
       pfd:PIXELFORMATDESCRIPTOR;
     end;
     pEMRPIXELFORMAT=pointer to EMRPIXELFORMAT;

const GDICOMMENT_IDENTIFIER=0x43494447;
const GDICOMMENT_WINDOWS_METAFILE=0x80000001;
const GDICOMMENT_BEGINGROUP=0x00000002;
const GDICOMMENT_ENDGROUP=0x00000003;
const GDICOMMENT_MULTIFORMATS=0x40000004;
const EPS_SIGNATURE=0x46535045;

procedure SwapBuffers(HDC):boolean;

type POINTFLOAT=record
       x:real;
       y:real;
     end;
     pPOINTFLOAT=pointer to POINTFLOAT;

type GLYPHMETRICSFLOAT=record
       gmfBlackBoxX:real;
       gmfBlackBoxY:real;
       gmfptGlyphOrigin:POINTFLOAT;
       gmfCellIncX:real;
       gmfCellIncY:real;
     end;
     pGLYPHMETRICSFLOAT=pointer to GLYPHMETRICSFLOAT;

const WGL_FONT_LINES=0x00000000;
const WGL_FONT_POLYGONS=0x00000001;

type LAYERPLANEDESCRIPTOR=record
       nSize:word;
       nVersion:word;
       dwFlags:cardinal;
       iPixelType:byte;
       cColorBits:byte;
       cRedBits:byte;
       cRedShift:byte;
       cGreenBits:byte;
       cGreenShift:byte;
       cBlueBits:byte;
       cBlueShift:byte;
       cAlphaBits:byte;
       cAlphaShift:byte;
       cAccumBits:byte;
       cAccumRedBits:byte;
       cAccumGreenBits:byte;
       cAccumBlueBits:byte;
       cAccumAlphaBits:byte;
       cDepthBits:byte;
       cStencilBits:byte;
       cAuxBuffers:byte;
       iLayerPlane:byte;
       bReserved:byte;
       crTransparent:COLORREF;
     end;
     pLAYERPLANEDESCRIPTOR=pointer to LAYERPLANEDESCRIPTOR;

const LPD_DOUBLEBUFFER=0x00000001;
const LPD_STEREO=0x00000002;
const LPD_SUPPORT_GDI=0x00000010;
const LPD_SUPPORT_OPENGL=0x00000020;
const LPD_SHARE_DEPTH=0x00000040;
const LPD_SHARE_STENCIL=0x00000080;
const LPD_SHARE_ACCUM=0x00000100;
const LPD_SWAP_EXCHANGE=0x00000200;
const LPD_SWAP_COPY=0x00000400;
const LPD_TRANSPARENT=0x00001000;
const LPD_TYPE_RGBA=0x00000000;
const LPD_TYPE_COLORINDEX=0x00000001;
const WGL_SWAP_MAIN_PLANE=0x00000001;
const WGL_SWAP_OVERLAY1=0x00000002;
const WGL_SWAP_OVERLAY2=0x00000004;
const WGL_SWAP_OVERLAY3=0x00000008;
const WGL_SWAP_OVERLAY4=0x00000010;
const WGL_SWAP_OVERLAY5=0x00000020;
const WGL_SWAP_OVERLAY6=0x00000040;
const WGL_SWAP_OVERLAY7=0x00000080;
const WGL_SWAP_OVERLAY8=0x00000100;
const WGL_SWAP_OVERLAY9=0x00000200;
const WGL_SWAP_OVERLAY10=0x00000400;
const WGL_SWAP_OVERLAY11=0x00000800;
const WGL_SWAP_OVERLAY12=0x00001000;
const WGL_SWAP_OVERLAY13=0x00002000;
const WGL_SWAP_OVERLAY14=0x00004000;
const WGL_SWAP_OVERLAY15=0x00008000;
const WGL_SWAP_UNDERLAY1=0x00010000;
const WGL_SWAP_UNDERLAY2=0x00020000;
const WGL_SWAP_UNDERLAY3=0x00040000;
const WGL_SWAP_UNDERLAY4=0x00080000;
const WGL_SWAP_UNDERLAY5=0x00100000;
const WGL_SWAP_UNDERLAY6=0x00200000;
const WGL_SWAP_UNDERLAY7=0x00400000;
const WGL_SWAP_UNDERLAY8=0x00800000;
const WGL_SWAP_UNDERLAY9=0x01000000;
const WGL_SWAP_UNDERLAY10=0x02000000;
const WGL_SWAP_UNDERLAY11=0x04000000;
const WGL_SWAP_UNDERLAY12=0x08000000;
const WGL_SWAP_UNDERLAY13=0x10000000;
const WGL_SWAP_UNDERLAY14=0x20000000;
const WGL_SWAP_UNDERLAY15=0x40000000;

//========================================================================
//                          ���� � ������� ������ Comdlg32
//========================================================================

from Comdlg32;

type OPENFILENAME=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hInstance:HINSTANCE;
       lpstrFilter:pstr;
       lpstrCustomFilter:pstr;
       nMaxCustFilter:cardinal;
       nFilterIndex:cardinal;
       lpstrFile:pstr;
       nMaxFile:cardinal;
       lpstrFileTitle:pstr;
       nMaxFileTitle:cardinal;
       lpstrInitialDir:pstr;
       lpstrTitle:pstr;
       Flags:cardinal;
       nFileOffset:word;
       nFileExtension:word;
       lpstrDefExt:pstr;
       lCustData:cardinal;
       lpfnHook:pPROC;
       lpTemplateName:pstr;
     end;
     pOPENFILENAME=pointer to OPENFILENAME;

procedure  GetOpenFileName ascii(pOPENFILENAME):boolean;
procedure  GetSaveFileName ascii(pOPENFILENAME):boolean;
procedure  GetFileTitle ascii(pstr; pstr; word):word;
const OFN_READONLY=0X00000001;
const OFN_OVERWRITEPROMPT=0X00000002;
const OFN_HIDEREADONLY=0X00000004;
const OFN_NOCHANGEDIR=0X00000008;
const OFN_SHOWHELP=0X00000010;
const OFN_ENABLEHOOK=0X00000020;
const OFN_ENABLETEMPLATE=0X00000040;
const OFN_ENABLETEMPLATEHANDLE=0X00000080;
const OFN_NOVALIDATE=0X00000100;
const OFN_ALLOWMULTISELECT=0X00000200;
const OFN_EXTENSIONDIFFERENT=0X00000400;
const OFN_PATHMUSTEXIST=0X00000800;
const OFN_FILEMUSTEXIST=0X00001000;
const OFN_CREATEPROMPT=0X00002000;
const OFN_SHAREAWARE=0X00004000;
const OFN_NOREADONLYRETURN=0X00008000;
const OFN_NOTESTFILECREATE=0X00010000;
const OFN_NONETWORKBUTTON=0X00020000;
const OFN_NOLONGNAMES=0X00040000;
const OFN_EXPLORER=0X00080000;
const OFN_NODEREFERENCELINKS=0X00100000;
const OFN_LONGNAMES=0X00200000;
const OFN_SHAREFALLTHROUGH=0X00000002;
const OFN_SHARENOWARN=0X00000001;
const OFN_SHAREWARN=0X00000000;
type OFNOTIFY=record
       hdr:NMHDR;
       lpOFN:pOPENFILENAME;
       pszFile:pstr;
     end;
     pOFNOTIFY=pointer to OFNOTIFY;

const CDN_FIRST=-0X00000259;
const CDN_LAST=-0X000002BB;
const CDN_INITDONE=CDN_FIRST-0;
const CDN_SELCHANGE=CDN_FIRST-1;
const CDN_FOLDERCHANGE=CDN_FIRST-2;
const CDN_SHAREVIOLATION=CDN_FIRST-3;
const CDN_HELP=CDN_FIRST-4;
const CDN_FILEOK=CDN_FIRST-5;
const CDN_TYPECHANGE=CDN_FIRST-6;
const CDM_FIRST=WM_USER+100;
const CDM_LAST=WM_USER+200;
const CDM_GETSPEC=CDM_FIRST+0;
const CDM_GETFOLDERPATH=CDM_FIRST+2;
const CDM_GETFOLDERIDLIST=CDM_FIRST+3;
const CDM_SETCONTROLTEXT=CDM_FIRST+4;
const CDM_HIDECONTROL=CDM_FIRST+5;
const CDM_SETDEFEXT=CDM_FIRST+6;
type CHOOSECOLOR=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hInstance:HWND;
       rgbResult:COLORREF;
       lpCustColors:pointer to COLORREF;
       Flags:cardinal;
       lCustData:cardinal;
       lpfnHook:pPROC;
       lpTemplateName:pstr;
     end;
     pCHOOSECOLOR=pointer to CHOOSECOLOR;

procedure  ChooseColor ascii(pCHOOSECOLOR):boolean;
const CC_RGBINIT=0X00000001;
const CC_FULLOPEN=0X00000002;
const CC_PREVENTFULLOPEN=0X00000004;
const CC_SHOWHELP=0X00000008;
const CC_ENABLEHOOK=0X00000010;
const CC_ENABLETEMPLATE=0X00000020;
const CC_ENABLETEMPLATEHANDLE=0X00000040;
const CC_SOLIDCOLOR=0X00000080;
const CC_ANYCOLOR=0X00000100;
type FINDREPLACE=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hInstance:HINSTANCE;
       Flags:cardinal;
       lpstrFindWhat:pstr;
       lpstrReplaceWith:pstr;
       wFindWhatLen:word;
       wReplaceWithLen:word;
       lCustData:cardinal;
       lpfnHook:pPROC;
       lpTemplateName:pstr;
     end;
     pFINDREPLACE=pointer to FINDREPLACE;

const FR_DOWN=0X00000001;
const FR_WHOLEWORD=0X00000002;
const FR_MATCHCASE=0X00000004;
const FR_FINDNEXT=0X00000008;
const FR_REPLACE=0X00000010;
const FR_REPLACEALL=0X00000020;
const FR_DIALOGTERM=0X00000040;
const FR_SHOWHELP=0X00000080;
const FR_ENABLEHOOK=0X00000100;
const FR_ENABLETEMPLATE=0X00000200;
const FR_NOUPDOWN=0X00000400;
const FR_NOMATCHCASE=0X00000800;
const FR_NOWHOLEWORD=0X00001000;
const FR_ENABLETEMPLATEHANDLE=0X00002000;
const FR_HIDEUPDOWN=0X00004000;
const FR_HIDEMATCHCASE=0X00008000;
const FR_HIDEWHOLEWORD=0X00010000;
procedure  FindText ascii(pFINDREPLACE):HWND;
procedure  ReplaceText ascii(pFINDREPLACE):HWND;
type CHOOSEFONT=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hDC:HDC;
       lpLogFont:pLOGFONT;
       iPointSize:integer;
       Flags:cardinal;
       rgbColors:COLORREF;
       lCustData:cardinal;
       lpfnHook:pPROC;
       lpTemplateName:pstr;
       hInstance:HINSTANCE;
       lpszStyle:pstr;
       nFontType:word;
       ___MISSING_ALIGNMENT__:word;
       nSizeMin:integer;
       nSizeMax:integer;
     end;
     pCHOOSEFONT=pointer to CHOOSEFONT;

procedure  ChooseFont ascii(pCHOOSEFONT):boolean;
const CF_SCREENFONTS=0X00000001;
const CF_PRINTERFONTS=0X00000002;
const CF_BOTH=CF_SCREENFONTS|CF_PRINTERFONTS;
const CF_SHOWHELP=0X00000004;
const CF_ENABLEHOOK=0X00000008;
const CF_ENABLETEMPLATE=0X00000010;
const CF_ENABLETEMPLATEHANDLE=0X00000020;
const CF_INITTOLOGFONTSTRUCT=0X00000040;
const CF_USESTYLE=0X00000080;
const CF_EFFECTS=0X00000100;
const CF_APPLY=0X00000200;
const CF_ANSIONLY=0X00000400;
const CF_SCRIPTSONLY=CF_ANSIONLY;
const CF_NOVECTORFONTS=0X00000800;
const CF_NOOEMFONTS=CF_NOVECTORFONTS;
const CF_NOSIMULATIONS=0X00001000;
const CF_LIMITSIZE=0X00002000;
const CF_FIXEDPITCHONLY=0X00004000;
const CF_WYSIWYG=0X00008000;
const CF_FORCEFONTEXIST=0X00010000;
const CF_SCALABLEONLY=0X00020000;
const CF_TTONLY=0X00040000;
const CF_NOFACESEL=0X00080000;
const CF_NOSTYLESEL=0X00100000;
const CF_NOSIZESEL=0X00200000;
const CF_SELECTSCRIPT=0X00400000;
const CF_NOSCRIPTSEL=0X00800000;
const CF_NOVERTFONTS=0X01000000;
const SIMULATED_FONTTYPE=0X00008000;
const PRINTER_FONTTYPE=0X00004000;
const SCREEN_FONTTYPE=0X00002000;
const BOLD_FONTTYPE=0X00000100;
const ITALIC_FONTTYPE=0X00000200;
const REGULAR_FONTTYPE=0X00000400;
const WM_CHOOSEFONT_GETLOGFONT=WM_USER+1;
const CD_LBSELNOITEMS=-0X00000001;
const CD_LBSELCHANGE=0X00000000;
const CD_LBSELSUB=0X00000001;
const CD_LBSELADD=0X00000002;
type PRINTDLG=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hDevMode:HGLOBAL;
       hDevNames:HGLOBAL;
       hDC:HDC;
       Flags:cardinal;
       nFromPage:word;
       nToPage:word;
       nMinPage:word;
       nMaxPage:word;
       nCopies:word;
       hInstance:HINSTANCE;
       lCustData:cardinal;
       lpfnPrintHook:pPROC;
       lpfnSetupHook:pPROC;
       lpPrintTemplateName:pstr;
       lpSetupTemplateName:pstr;
       hPrintTemplate:HGLOBAL;
       hSetupTemplate:HGLOBAL;
     end;
     pPRINTDLG=pointer to PRINTDLG;

procedure  PrintDlg ascii(pPRINTDLG):boolean;
const PD_ALLPAGES=0X00000000;
const PD_SELECTION=0X00000001;
const PD_PAGENUMS=0X00000002;
const PD_NOSELECTION=0X00000004;
const PD_NOPAGENUMS=0X00000008;
const PD_COLLATE=0X00000010;
const PD_PRINTTOFILE=0X00000020;
const PD_PRINTSETUP=0X00000040;
const PD_NOWARNING=0X00000080;
const PD_RETURNDC=0X00000100;
const PD_RETURNIC=0X00000200;
const PD_RETURNDEFAULT=0X00000400;
const PD_SHOWHELP=0X00000800;
const PD_ENABLEPRINTHOOK=0X00001000;
const PD_ENABLESETUPHOOK=0X00002000;
const PD_ENABLEPRINTTEMPLATE=0X00004000;
const PD_ENABLESETUPTEMPLATE=0X00008000;
const PD_ENABLEPRINTTEMPLATEHANDLE=0X00010000;
const PD_ENABLESETUPTEMPLATEHANDLE=0X00020000;
const PD_USEDEVMODECOPIES=0X00040000;
const PD_USEDEVMODECOPIESANDCOLLATE=0X00040000;
const PD_DISABLEPRINTTOFILE=0X00080000;
const PD_HIDEPRINTTOFILE=0X00100000;
const PD_NONETWORKBUTTON=0X00200000;
type DEVNAMES=record
       wDriverOffset:word;
       wDeviceOffset:word;
       wOutputOffset:word;
       wDefault:word;
     end;
     pDEVNAMES=pointer to DEVNAMES;

const DN_DEFAULTPRN=0X00000001;
procedure  CommDlgExtendedError():cardinal;
const WM_PSD_PAGESETUPDLG=WM_USER;
const WM_PSD_FULLPAGERECT=WM_USER+1;
const WM_PSD_MINMARGINRECT=WM_USER+2;
const WM_PSD_MARGINRECT=WM_USER+3;
const WM_PSD_GREEKTEXTRECT=WM_USER+4;
const WM_PSD_ENVSTAMPRECT=WM_USER+5;
const WM_PSD_YAFULLPAGERECT=WM_USER+6;
type PAGESETUPDLG=record
       lStructSize:cardinal;
       hwndOwner:HWND;
       hDevMode:HGLOBAL;
       hDevNames:HGLOBAL;
       Flags:cardinal;
       ptPaperSize:POINT;
       rtMinMargin:RECT;
       rtMargin:RECT;
       hInstance:HINSTANCE;
       lCustData:cardinal;
       lpfnPageSetupHook:pPROC;
       lpfnPagePaintHook:pPROC;
       lpPageSetupTemplateName:pstr;
       hPageSetupTemplate:HGLOBAL;
     end;
     pPAGESETUPDLG=pointer to PAGESETUPDLG;

procedure  PageSetupDlg ascii(pPAGESETUPDLG):boolean;
const PSD_DEFAULTMINMARGINS=0X00000000;
const PSD_INWININIINTLMEASURE=0X00000000;
const PSD_MINMARGINS=0X00000001;
const PSD_MARGINS=0X00000002;
const PSD_INTHOUSANDTHSOFINCHES=0X00000004;
const PSD_INHUNDREDTHSOFMILLIMETERS=0X00000008;
const PSD_DISABLEMARGINS=0X00000010;
const PSD_DISABLEPRINTER=0X00000020;
const PSD_NOWARNING=0X00000080;
const PSD_DISABLEORIENTATION=0X00000100;
const PSD_RETURNDEFAULT=0X00000400;
const PSD_DISABLEPAPER=0X00000200;
const PSD_SHOWHELP=0X00000800;
const PSD_ENABLEPAGESETUPHOOK=0X00002000;
const PSD_ENABLEPAGESETUPTEMPLATE=0X00008000;
const PSD_ENABLEPAGESETUPTEMPLATEHANDLE=0X00020000;
const PSD_ENABLEPAGEPAINTHOOK=0X00040000;
const PSD_DISABLEPAGEPAINTING=0X00080000;
const PSD_NONETWORKBUTTON=0X00200000;

const CDERR_DIALOGFAILURE=0xFFFF;
const CDERR_GENERALCODES=0x0000;
const CDERR_STRUCTSIZE=0x0001;
const CDERR_INITIALIZATION=0x0002;
const CDERR_NOTEMPLATE=0x0003;
const CDERR_NOHINSTANCE=0x0004;
const CDERR_LOADSTRFAILURE=0x0005;
const CDERR_FINDRESFAILURE=0x0006;
const CDERR_LOADRESFAILURE=0x0007;
const CDERR_LOCKRESFAILURE=0x0008;
const CDERR_MEMALLOCFAILURE=0x0009;
const CDERR_MEMLOCKFAILURE=0x000A;
const CDERR_NOHOOK=0x000B;
const CDERR_REGISTERMSGFAIL=0x000C;

const PDERR_PRINTERCODES=0x1000;
const PDERR_SETUPFAILURE=0x1001;
const PDERR_PARSEFAILURE=0x1002;
const PDERR_RETDEFFAILURE=0x1003;
const PDERR_LOADDRVFAILURE=0x1004;
const PDERR_GETDEVMODEFAIL=0x1005;
const PDERR_INITFAILURE=0x1006;
const PDERR_NODEVICES=0x1007;
const PDERR_NODEFAULTPRN=0x1008;
const PDERR_DNDMMISMATCH=0x1009;
const PDERR_CREATEICFAILURE=0x100A;
const PDERR_PRINTERNOTFOUND=0x100B;
const PDERR_DEFAULTDIFFERENT=0x100C;

const CFERR_CHOOSEFONTCODES=0x2000;
const CFERR_NOFONTS=0x2001;
const CFERR_MAXLESSTHANMIN=0x2002;

const FNERR_FILENAMECODES=0x3000;
const FNERR_SUBCLASSFAILURE=0x3001;
const FNERR_INVALIDFILENAME=0x3002;
const FNERR_BUFFERTOOSMALL=0x3003;

const FRERR_FINDREPLACECODES=0x4000;
const FRERR_BUFFERLENGTHZERO=0x4001;

const CCERR_CHOOSECOLORCODES=0x5000;

//========================================================================
//                          ���� � ������� ������ Comctl32
//========================================================================

from Comctl32;
procedure InitCommonControls();

const ODT_HEADER=0X00000064;
const ODT_TAB=0X00000065;
const ODT_LISTVIEW=0X00000066;
const LVM_FIRST=0X00001000;
const TV_FIRST=0X00001100;
const HDM_FIRST=0X00001200;
const NM_FIRST=-0X00000000;
const NM_LAST=-0X00000063;
const LVN_FIRST=-0X00000064;
const LVN_LAST=-0X000000C7;
const HDN_FIRST=-0X0000012C;
const HDN_LAST=-0X0000018F;
const TVN_FIRST=-0X00000190;
const TVN_LAST=-0X000001F3;
const TTN_FIRST=-0X00000208;
const TTN_LAST=-0X00000225;
const TCN_FIRST=-0X00000226;
const TCN_LAST=-0X00000244;
const TBN_FIRST=-0X000002BC;
const TBN_LAST=-0X000002D0;
const UDN_FIRST=-0X000002D1;
const UDN_LAST=-0X000002E4;
const NM_OUTOFMEMORY=NM_FIRST-1;
const NM_CLICK=NM_FIRST-2;
const NM_DBLCLK=NM_FIRST-3;
const NM_RETURN=NM_FIRST-4;
const NM_RCLICK=NM_FIRST-5;
const NM_RDBLCLK=NM_FIRST-6;
const NM_SETFOCUS=NM_FIRST-7;
const NM_KILLFOCUS=NM_FIRST-8;
const MSGF_COMMCTRL_BEGINDRAG=0X00004200;
const MSGF_COMMCTRL_SIZEHEADER=0X00004201;
const MSGF_COMMCTRL_DRAGSELECT=0X00004202;
const MSGF_COMMCTRL_TOOLBARCUST=0X00004203;
const CLR_NONE=0XFFFFFFFF;
const CLR_DEFAULT=0XFF000000;
const ILC_MASK=0X00000001;
const ILC_COLOR=0X00000000;
const ILC_COLORDDB=0X000000FE;
const ILC_COLOR4=0X00000004;
const ILC_COLOR8=0X00000008;
const ILC_COLOR16=0X00000010;
const ILC_COLOR24=0X00000018;
const ILC_COLOR32=0X00000020;
const ILC_PALETTE=0X00000800;
procedure ImageList_Create(cx:integer; cy:integer; flags:cardinal; cInitial:integer; cGrow:integer):HIMAGELIST;
procedure ImageList_Destroy(himl:HIMAGELIST):boolean;
procedure ImageList_GetImageCount(himl:HIMAGELIST):integer;
procedure ImageList_Add(himl:HIMAGELIST; hbmImage:HBITMAP; hbmMask:HBITMAP):integer;
procedure ImageList_ReplaceIcon(himl:HIMAGELIST; i:integer; hicon:HICON):integer;
procedure ImageList_SetBkColor(himl:HIMAGELIST; clrBk:COLORREF):COLORREF;
procedure ImageList_GetBkColor(himl:HIMAGELIST):COLORREF;
procedure ImageList_SetOverlayImage(himl:HIMAGELIST; iImage:integer; iOverlay:integer):boolean;
const ILD_NORMAL=0X00000000;
const ILD_TRANSPARENT=0X00000001;
const ILD_MASK=0X00000010;
const ILD_IMAGE=0X00000020;
const ILD_BLEND25=0X00000002;
const ILD_BLEND50=0X00000004;
const ILD_OVERLAYMASK=0X00000F00;
const ILD_SELECTED=ILD_BLEND50;
const ILD_FOCUS=ILD_BLEND25;
const ILD_BLEND=ILD_BLEND50;
const CLR_HILIGHT=CLR_DEFAULT;
procedure ImageList_Draw(himl:HIMAGELIST; i:integer; hdcDst:HDC; x:integer; y:integer; fStyle:cardinal):boolean;
procedure ImageList_Replace(himl:HIMAGELIST; i:integer; hbmImage:HBITMAP; hbmMask:HBITMAP):boolean;
procedure ImageList_AddMasked(himl:HIMAGELIST; hbmImage:HBITMAP; crMask:COLORREF):integer;
procedure ImageList_DrawEx(himl:HIMAGELIST; i:integer; hdcDst:HDC; x:integer; y:integer; dx:integer; dy:integer; rgbBk:COLORREF; rgbFg:COLORREF; fStyle:cardinal):boolean;
procedure ImageList_Remove(himl:HIMAGELIST; i:integer):boolean;
procedure ImageList_GetIcon(himl:HIMAGELIST; i:integer; flags:cardinal):HICON;
procedure ImageList_LoadImage ascii(hi:HINSTANCE; lpbmp:pstr; cx:integer; cGrow:integer; crMask:COLORREF; uType:cardinal; uFlags:cardinal):HIMAGELIST;
procedure ImageList_BeginDrag(himlTrack:HIMAGELIST; iTrack:integer; dxHotspot:integer; dyHotspot:integer):boolean;
procedure ImageList_EndDrag();
procedure ImageList_DragEnter(hwndLock:HWND; x:integer; y:integer):boolean;
procedure ImageList_DragLeave(hwndLock:HWND):boolean;
procedure ImageList_DragMove(x:integer; y:integer):boolean;
procedure ImageList_SetDragCursorImage(himlDrag:HIMAGELIST; iDrag:integer; dxHotspot:integer; dyHotspot:integer):boolean;
procedure ImageList_DragShowNolock(fShow:boolean):boolean;
procedure ImageList_GetDragImage(ppt:pPOINT; pptHotspot:pPOINT):HIMAGELIST;
procedure ImageList_Read(pstm:address):HIMAGELIST;
procedure ImageList_Write(himl:HIMAGELIST; pstm:address):boolean;
type IMAGEINFO=record
       hbmImage:HBITMAP;
       hbmMask:HBITMAP;
       Unused1:integer;
       Unused2:integer;
       rcImage:RECT;
     end;
     pIMAGEINFO=pointer to IMAGEINFO;

procedure ImageList_GetIconSize(himl:HIMAGELIST; cx:pINT; cy:pINT):boolean;
procedure ImageList_SetIconSize(himl:HIMAGELIST; cx:integer; cy:integer):boolean;
procedure ImageList_GetImageInfo(himl:HIMAGELIST; i:integer; pImageInfo:pIMAGEINFO):boolean;
procedure ImageList_Merge(himl1:HIMAGELIST; i1:integer; himl2:HIMAGELIST; i2:integer; dx:integer; dy:integer):HIMAGELIST;
const HDS_HORZ=0X00000000;
const HDS_BUTTONS=0X00000002;
const HDS_HIDDEN=0X00000008;
type HD_ITEM=record
       mask:cardinal;
       cxy:integer;
       pszText:pstr;
       hbm:HBITMAP;
       cchTextMax:integer;
       fmt:integer;
       lParam:cardinal;
     end;
     pHD_ITEM=pointer to HD_ITEM;

const HDI_WIDTH=0X00000001;
const HDI_HEIGHT=HDI_WIDTH;
const HDI_TEXT=0X00000002;
const HDI_FORMAT=0X00000004;
const HDI_LPARAM=0X00000008;
const HDI_BITMAP=0X00000010;
const HDF_LEFT=0X00000000;
const HDF_RIGHT=0X00000001;
const HDF_CENTER=0X00000002;
const HDF_JUSTIFYMASK=0X00000003;
const HDF_RTLREADING=0X00000004;
const HDF_OWNERDRAW=0X00008000;
const HDF_STRING=0X00004000;
const HDF_BITMAP=0X00002000;
const HDM_GETITEMCOUNT=HDM_FIRST+0;
const HDM_INSERTITEM=HDM_FIRST+1;
const HDM_DELETEITEM=HDM_FIRST+2;
const HDM_GETITEM=HDM_FIRST+3;
const HDM_SETITEM=HDM_FIRST+4;
type HD_LAYOUT=record
       prc:pointer to RECT;
       pwpos:pointer to WINDOWPOS;
     end;
     pHD_LAYOUT=pointer to HD_LAYOUT;

const HDM_LAYOUT=HDM_FIRST+5;
const HHT_NOWHERE=0X00000001;
const HHT_ONHEADER=0X00000002;
const HHT_ONDIVIDER=0X00000004;
const HHT_ONDIVOPEN=0X00000008;
const HHT_ABOVE=0X00000100;
const HHT_BELOW=0X00000200;
const HHT_TORIGHT=0X00000400;
const HHT_TOLEFT=0X00000800;
type HD_HITTESTINFO=record
       pt:POINT;
       flags:cardinal;
       iItem:integer;
     end;
     pHD_HITTESTINFO=pointer to HD_HITTESTINFO;

const HDM_HITTEST=HDM_FIRST+6;
const HDN_ITEMCHANGING=HDN_FIRST-0;
const HDN_ITEMCHANGED=HDN_FIRST-1;
const HDN_ITEMCLICK=HDN_FIRST-2;
const HDN_ITEMDBLCLICK=HDN_FIRST-3;
const HDN_DIVIDERDBLCLICK=HDN_FIRST-5;
const HDN_BEGINTRACK=HDN_FIRST-6;
const HDN_ENDTRACK=HDN_FIRST-7;
const HDN_TRACK=HDN_FIRST-8;
type HD_NOTIFY=record
       hdr:NMHDR;
       iItem:integer;
       iButton:integer;
       pitem:pointer to HD_ITEM;
     end;
     pHD_NOTIFY=pointer to HD_NOTIFY;

type TBBUTTON=record
       iBitmap:integer;
       idCommand:integer;
       fsState:byte;
       fsStyle:byte;
       bReserved:array[0..1]of byte;
       dwData:cardinal;
       iString:integer;
     end;
     pTBBUTTON=pointer to TBBUTTON;

type COLORMAP=record
       _from:COLORREF;
       _to:COLORREF;
     end;
     pCOLORMAP=pointer to COLORMAP;

procedure CreateToolbarEx(hwnd:HWND; ws:cardinal; wID:cardinal; nBitmaps:integer; hBMInst:HINSTANCE; wBMID:cardinal; lpButtons:pTBBUTTON; iNumButtons:integer; dxButton:integer; dyButton:integer; dxBitmap:integer; dyBitmap:integer; uStructSize:cardinal):HWND;
procedure CreateMappedBitmap(hInstance:HINSTANCE; idBitmap:integer; wFlags:cardinal; lpColorMap:pCOLORMAP; iNumMaps:integer):HBITMAP;
const CMB_MASKED=0X00000002;
const TBSTATE_CHECKED=0X00000001;
const TBSTATE_PRESSED=0X00000002;
const TBSTATE_ENABLED=0X00000004;
const TBSTATE_HIDDEN=0X00000008;
const TBSTATE_INDETERMINATE=0X00000010;
const TBSTATE_WRAP=0X00000020;
const TBSTYLE_BUTTON=0X00000000;
const TBSTYLE_SEP=0X00000001;
const TBSTYLE_CHECK=0X00000002;
const TBSTYLE_GROUP=0X00000004;
const TBSTYLE_CHECKGROUP=TBSTYLE_GROUP|TBSTYLE_CHECK;
const TBSTYLE_TOOLTIPS=0X00000100;
const TBSTYLE_WRAPABLE=0X00000200;
const TBSTYLE_ALTDRAG=0X00000400;
const TB_ENABLEBUTTON=WM_USER+1;
const TB_CHECKBUTTON=WM_USER+2;
const TB_PRESSBUTTON=WM_USER+3;
const TB_HIDEBUTTON=WM_USER+4;
const TB_INDETERMINATE=WM_USER+5;
const TB_ISBUTTONENABLED=WM_USER+9;
const TB_ISBUTTONCHECKED=WM_USER+10;
const TB_ISBUTTONPRESSED=WM_USER+11;
const TB_ISBUTTONHIDDEN=WM_USER+12;
const TB_ISBUTTONINDETERMINATE=WM_USER+13;
const TB_SETSTATE=WM_USER+17;
const TB_GETSTATE=WM_USER+18;
const TB_ADDBITMAP=WM_USER+19;
type TBADDBITMAP=record
       hInst:HINSTANCE;
       nID:cardinal;
     end;
     pTBADDBITMAP=pointer to TBADDBITMAP;

const HINST_COMMCTRL=0X003FFFFF;
const IDB_STD_SMALL_COLOR=0X00000000;
const IDB_STD_LARGE_COLOR=0X00000001;
const IDB_VIEW_SMALL_COLOR=0X00000004;
const IDB_VIEW_LARGE_COLOR=0X00000005;
const STD_CUT=0X00000000;
const STD_COPY=0X00000001;
const STD_PASTE=0X00000002;
const STD_UNDO=0X00000003;
const STD_REDOW=0X00000004;
const STD_DELETE=0X00000005;
const STD_FILENEW=0X00000006;
const STD_FILEOPEN=0X00000007;
const STD_FILESAVE=0X00000008;
const STD_PRINTPRE=0X00000009;
const STD_PROPERTIES=0X0000000A;
const STD_HELP=0X0000000B;
const STD_FIND=0X0000000C;
const STD_REPLACE=0X0000000D;
const STD_PRINT=0X0000000E;
const VIEW_LARGEICONS=0X00000000;
const VIEW_SMALLICONS=0X00000001;
const VIEW_LIST=0X00000002;
const VIEW_DETAILS=0X00000003;
const VIEW_SORTNAME=0X00000004;
const VIEW_SORTSIZE=0X00000005;
const VIEW_SORTDATE=0X00000006;
const VIEW_SORTTYPE=0X00000007;
const VIEW_PARENTFOLDER=0X00000008;
const VIEW_NETCONNECT=0X00000009;
const VIEW_NETDISCONNECT=0X0000000A;
const VIEW_NEWFOLDER=0X0000000B;
const TB_ADDBUTTONS=WM_USER+20;
const TB_INSERTBUTTON=WM_USER+21;
const TB_DELETEBUTTON=WM_USER+22;
const TB_GETBUTTON=WM_USER+23;
const TB_BUTTONCOUNT=WM_USER+24;
const TB_COMMANDTOINDEX=WM_USER+25;
type TBSAVEPARAMS=record
       hkr:HKEY;
       pszSubKey:pstr;
       pszValueName:pstr;
     end;
     pTBSAVEPARAMS=pointer to TBSAVEPARAMS;

const TB_SAVERESTORE=WM_USER+26;
const TB_CUSTOMIZE=WM_USER+27;
const TB_ADDSTRING=WM_USER+28;
const TB_GETITEMRECT=WM_USER+29;
const TB_BUTTONSTRUCTSIZE=WM_USER+30;
const TB_SETBUTTONSIZE=WM_USER+31;
const TB_SETBITMAPSIZE=WM_USER+32;
const TB_AUTOSIZE=WM_USER+33;
const TB_GETTOOLTIPS=WM_USER+35;
const TB_SETTOOLTIPS=WM_USER+36;
const TB_SETPARENT=WM_USER+37;
const TB_SETROWS=WM_USER+39;
const TB_GETROWS=WM_USER+40;
const TB_SETCMDID=WM_USER+42;
const TB_CHANGEBITMAP=WM_USER+43;
const TB_GETBITMAP=WM_USER+44;
const TB_GETBUTTONTEXT=WM_USER+45;
const TB_REPLACEBITMAP=WM_USER+46;
const TB_SETINDENT=WM_USER+47;
type TBREPLACEBITMAP=record
       hInstOld:HINSTANCE;
       nIDOld:cardinal;
       hInstNew:HINSTANCE;
       nIDNew:cardinal;
       nButtons:integer;
     end;
     pTBREPLACEBITMAP=pointer to TBREPLACEBITMAP;

const TBBF_LARGE=0X00000001;
const TB_GETBITMAPFLAGS=WM_USER+41;
const TBN_GETBUTTONINFO=TBN_FIRST-0;
const TBN_BEGINDRAG=TBN_FIRST-1;
const TBN_ENDDRAG=TBN_FIRST-2;
const TBN_BEGINADJUST=TBN_FIRST-3;
const TBN_ENDADJUST=TBN_FIRST-4;
const TBN_RESET=TBN_FIRST-5;
const TBN_QUERYINSERT=TBN_FIRST-6;
const TBN_QUERYDELETE=TBN_FIRST-7;
const TBN_TOOLBARCHANGE=TBN_FIRST-8;
const TBN_CUSTHELP=TBN_FIRST-9;
type TBNOTIFY=record
       hdr:NMHDR;
       iItem:integer;
       tbButton:TBBUTTON;
       cchText:integer;
       pszText:pstr;
     end;
     pTBNOTIFY=pointer to TBNOTIFY;

type TOOLINFO=record
       cbSize:cardinal;
       uFlags:cardinal;
       hwnd:HWND;
       uId:cardinal;
       rect:RECT;
       hinst:HINSTANCE;
       lpszText:pstr;
     end;
     pTOOLINFO=pointer to TOOLINFO;

const TTS_ALWAYSTIP=0X00000001;
const TTS_NOPREFIX=0X00000002;
const TTF_IDISHWND=0X00000001;
const TTF_CENTERTIP=0X00000002;
const TTF_RTLREADING=0X00000004;
const TTF_SUBCLASS=0X00000010;
const TTDT_AUTOMATIC=0X00000000;
const TTDT_RESHOW=0X00000001;
const TTDT_AUTOPOP=0X00000002;
const TTDT_INITIAL=0X00000003;
const TTM_ACTIVATE=WM_USER+1;
const TTM_SETDELAYTIME=WM_USER+3;
const TTM_ADDTOOL=WM_USER+4;
const TTM_DELTOOL=WM_USER+5;
const TTM_NEWTOOLRECT=WM_USER+6;
const TTM_RELAYEVENT=WM_USER+7;
const TTM_GETTOOLINFO=WM_USER+8;
const TTM_SETTOOLINFO=WM_USER+9;
const TTM_HITTEST=WM_USER+10;
const TTM_GETTEXT=WM_USER+11;
const TTM_UPDATETIPTEXT=WM_USER+12;
const TTM_GETTOOLCOUNT=WM_USER+13;
const TTM_ENUMTOOLS=WM_USER+14;
const TTM_GETCURRENTTOOL=WM_USER+15;
const TTM_WINDOWFROMPOINT=WM_USER+16;
type TTHITTESTINFO=record
       hwnd:HWND;
       pt:POINT;
       ti:TOOLINFO;
     end;
     pTTHITTESTINFO=pointer to TTHITTESTINFO;

const TTN_NEEDTEXT=TTN_FIRST-0;
const TTN_SHOW=TTN_FIRST-1;
const TTN_POP=TTN_FIRST-2;
type TOOLTIPTEXT=record
       hdr:NMHDR;
       lpszText:pstr;
       szText:array[0..79]of char;
       hinst:HINSTANCE;
       uFlags:cardinal;
     end;
     pTOOLTIPTEXT=pointer to TOOLTIPTEXT;

const SBARS_SIZEGRIP=0X00000100;
procedure DrawStatusText ascii(hDC:HDC; lprc:pRECT; pszText:pstr; uFlags:cardinal);
procedure CreateStatusWindow ascii(style:integer; lpszText:pstr; hwndParent:HWND; wID:cardinal):HWND;
const SB_SETTEXT=WM_USER+1;
const SB_GETTEXT=WM_USER+2;
const SB_GETTEXTLENGTH=WM_USER+3;
const SB_SETPARTS=WM_USER+4;
const SB_GETPARTS=WM_USER+6;
const SB_GETBORDERS=WM_USER+7;
const SB_SETMINHEIGHT=WM_USER+8;
const SB_SIMPLE=WM_USER+9;
const SB_GETRECT=WM_USER+10;
const SBT_OWNERDRAW=0X00001000;
const SBT_NOBORDERS=0X00000100;
const SBT_POPOUT=0X00000200;
const SBT_RTLREADING=0X00000400;
procedure MenuHelp(uMsg:cardinal; wParam:cardinal; lParam:cardinal; hMainMenu:HMENU; hInst:HINSTANCE; hwndStatus:HWND; lpwIDs:pCARDINAL);
procedure ShowHideMenuCtl(hWnd:HWND; uFlags:cardinal; lpInfo:pINT):boolean;
procedure GetEffectiveClientRect(hWnd:HWND; lprc:pRECT; lpInfo:pINT);
const MINSYSCOMMAND=SC_SIZE;
const TBS_AUTOTICKS=0X00000001;
const TBS_VERT=0X00000002;
const TBS_HORZ=0X00000000;
const TBS_TOP=0X00000004;
const TBS_BOTTOM=0X00000000;
const TBS_LEFT=0X00000004;
const TBS_RIGHT=0X00000000;
const TBS_BOTH=0X00000008;
const TBS_NOTICKS=0X00000010;
const TBS_ENABLESELRANGE=0X00000020;
const TBS_FIXEDLENGTH=0X00000040;
const TBS_NOTHUMB=0X00000080;
const TBM_GETPOS=WM_USER;
const TBM_GETRANGEMIN=WM_USER+1;
const TBM_GETRANGEMAX=WM_USER+2;
const TBM_GETTIC=WM_USER+3;
const TBM_SETTIC=WM_USER+4;
const TBM_SETPOS=WM_USER+5;
const TBM_SETRANGE=WM_USER+6;
const TBM_SETRANGEMIN=WM_USER+7;
const TBM_SETRANGEMAX=WM_USER+8;
const TBM_CLEARTICS=WM_USER+9;
const TBM_SETSEL=WM_USER+10;
const TBM_SETSELSTART=WM_USER+11;
const TBM_SETSELEND=WM_USER+12;
const TBM_GETPTICS=WM_USER+14;
const TBM_GETTICPOS=WM_USER+15;
const TBM_GETNUMTICS=WM_USER+16;
const TBM_GETSELSTART=WM_USER+17;
const TBM_GETSELEND=WM_USER+18;
const TBM_CLEARSEL=WM_USER+19;
const TBM_SETTICFREQ=WM_USER+20;
const TBM_SETPAGESIZE=WM_USER+21;
const TBM_GETPAGESIZE=WM_USER+22;
const TBM_SETLINESIZE=WM_USER+23;
const TBM_GETLINESIZE=WM_USER+24;
const TBM_GETTHUMBRECT=WM_USER+25;
const TBM_GETCHANNELRECT=WM_USER+26;
const TBM_SETTHUMBLENGTH=WM_USER+27;
const TBM_GETTHUMBLENGTH=WM_USER+28;
const TB_LINEUP=0X00000000;
const TB_LINEDOWN=0X00000001;
const TB_PAGEUP=0X00000002;
const TB_PAGEDOWN=0X00000003;
const TB_THUMBPOSITION=0X00000004;
const TB_THUMBTRACK=0X00000005;
const TB_TOP=0X00000006;
const TB_BOTTOM=0X00000007;
const TB_ENDTRACK=0X00000008;
type DRAGLISTINFO=record
       uNotification:cardinal;
       hWnd:HWND;
       ptCursor:POINT;
     end;
     pDRAGLISTINFO=pointer to DRAGLISTINFO;

const DL_BEGINDRAG=WM_USER+133;
const DL_DRAGGING=WM_USER+134;
const DL_DROPPED=WM_USER+135;
const DL_CANCELDRAG=WM_USER+136;
const DL_CURSORSET=0X00000000;
const DL_STOPCURSOR=0X00000001;
const DL_COPYCURSOR=0X00000002;
const DL_MOVECURSOR=0X00000003;
procedure MakeDragList(hLB:HWND):boolean;
procedure DrawInsert(handParent:HWND; hLB:HWND; nItem:integer);
procedure LBItemFromPt(hLB:HWND; pt:POINT; bAutoScroll:boolean):integer;
type UDACCEL=record
       nSec:cardinal;
       nInc:cardinal;
     end;
     pUDACCEL=pointer to UDACCEL;

const UD_MAXVAL=0X00007FFF;
const UD_MINVAL=-0X00007FFF;
const UDS_WRAP=0X00000001;
const UDS_SETBUDDYINT=0X00000002;
const UDS_ALIGNRIGHT=0X00000004;
const UDS_ALIGNLEFT=0X00000008;
const UDS_AUTOBUDDY=0X00000010;
const UDS_ARROWKEYS=0X00000020;
const UDS_HORZ=0X00000040;
const UDS_NOTHOUSANDS=0X00000080;
const UDM_SETRANGE=WM_USER+101;
const UDM_GETRANGE=WM_USER+102;
const UDM_SETPOS=WM_USER+103;
const UDM_GETPOS=WM_USER+104;
const UDM_SETBUDDY=WM_USER+105;
const UDM_GETBUDDY=WM_USER+106;
const UDM_SETACCEL=WM_USER+107;
const UDM_GETACCEL=WM_USER+108;
const UDM_SETBASE=WM_USER+109;
const UDM_GETBASE=WM_USER+110;
procedure CreateUpDownControl(dwStyle:cardinal; x:integer; y:integer; cx:integer; cy:integer; hParent:HWND; nID:integer; hInst:HINSTANCE; hBuddy:HWND; nUpper:integer; nLower:integer; nPos:integer):HWND;
type NM_UPDOWN=record
       hdr:NMHDR;
       iPos:integer;
       iDelta:integer;
     end;
     pNM_UPDOWN=pointer to NM_UPDOWN;

const UDN_DELTAPOS=UDN_FIRST-1;
const PBM_SETRANGE=WM_USER+1;
const PBM_SETPOS=WM_USER+2;
const PBM_DELTAPOS=WM_USER+3;
const PBM_SETSTEP=WM_USER+4;
const PBM_STEPIT=WM_USER+5;
const HOTKEYF_SHIFT=0X00000001;
const HOTKEYF_CONTROL=0X00000002;
const HOTKEYF_ALT=0X00000004;
const HOTKEYF_EXT=0X00000008;
const HKCOMB_NONE=0X00000001;
const HKCOMB_S=0X00000002;
const HKCOMB_C=0X00000004;
const HKCOMB_A=0X00000008;
const HKCOMB_SC=0X00000010;
const HKCOMB_SA=0X00000020;
const HKCOMB_CA=0X00000040;
const HKCOMB_SCA=0X00000080;
const HKM_SETHOTKEY=WM_USER+1;
const HKM_GETHOTKEY=WM_USER+2;
const HKM_SETRULES=WM_USER+3;
const CCS_TOP=0X00000001;
const CCS_NOMOVEY=0X00000002;
const CCS_BOTTOM=0X00000003;
const CCS_NORESIZE=0X00000004;
const CCS_NOPARENTALIGN=0X00000008;
const CCS_ADJUSTABLE=0X00000020;
const CCS_NODIVIDER=0X00000040;
const LVS_ICON=0X00000000;
const LVS_REPORT=0X00000001;
const LVS_SMALLICON=0X00000002;
const LVS_LIST=0X00000003;
const LVS_TYPEMASK=0X00000003;
const LVS_SINGLESEL=0X00000004;
const LVS_SHOWSELALWAYS=0X00000008;
const LVS_SORTASCENDING=0X00000010;
const LVS_SORTDESCENDING=0X00000020;
const LVS_SHAREIMAGELISTS=0X00000040;
const LVS_NOLABELWRAP=0X00000080;
const LVS_AUTOARRANGE=0X00000100;
const LVS_EDITLABELS=0X00000200;
const LVS_OWNERDATA=0X00001000;
const LVS_NOSCROLL=0X00002000;
const LVS_TYPESTYLEMASK=0X0000FC00;
const LVS_ALIGNTOP=0X00000000;
const LVS_ALIGNLEFT=0X00000800;
const LVS_ALIGNMASK=0X00000C00;
const LVS_OWNERDRAWFIXED=0X00000400;
const LVS_NOCOLUMNHEADER=0X00004000;
const LVS_NOSORTHEADER=0X00008000;
const LVM_GETBKCOLOR=LVM_FIRST+0;
const LVM_SETBKCOLOR=LVM_FIRST+1;
const LVM_GETIMAGELIST=LVM_FIRST+2;
const LVSIL_NORMAL=0X00000000;
const LVSIL_SMALL=0X00000001;
const LVSIL_STATE=0X00000002;
const LVM_SETIMAGELIST=LVM_FIRST+3;
const LVM_GETITEMCOUNT=LVM_FIRST+4;
const LVIF_TEXT=0X00000001;
const LVIF_IMAGE=0X00000002;
const LVIF_PARAM=0X00000004;
const LVIF_STATE=0X00000008;
const LVIS_FOCUSED=0X00000001;
const LVIS_SELECTED=0X00000002;
const LVIS_CUT=0X00000004;
const LVIS_DROPHILITED=0X00000008;
const LVIS_OVERLAYMASK=0X00000F00;
const LVIS_STATEIMAGEMASK=0X0000F000;
type LV_ITEM=record
       mask:cardinal;
       iItem:integer;
       iSubItem:integer;
       state:cardinal;
       stateMask:cardinal;
       pszText:pstr;
       cchTextMax:integer;
       iImage:integer;
       lParam:cardinal;
     end;
     pLV_ITEM=pointer to LV_ITEM;

const I_IMAGECALLBACK=-0X00000001;
const LVM_GETITEM=LVM_FIRST+5;
const LVM_SETITEM=LVM_FIRST+6;
const LVM_INSERTITEM=LVM_FIRST+7;
const LVM_DELETEITEM=LVM_FIRST+8;
const LVM_DELETEALLITEMS=LVM_FIRST+9;
const LVM_GETCALLBACKMASK=LVM_FIRST+10;
const LVM_SETCALLBACKMASK=LVM_FIRST+11;
const LVNI_ALL=0X00000000;
const LVNI_FOCUSED=0X00000001;
const LVNI_SELECTED=0X00000002;
const LVNI_CUT=0X00000004;
const LVNI_DROPHILITED=0X00000008;
const LVNI_ABOVE=0X00000100;
const LVNI_BELOW=0X00000200;
const LVNI_TOLEFT=0X00000400;
const LVNI_TORIGHT=0X00000800;
const LVM_GETNEXTITEM=LVM_FIRST+12;
const LVFI_PARAM=0X00000001;
const LVFI_STRING=0X00000002;
const LVFI_PARTIAL=0X00000008;
const LVFI_WRAP=0X00000020;
const LVFI_NEARESTXY=0X00000040;
type LV_FINDINFO=record
       flags:cardinal;
       psz:pstr;
       lParam:cardinal;
       pt:POINT;
       vkDirection:cardinal;
     end;
     pLV_FINDINFO=pointer to LV_FINDINFO;

const LVM_FINDITEM=LVM_FIRST+13;
const LVIR_BOUNDS=0X00000000;
const LVIR_ICON=0X00000001;
const LVIR_LABEL=0X00000002;
const LVIR_SELECTBOUNDS=0X00000003;
const LVM_GETITEMRECT=LVM_FIRST+14;
const LVM_SETITEMPOSITION=LVM_FIRST+15;
const LVM_GETITEMPOSITION=LVM_FIRST+16;
const LVM_GETSTRINGWIDTH=LVM_FIRST+17;
const LVHT_NOWHERE=0X00000001;
const LVHT_ONITEMICON=0X00000002;
const LVHT_ONITEMLABEL=0X00000004;
const LVHT_ONITEMSTATEICON=0X00000008;
const LVHT_ONITEM=LVHT_ONITEMICON|LVHT_ONITEMLABEL|LVHT_ONITEMSTATEICON;
const LVHT_ABOVE=0X00000008;
const LVHT_BELOW=0X00000010;
const LVHT_TORIGHT=0X00000020;
const LVHT_TOLEFT=0X00000040;
type LV_HITTESTINFO=record
       pt:POINT;
       flags:cardinal;
       iItem:integer;
     end;
     pLV_HITTESTINFO=pointer to LV_HITTESTINFO;

const LVM_HITTEST=LVM_FIRST+18;
const LVM_ENSUREVISIBLE=LVM_FIRST+19;
const LVM_SCROLL=LVM_FIRST+20;
const LVM_REDRAWITEMS=LVM_FIRST+21;
const LVA_DEFAULT=0X00000000;
const LVA_ALIGNLEFT=0X00000001;
const LVA_ALIGNTOP=0X00000002;
const LVA_SNAPTOGRID=0X00000005;
const LVM_ARRANGE=LVM_FIRST+22;
const LVM_EDITLABEL=LVM_FIRST+23;
const LVM_GETEDITCONTROL=LVM_FIRST+24;
type LV_COLUMN=record
       mask:cardinal;
       fmt:integer;
       cx:integer;
       pszText:pstr;
       cchTextMax:integer;
       iSubItem:integer;
     end;
     pLV_COLUMN=pointer to LV_COLUMN;

const LVCF_FMT=0X00000001;
const LVCF_WIDTH=0X00000002;
const LVCF_TEXT=0X00000004;
const LVCF_SUBITEM=0X00000008;
const LVCFMT_LEFT=0X00000000;
const LVCFMT_RIGHT=0X00000001;
const LVCFMT_CENTER=0X00000002;
const LVCFMT_JUSTIFYMASK=0X00000003;
const LVM_GETCOLUMN=LVM_FIRST+25;
const LVM_SETCOLUMN=LVM_FIRST+26;
const LVM_INSERTCOLUMN=LVM_FIRST+27;
const LVM_DELETECOLUMN=LVM_FIRST+28;
const LVM_GETCOLUMNWIDTH=LVM_FIRST+29;
const LVSCW_AUTOSIZE=-0X00000001;
const LVSCW_AUTOSIZE_USEHEADER=-0X00000002;
const LVM_SETCOLUMNWIDTH=LVM_FIRST+30;
const LVM_CREATEDRAGIMAGE=LVM_FIRST+33;
const LVM_GETVIEWRECT=LVM_FIRST+34;
const LVM_GETTEXTCOLOR=LVM_FIRST+35;
const LVM_SETTEXTCOLOR=LVM_FIRST+36;
const LVM_GETTEXTBKCOLOR=LVM_FIRST+37;
const LVM_SETTEXTBKCOLOR=LVM_FIRST+38;
const LVM_GETTOPINDEX=LVM_FIRST+39;
const LVM_GETCOUNTPERPAGE=LVM_FIRST+40;
const LVM_GETORIGIN=LVM_FIRST+41;
const LVM_UPDATE=LVM_FIRST+42;
const LVM_SETITEMSTATE=LVM_FIRST+43;
const LVM_GETITEMSTATE=LVM_FIRST+44;
const LVM_GETITEMTEXT=LVM_FIRST+45;
const LVM_SETITEMTEXT=LVM_FIRST+46;
const LVM_SETITEMCOUNT=LVM_FIRST+47;
const LVM_SORTITEMS=LVM_FIRST+48;
const LVM_SETITEMPOSITION32=LVM_FIRST+49;
const LVM_GETSELECTEDCOUNT=LVM_FIRST+50;
const LVM_GETITEMSPACING=LVM_FIRST+51;
const LVM_GETISEARCHSTRING=LVM_FIRST+52;
type NM_LISTVIEW=record
       hdr:NMHDR;
       iItem:integer;
       iSubItem:integer;
       uNewState:cardinal;
       uOldState:cardinal;
       uChanged:cardinal;
       ptAction:POINT;
       lParam:cardinal;
     end;
     pNM_LISTVIEW=pointer to NM_LISTVIEW;

type NM_CACHEHINT=record
       hdr:NMHDR;
       iFrom:integer;
       iTo:integer;
     end;
     pNM_CACHEHINT=pointer to NM_CACHEHINT;

type NM_FINDITEM=record
       hdr:NMHDR;
       iStart:integer;
       lvfi:LV_FINDINFO;
     end;
     pNM_FINDITEM=pointer to NM_FINDITEM;

const LVN_ITEMCHANGING=LVN_FIRST-0;
const LVN_ITEMCHANGED=LVN_FIRST-1;
const LVN_INSERTITEM=LVN_FIRST-2;
const LVN_DELETEITEM=LVN_FIRST-3;
const LVN_DELETEALLITEMS=LVN_FIRST-4;
const LVN_BEGINLABELEDIT=LVN_FIRST-5;
const LVN_ENDLABELEDIT=LVN_FIRST-6;
const LVN_COLUMNCLICK=LVN_FIRST-8;
const LVN_BEGINDRAG=LVN_FIRST-9;
const LVN_BEGINRDRAG=LVN_FIRST-11;
const LVN_ODCACHEHINT=LVN_FIRST-13;
const LVN_ODFINDITEM=LVN_FIRST-52;
const LVN_GETDISPINFO=LVN_FIRST-50;
const LVN_SETDISPINFO=LVN_FIRST-51;
const LVIF_DI_SETITEM=0X00001000;
type LV_DISPINFO=record
       hdr:NMHDR;
       item:LV_ITEM;
     end;
     pLV_DISPINFO=pointer to LV_DISPINFO;

const LVN_KEYDOWN=LVN_FIRST-55;
type LV_KEYDOWN=record
       hdr:NMHDR;
       wVKey:word;
       flags:cardinal;
     end;
     pLV_KEYDOWN=pointer to LV_KEYDOWN;

const TVS_HASBUTTONS=0X00000001;
const TVS_HASLINES=0X00000002;
const TVS_LINESATROOT=0X00000004;
const TVS_EDITLABELS=0X00000008;
const TVS_DISABLEDRAGDROP=0X00000010;
const TVS_SHOWSELALWAYS=0X00000020;
const TVIF_TEXT=0X00000001;
const TVIF_IMAGE=0X00000002;
const TVIF_PARAM=0X00000004;
const TVIF_STATE=0X00000008;
const TVIF_HANDLE=0X00000010;
const TVIF_SELECTEDIMAGE=0X00000020;
const TVIF_CHILDREN=0X00000040;
const TVIS_FOCUSED=0X00000001;
const TVIS_SELECTED=0X00000002;
const TVIS_CUT=0X00000004;
const TVIS_DROPHILITED=0X00000008;
const TVIS_BOLD=0X00000010;
const TVIS_EXPANDED=0X00000020;
const TVIS_EXPANDEDONCE=0X00000040;
const TVIS_OVERLAYMASK=0X00000F00;
const TVIS_STATEIMAGEMASK=0X0000F000;
const TVIS_USERMASK=0X0000F000;
const I_CHILDRENCALLBACK=-0X00000001;
type TV_ITEM=record
       mask:cardinal;
       hItem:HTREEITEM;
       state:cardinal;
       stateMask:cardinal;
       pszText:pstr;
       cchTextMax:integer;
       iImage:integer;
       iSelectedImage:integer;
       cChildren:integer;
       lParam:cardinal;
     end;
     pTV_ITEM=pointer to TV_ITEM;

const TVI_ROOT=0XFFFF0000;
const TVI_FIRST=0XFFFF0001;
const TVI_LAST=0XFFFF0002;
const TVI_SORT=0XFFFF0003;
type TV_INSERTSTRUCT=record
       hParent:HTREEITEM;
       hInsertAfter:HTREEITEM;
       item:TV_ITEM;
     end;
     pTV_INSERTSTRUCT=pointer to TV_INSERTSTRUCT;

const TVM_INSERTITEM=TV_FIRST+0;
const TVM_DELETEITEM=TV_FIRST+1;
const TVM_EXPAND=TV_FIRST+2;
const TVE_COLLAPSE=0X00000001;
const TVE_EXPAND=0X00000002;
const TVE_TOGGLE=0X00000003;
const TVE_COLLAPSERESET=0X00008000;
const TVM_GETITEMRECT=TV_FIRST+4;
const TVM_GETCOUNT=TV_FIRST+5;
const TVM_GETINDENT=TV_FIRST+6;
const TVM_SETINDENT=TV_FIRST+7;
const TVM_GETIMAGELIST=TV_FIRST+8;
const TVSIL_NORMAL=0X00000000;
const TVSIL_STATE=0X00000002;
const TVM_SETIMAGELIST=TV_FIRST+9;
const TVM_GETNEXTITEM=TV_FIRST+10;
const TVGN_ROOT=0X00000000;
const TVGN_NEXT=0X00000001;
const TVGN_PREVIOUS=0X00000002;
const TVGN_PARENT=0X00000003;
const TVGN_CHILD=0X00000004;
const TVGN_FIRSTVISIBLE=0X00000005;
const TVGN_NEXTVISIBLE=0X00000006;
const TVGN_PREVIOUSVISIBLE=0X00000007;
const TVGN_DROPHILITE=0X00000008;
const TVGN_CARET=0X00000009;
const TVM_SELECTITEM=TV_FIRST+11;
const TVM_GETITEM=TV_FIRST+12;
const TVM_SETITEM=TV_FIRST+13;
const TVM_EDITLABEL=TV_FIRST+14;
const TVM_GETEDITCONTROL=TV_FIRST+15;
const TVM_GETVISIBLECOUNT=TV_FIRST+16;
const TVM_HITTEST=TV_FIRST+17;
type TV_HITTESTINFO=record
       pt:POINT;
       flags:cardinal;
       hItem:HTREEITEM;
     end;
     pTV_HITTESTINFO=pointer to TV_HITTESTINFO;

const TVHT_NOWHERE=0X00000001;
const TVHT_ONITEMICON=0X00000002;
const TVHT_ONITEMLABEL=0X00000004;
const TVHT_ONITEMINDENT=0X00000008;
const TVHT_ONITEMBUTTON=0X00000010;
const TVHT_ONITEMRIGHT=0X00000020;
const TVHT_ONITEMSTATEICON=0X00000040;
const TVHT_ONITEM=TVHT_ONITEMICON|TVHT_ONITEMLABEL|TVHT_ONITEMSTATEICON;
const TVHT_ABOVE=0X00000100;
const TVHT_BELOW=0X00000200;
const TVHT_TORIGHT=0X00000400;
const TVHT_TOLEFT=0X00000800;
const TVM_CREATEDRAGIMAGE=TV_FIRST+18;
const TVM_SORTCHILDREN=TV_FIRST+19;
const TVM_ENSUREVISIBLE=TV_FIRST+20;
const TVM_SORTCHILDRENCB=TV_FIRST+21;
const TVM_ENDEDITLABELNOW=TV_FIRST+22;
const TVM_GETISEARCHSTRING=TV_FIRST+23;
type TV_SORTCB=record
       hParent:HTREEITEM;
       lpfnCompare:pPROC;
       lParam:cardinal;
     end;
     pTV_SORTCB=pointer to TV_SORTCB;

type NM_TREEVIEW=record
       hdr:NMHDR;
       action:cardinal;
       itemOld:TV_ITEM;
       itemNew:TV_ITEM;
       ptDrag:POINT;
     end;
     pNM_TREEVIEW=pointer to NM_TREEVIEW;

const TVN_SELCHANGING=TVN_FIRST-1;
const TVN_SELCHANGED=TVN_FIRST-2;
const TVC_UNKNOWN=0X00000000;
const TVC_BYMOUSE=0X00000001;
const TVC_BYKEYBOARD=0X00000002;
const TVN_GETDISPINFO=TVN_FIRST-3;
const TVN_SETDISPINFO=TVN_FIRST-4;
const TVIF_DI_SETITEM=0X00001000;
type TV_DISPINFO=record
       hdr:NMHDR;
       item:TV_ITEM;
     end;
     pTV_DISPINFO=pointer to TV_DISPINFO;

const TVN_ITEMEXPANDING=TVN_FIRST-5;
const TVN_ITEMEXPANDED=TVN_FIRST-6;
const TVN_BEGINDRAG=TVN_FIRST-7;
const TVN_BEGINRDRAG=TVN_FIRST-8;
const TVN_DELETEITEM=TVN_FIRST-9;
const TVN_BEGINLABELEDIT=TVN_FIRST-10;
const TVN_ENDLABELEDIT=TVN_FIRST-11;
const TVN_KEYDOWN=TVN_FIRST-12;
type TV_KEYDOWN=record
       hdr:NMHDR;
       wVKey:word;
       flags:cardinal;
     end;
     pTV_KEYDOWN=pointer to TV_KEYDOWN;

const TCS_FORCEICONLEFT=0X00000010;
const TCS_FORCELABELLEFT=0X00000020;
const TCS_TABS=0X00000000;
const TCS_BUTTONS=0X00000100;
const TCS_SINGLELINE=0X00000000;
const TCS_MULTILINE=0X00000200;
const TCS_RIGHTJUSTIFY=0X00000000;
const TCS_FIXEDWIDTH=0X00000400;
const TCS_RAGGEDRIGHT=0X00000800;
const TCS_FOCUSONBUTTONDOWN=0X00001000;
const TCS_OWNERDRAWFIXED=0X00002000;
const TCS_TOOLTIPS=0X00004000;
const TCS_FOCUSNEVER=0X00008000;
const TCM_FIRST=0X00001300;
const TCM_GETIMAGELIST=TCM_FIRST+2;
const TCM_SETIMAGELIST=TCM_FIRST+3;
const TCM_GETITEMCOUNT=TCM_FIRST+4;
const TCIF_TEXT=0X00000001;
const TCIF_IMAGE=0X00000002;
const TCIF_RTLREADING=0X00000004;
const TCIF_PARAM=0X00000008;
type TC_ITEMHEADER=record
       mask:cardinal;
       lpReserved1:cardinal;
       lpReserved2:cardinal;
       pszText:pstr;
       cchTextMax:integer;
       iImage:integer;
     end;
     pTC_ITEMHEADER=pointer to TC_ITEMHEADER;

type TC_ITEM=record
       mask:cardinal;
       lpReserved1:cardinal;
       lpReserved2:cardinal;
       pszText:pstr;
       cchTextMax:integer;
       iImage:integer;
       lParam:cardinal;
     end;
     pTC_ITEM=pointer to TC_ITEM;

const TCM_GETITEM=TCM_FIRST+5;
const TCM_SETITEM=TCM_FIRST+6;
const TCM_INSERTITEM=TCM_FIRST+7;
const TCM_DELETEITEM=TCM_FIRST+8;
const TCM_DELETEALLITEMS=TCM_FIRST+9;
const TCM_GETITEMRECT=TCM_FIRST+10;
const TCM_GETCURSEL=TCM_FIRST+11;
const TCM_SETCURSEL=TCM_FIRST+12;
const TCHT_NOWHERE=0X00000001;
const TCHT_ONITEMICON=0X00000002;
const TCHT_ONITEMLABEL=0X00000004;
const TCHT_ONITEM=TCHT_ONITEMICON|TCHT_ONITEMLABEL;
type TC_HITTESTINFO=record
       pt:POINT;
       flags:cardinal;
     end;
     pTC_HITTESTINFO=pointer to TC_HITTESTINFO;

const TCM_HITTEST=TCM_FIRST+13;
const TCM_SETITEMEXTRA=TCM_FIRST+14;
const TCM_ADJUSTRECT=TCM_FIRST+40;
const TCM_SETITEMSIZE=TCM_FIRST+41;
const TCM_REMOVEIMAGE=TCM_FIRST+42;
const TCM_SETPADDING=TCM_FIRST+43;
const TCM_GETROWCOUNT=TCM_FIRST+44;
const TCM_GETTOOLTIPS=TCM_FIRST+45;
const TCM_SETTOOLTIPS=TCM_FIRST+46;
const TCM_GETCURFOCUS=TCM_FIRST+47;
const TCM_SETCURFOCUS=TCM_FIRST+48;
const TCN_KEYDOWN=TCN_FIRST-0;
type TC_KEYDOWN=record
       hdr:NMHDR;
       wVKey:word;
       flags:cardinal;
     end;
     pTC_KEYDOWN=pointer to TC_KEYDOWN;

const TCN_SELCHANGE=TCN_FIRST-1;
const TCN_SELCHANGING=TCN_FIRST-2;
const ACS_CENTER=0X00000001;
const ACS_TRANSPARENT=0X00000002;
const ACS_AUTOPLAY=0X00000004;
const ACM_OPEN=WM_USER+100;
const ACM_PLAY=WM_USER+101;
const ACM_STOP=WM_USER+102;
const ACN_START=0X00000001;
const ACN_STOP=0X00000002;

const MAXPROPPAGES=100;

const PSP_DEFAULT=0x0000;
const PSP_DLGINDIRECT=0x0001;
const PSP_USEHICON=0x0002;
const PSP_USEICONID=0x0004;
const PSP_USETITLE=0x0008;
const PSP_RTLREADING=0x0010;
const PSP_HASHELP=0x0020;
const PSP_USEREFPARENT=0x0040;
const PSP_USECALLBACK=0x0080;
const PSPCB_RELEASE=1;
const PSPCB_CREATE=2;

type PROPSHEETPAGE=record
  dwSize:cardinal;
  dwFlags:cardinal;
  hInstance:cardinal;
  pszTemplate:pstr;
  pszIcon:pstr;
  pszTitle:pstr;
  pfnDlgProc:address;
  lParam:cardinal;
  pfnCallback:address;
  pcRefParent:pCARDINAL;
end;
type pPROPSHEETPAGE=pointer to PROPSHEETPAGE;

const PSH_DEFAULT=0x0000;
const PSH_PROPTITLE=0x0001;
const PSH_USEHICON=0x0002;
const PSH_USEICONID=0x0004;
const PSH_PROPSHEETPAGE=0x0008;
const PSH_WIZARD=0x0020;
const PSH_USEPSTARTPAGE=0x0040;
const PSH_NOAPPLYNOW=0x0080;
const PSH_USECALLBACK=0x0100;
const PSH_HASHELP=0x0200;
const PSH_MODELESS=0x0400;
const PSH_RTLREADING=0x0800;

type PROPSHEETHEADER=record
  dwSize:cardinal;
  dwFlags:cardinal;
  hwndParent:HWND;
  hInstance:cardinal;
  pszIcon:pstr;
  pszCaption:pstr;
  nPages:cardinal;
  nStartPage:cardinal;
  ppsp:pPROPSHEETPAGE;
  pfnCallback:address;
end;
type pPROPSHEETHEADER=pointer to PROPSHEETHEADER;

const PSCB_INITIALIZED=1;
const PSCB_PRECREATE=2;

procedure CreatePropertySheetPage ascii(pPROPSHEETPAGE):HANDLE;
procedure DestroyPropertySheetPage(HANDLE):boolean;
procedure PropertySheet ascii(pPROPSHEETHEADER):integer;

type PSHNOTIFY=record
    hdr:NMHDR;
    lParam:cardinal;
end;
type pPSHNOTIFY=pointer to PSHNOTIFY;

const PSN_FIRST=-200;
const PSN_LAST=-299;

const PSN_SETACTIVE=PSN_FIRST-0;
const PSN_KILLACTIVE=PSN_FIRST-1;
const PSN_APPLY=PSN_FIRST-2;
const PSN_RESET=PSN_FIRST-3;
const PSN_HELP=PSN_FIRST-5;
const PSN_WIZBACK=PSN_FIRST-6;
const PSN_WIZNEXT=PSN_FIRST-7;
const PSN_WIZFINISH=PSN_FIRST-8;
const PSN_QUERYCANCEL=PSN_FIRST-9;

const PSNRET_NOERROR=0;
const PSNRET_INVALID=1;
const PSNRET_INVALID_NOCHANGEPAGE=2;

const PSM_SETCURSEL=WM_USER +101;
const PSM_REMOVEPAGE=WM_USER + 102;
const PSM_ADDPAGE=WM_USER + 103;
const PSM_CHANGED=WM_USER + 104;
const PSM_RESTARTWINDOWS=WM_USER + 105;
const PSM_REBOOTSYSTEM=WM_USER + 106;
const PSM_CANCELTOCLOSE=WM_USER + 107;
const PSM_QUERYSIBLINGS=WM_USER + 108;
const PSM_UNCHANGED=WM_USER + 109;
const PSM_APPLY=WM_USER + 110;
const PSM_SETTITLE=WM_USER + 111;
const PSM_SETWIZBUTTONS=WM_USER + 112;
const PSWIZB_BACK=0x00000001;
const PSWIZB_NEXT=0x00000002;
const PSWIZB_FINISH=0x00000004;
const PSWIZB_DISABLEDFINISH=0x00000008;
const PSM_PRESSBUTTON=WM_USER + 113;
const PSBTN_BACK=0;
const PSBTN_NEXT=1;
const PSBTN_FINISH=2;
const PSBTN_OK=3;
const PSBTN_APPLYNOW=4;
const PSBTN_CANCEL=5;
const PSBTN_HELP=6;
const PSBTN_MAX=6;
const PSM_SETCURSELID=WM_USER + 114;
const PSM_SETFINISHTEXT=WM_USER + 115;
const PSM_GETTABCONTROL=WM_USER + 116;
const PSM_ISDIALOGMESSAGE=WM_USER + 117;
const PSM_GETCURRENTPAGEHWND=WM_USER + 118;
const ID_PSRESTARTWINDOWS=0x2;
const ID_PSREBOOTSYSTEM=ID_PSRESTARTWINDOWS | 0x1;

const WIZ_CXDLG=276;
const WIZ_CYDLG=140;
const WIZ_CXBMP=80 ;
const WIZ_BODYX=92;
const WIZ_BODYCX=184;
const PROP_SM_CXDLG=212;
const PROP_SM_CYDLG=188;
const PROP_MED_CXDLG=227;
const PROP_MED_CYDLG=215;
const PROP_LG_CXDLG=252;
const PROP_LG_CYDLG=218;

//========================================================================
//                          ���� � ������� ������ Riched20
//========================================================================

from Riched20;

const cchTextLimitDefault=0X00007FFF;

const EM_CANPASTE=WM_USER+50;
const EM_DISPLAYBAND=WM_USER+51;
const EM_EXGETSEL=WM_USER+52;
const EM_EXLIMITTEXT=WM_USER+53;
const EM_EXLINEFROMCHAR=WM_USER+54;
const EM_EXSETSEL=WM_USER+55;
const EM_FINDTEXT=WM_USER+56;
const EM_FORMATRANGE=WM_USER+57;
const EM_GETCHARFORMAT=WM_USER+58;
const EM_GETEVENTMASK=WM_USER+59;
const EM_GETOLEINTERFACE=WM_USER+60;
const EM_GETPARAFORMAT=WM_USER+61;
const EM_GETSELTEXT=WM_USER+62;
const EM_HIDESELECTION=WM_USER+63;
const EM_PASTESPECIAL=WM_USER+64;
const EM_REQUESTRESIZE=WM_USER+65;
const EM_SELECTIONTYPE=WM_USER+66;
const EM_SETBKGNDCOLOR=WM_USER+67;
const EM_SETCHARFORMAT=WM_USER+68;
const EM_SETEVENTMASK=WM_USER+69;
const EM_SETOLECALLBACK=WM_USER+70;
const EM_SETPARAFORMAT=WM_USER+71;
const EM_SETTARGETDEVICE=WM_USER+72;
const EM_STREAMIN=WM_USER+73;
const EM_STREAMOUT=WM_USER+74;
const EM_GETTEXTRANGE=WM_USER+75;
const EM_FINDWORDBREAK=WM_USER+76;
const EM_SETOPTIONS=WM_USER+77;
const EM_GETOPTIONS=WM_USER+78;
const EM_FINDTEXTEX=WM_USER+79;
const EM_GETWORDBREAKPROCEX=WM_USER+80;
const EM_SETWORDBREAKPROCEX=WM_USER+81;
const EM_SETUNDOLIMIT=WM_USER+82;
const EM_REDO=WM_USER+84;
const EM_CANREDO=WM_USER+85;
const EM_GETUNDONAME=WM_USER+86;
const EM_GETREDONAME=WM_USER+87;
const EM_STOPGROUPTYPING=WM_USER+88;
const EM_SETTEXTMODE=WM_USER+89;
const EM_GETTEXTMODE=WM_USER+90;
const TM_PLAINTEXT=0X00000001;
const TM_RICHTEXT=0X00000002;
const TM_SINGLELEVELUNDO=0X00000004;
const TM_MULTILEVELUNDO=0X00000008;
const TM_SINGLECODEPAGE=0X00000010;
const TM_MULTICODEPAGE=0X00000020;
const EM_AUTOURLDETECT=WM_USER+91;
const EM_GETAUTOURLDETECT=WM_USER+92;
const EM_SETPALETTE=WM_USER+93;
const EM_GETTEXTEX=WM_USER+94;
const EM_GETTEXTLENGTHEX=WM_USER+95;
const EM_SETPUNCTUATION=WM_USER+100;
const EM_GETPUNCTUATION=WM_USER+101;
const EM_SETWORDWRAPMODE=WM_USER+102;
const EM_GETWORDWRAPMODE=WM_USER+103;
const EM_SETIMECOLOR=WM_USER+104;
const EM_GETIMECOLOR=WM_USER+105;
const EM_SETIMEOPTIONS=WM_USER+106;
const EM_GETIMEOPTIONS=WM_USER+107;
const EM_CONVPOSITION=WM_USER+108;
const EM_SETLANGOPTIONS=WM_USER+120;
const EM_GETLANGOPTIONS=WM_USER+121;
const EM_GETIMECOMPMODE=WM_USER+122;
const IMF_AUTOKEYBOARD=0X00000001;
const IMF_AUTOFONT=0X00000002;
const IMF_IMECANCELCOMPLETE=0X00000004;
const IMF_IMEALWAYSSENDNOTIFY=0X00000008;
const ICM_NOTOPEN=0X00000000;
const ICM_LEVEL3=0X00000001;
const ICM_LEVEL2=0X00000002;
const ICM_LEVEL2_5=0X00000003;
const ICM_LEVEL2_SUI=0X00000004;
const EN_MSGFILTER=0X00000700;
const EN_REQUESTRESIZE=0X00000701;
const EN_SELCHANGE=0X00000702;
const EN_DROPFILES=0X00000703;
const EN_PROTECTED=0X00000704;
const EN_CORRECTTEXT=0X00000705;
const EN_STOPNOUNDO=0X00000706;
const EN_IMECHANGE=0X00000707;
const EN_SAVECLIPBOARD=0X00000708;
const EN_OLEOPFAILED=0X00000709;
const EN_OBJECTPOSITIONS=0X0000070A;
const EN_LINK=0X0000070B;
const EN_DRAGDROPDONE=0X0000070C;
const ENM_NONE=0X00000000;
const ENM_CHANGE=0X00000001;
const ENM_UPDATE=0X00000002;
const ENM_SCROLL=0X00000004;
const ENM_KEYEVENTS=0X00010000;
const ENM_MOUSEEVENTS=0X00020000;
const ENM_REQUESTRESIZE=0X00040000;
const ENM_SELCHANGE=0X00080000;
const ENM_DROPFILES=0X00100000;
const ENM_PROTECTED=0X00200000;
const ENM_CORRECTTEXT=0X00400000;
const ENM_SCROLLEVENTS=0X00000008;
const ENM_DRAGDROPDONE=0X00000010;
const ENM_IMECHANGE=0X00800000;
const ENM_LANGCHANGE=0X01000000;
const ENM_OBJECTPOSITIONS=0X02000000;
const ENM_LINK=0X04000000;
const ES_SAVESEL=0X00008000;
const ES_SUNKEN=0X00004000;
const ES_DISABLENOSCROLL=0X00002000;
const ES_SELECTIONBAR=0X01000000;
const ES_NOOLEDRAGDROP=0X00000008;
const ES_EX_NOCALLOLEINIT=0X01000000;
const ES_VERTICAL=0X00400000;
const ES_NOIME=0X00080000;
const ES_SELFIME=0X00040000;
const ECO_AUTOWORDSELECTION=0X00000001;
const ECO_AUTOVSCROLL=0X00000040;
const ECO_AUTOHSCROLL=0X00000080;
const ECO_NOHIDESEL=0X00000100;
const ECO_READONLY=0X00000800;
const ECO_WANTRETURN=0X00001000;
const ECO_SAVESEL=0X00008000;
const ECO_SELECTIONBAR=0X01000000;
const ECO_VERTICAL=0X00400000;
const ECOOP_SET=0X00000001;
const ECOOP_OR=0X00000002;
const ECOOP_AND=0X00000003;
const ECOOP_XOR=0X00000004;
const WB_CLASSIFY=0X00000003;
const WB_MOVEWORDLEFT=0X00000004;
const WB_MOVEWORDRIGHT=0X00000005;
const WB_LEFTBREAK=0X00000006;
const WB_RIGHTBREAK=0X00000007;
const WB_MOVEWORDPREV=0X00000004;
const WB_MOVEWORDNEXT=0X00000005;
const WB_PREVBREAK=0X00000006;
const WB_NEXTBREAK=0X00000007;
const PC_FOLLOWING=0X00000001;
const PC_LEADING=0X00000002;
const PC_OVERFLOW=0X00000003;
const PC_DELIMITER=0X00000004;
const WBF_WORDWRAP=0X00000010;
const WBF_WORDBREAK=0X00000020;
const WBF_OVERFLOW=0X00000040;
const WBF_LEVEL1=0X00000080;
const WBF_LEVEL2=0X00000100;
const WBF_CUSTOM=0X00000200;
const IMF_FORCENONE=0X00000001;
const IMF_FORCEENABLE=0X00000002;
const IMF_FORCEDISABLE=0X00000004;
const IMF_CLOSESTATUSWINDOW=0X00000008;
const IMF_VERTICAL=0X00000020;
const IMF_FORCEACTIVE=0X00000040;
const IMF_FORCEINACTIVE=0X00000080;
const IMF_FORCEREMEMBER=0X00000100;
const IMF_MULTIPLEEDIT=0X00000400;
const WBF_CLASS=0X0000000F;
const WBF_ISWHITE=0X00000010;
const WBF_BREAKLINE=0X00000020;
const WBF_BREAKAFTER=0X00000040;
type CHARFORMAT=record
       cbSize:cardinal;
       dwMask:cardinal;
       dwEffects:cardinal;
       yHeight:integer;
       yOffset:integer;
       crTextColor:COLORREF;
       bCharSet:byte;
       bPitchAndFamily:byte;
       szFaceName:array[0..LF_FACESIZE-1]of char;
       dummy:word; //������������ �� ������� dword
     end;
     pCHARFORMAT=pointer to CHARFORMAT;

const CFM_BOLD=0X00000001;
const CFM_ITALIC=0X00000002;
const CFM_UNDERLINE=0X00000004;
const CFM_STRIKEOUT=0X00000008;
const CFM_PROTECTED=0X00000010;
const CFM_LINK=0X00000020;
const CFM_SIZE=0X80000000;
const CFM_COLOR=0X40000000;
const CFM_FACE=0X20000000;
const CFM_OFFSET=0X10000000;
const CFM_CHARSET=0X08000000;
const CFE_BOLD=0X00000001;
const CFE_ITALIC=0X00000002;
const CFE_UNDERLINE=0X00000004;
const CFE_STRIKEOUT=0X00000008;
const CFE_PROTECTED=0X00000010;
const CFE_LINK=0X00000020;
const CFE_AUTOCOLOR=0X40000000;
const yHeightCharPtsMost=0X00000666;
const SCF_SELECTION=0X00000001;
const SCF_WORD=0X00000002;
const SCF_DEFAULT=0X00000000;
const SCF_ALL=0X00000004;
const SCF_USEUIRULES=0X00000008;
type CHARRANGE=record
       cpMin:integer;
       cpMax:integer;
     end;
     pCHARRANGE=pointer to CHARRANGE;

type TEXTRANGE=record
       chrg:CHARRANGE;
       lpstrText:pstr;
     end;
     pTEXTRANGE=pointer to TEXTRANGE;

type EDITSTREAM=record
       dwCookie:cardinal;
       dwError:cardinal;
       pfnCallback:address;
     end;
     pEDITSTREAM=pointer to EDITSTREAM;

const SF_TEXT=0X00000001;
const SF_RTF=0X00000002;
const SF_RTFNOOBJS=0X00000003;
const SF_TEXTIZED=0X00000004;
const SF_UNICODE=0X00000010;
const SFF_SELECTION=0X00008000;
const SFF_PLAINRTF=0X00004000;
type FINDTEXT=record
       chrg:CHARRANGE;
       lpstrText:pstr;
     end;
     pFINDTEXT=pointer to FINDTEXT;

type FINDTEXTEX=record
       chrg:CHARRANGE;
       lpstrText:pstr;
       chrgText:CHARRANGE;
     end;
     pFINDTEXTEX=pointer to FINDTEXTEX;

type FORMATRANGE=record
       hdc:HDC;
       hdcTarget:HDC;
       rc:RECT;
       rcPage:RECT;
       chrg:CHARRANGE;
     end;
     pFORMATRANGE=pointer to FORMATRANGE;

const MAX_TAB_STOPS=0X00000020;
const lDefaultTab=0X000002D0;
type PARAFORMAT=record
       cbSize:cardinal;
       dwMask:cardinal;
       wNumbering:word;
       wReserved:word;
       dxStartIndent:integer;
       dxRightIndent:integer;
       dxOffset:integer;
       wAlignment:word;
       cTabCount:word;
       rgxTabs:array[0..MAX_TAB_STOPS-1]of integer;
     end;
     pPARAFORMAT=pointer to PARAFORMAT;

const PFM_STARTINDENT=0X00000001;
const PFM_RIGHTINDENT=0X00000002;
const PFM_OFFSET=0X00000004;
const PFM_ALIGNMENT=0X00000008;
const PFM_TABSTOPS=0X00000010;
const PFM_NUMBERING=0X00000020;
const PFM_OFFSETINDENT=0X80000000;
const PFN_BULLET=0X00000001;
const PFA_LEFT=0X00000001;
const PFA_RIGHT=0X00000002;
const PFA_CENTER=0X00000003;
type CHARFORMAT2=record
       cbSize:cardinal;
       dwMask:cardinal;
       dwEffects:cardinal;
       yHeight:integer;
       yOffset:integer;
       crTextColor:COLORREF;
       bCharSet:byte;
       bPitchAndFamily:byte;
       szFaceName:array[0..LF_FACESIZE-1]of char;
       wWeight:word;
       sSpacing:word;
       crBackColor:COLORREF;
       lcid:cardinal;
       dwReserved:cardinal;
       sStyle:word;
       wKerning:word;
       bUnderlineType:byte;
       bAnimation:byte;
       bRevAuthor:byte;
     end;
     pCHARFORMAT2=pointer to CHARFORMAT2;

const CFM_EFFECTS=CFM_BOLD|CFM_ITALIC|CFM_UNDERLINE|CFM_COLOR|CFM_STRIKEOUT|CFE_PROTECTED|CFM_LINK;
const CFM_ALL=CFM_EFFECTS|CFM_SIZE|CFM_FACE|CFM_OFFSET|CFM_CHARSET;
const PFM_ALL=PFM_STARTINDENT|PFM_RIGHTINDENT|PFM_OFFSET|PFM_ALIGNMENT|PFM_TABSTOPS|PFM_NUMBERING|PFM_OFFSETINDENT;
const CFM_SMALLCAPS=0X00000040;
const CFM_ALLCAPS=0X00000080;
const CFM_HIDDEN=0X00000100;
const CFM_OUTLINE=0X00000200;
const CFM_SHADOW=0X00000400;
const CFM_EMBOSS=0X00000800;
const CFM_IMPRINT=0X00001000;
const CFM_DISABLED=0X00002000;
const CFM_REVISED=0X00004000;
const CFM_BACKCOLOR=0X04000000;
const CFM_LCID=0X02000000;
const CFM_UNDERLINETYPE=0X00800000;
const CFM_WEIGHT=0X00400000;
const CFM_SPACING=0X00200000;
const CFM_KERNING=0X00100000;
const CFM_STYLE=0X00080000;
const CFM_ANIMATION=0X00040000;
const CFM_REVAUTHOR=0X00008000;
const CFE_SUBSCRIPT=0X00010000;
const CFE_SUPERSCRIPT=0X00020000;
const CFM_SUBSCRIPT=CFE_SUBSCRIPT|CFE_SUPERSCRIPT;
const CFM_SUPERSCRIPT=CFM_SUBSCRIPT;
const CFM_EFFECTS2=CFM_EFFECTS|CFM_DISABLED|CFM_SMALLCAPS|CFM_ALLCAPS|CFM_HIDDEN|CFM_OUTLINE|CFM_SHADOW|CFM_EMBOSS|CFM_IMPRINT|CFM_DISABLED|CFM_REVISED|CFM_SUBSCRIPT|CFM_SUPERSCRIPT|CFM_BACKCOLOR;
                                                                                                                                                                                                    const CFM_ALL2=CFM_ALL|CFM_EFFECTS2|CFM_BACKCOLOR|CFM_LCID|CFM_UNDERLINETYPE|CFM_WEIGHT|CFM_REVAUTHOR|CFM_SPACING|CFM_KERNING|CFM_STYLE|CFM_ANIMATION;
const CFE_SMALLCAPS=CFM_SMALLCAPS;
const CFE_ALLCAPS=CFM_ALLCAPS;
const CFE_HIDDEN=CFM_HIDDEN;
const CFE_OUTLINE=CFM_OUTLINE;
const CFE_SHADOW=CFM_SHADOW;
const CFE_EMBOSS=CFM_EMBOSS;
const CFE_IMPRINT=CFM_IMPRINT;
const CFE_DISABLED=CFM_DISABLED;
const CFE_REVISED=CFM_REVISED;
const CFE_AUTOBACKCOLOR=CFM_BACKCOLOR;
const CFU_CF1UNDERLINE=0X000000FF;
const CFU_INVERT=0X000000FE;
const CFU_UNDERLINEDOTTED=0X00000004;
const CFU_UNDERLINEDOUBLE=0X00000003;
const CFU_UNDERLINEWORD=0X00000002;
const CFU_UNDERLINE=0X00000001;
const CFU_UNDERLINENONE=0X00000000;
type PARAFORMAT2=record
       cbSize:cardinal;
       dwMask:cardinal;
       wNumbering:word;
       wReserved:word;
       dxStartIndent:integer;
       dxRightIndent:integer;
       dxOffset:integer;
       wAlignment:word;
       cTabCount:word;
       rgxTabs:array[0..MAX_TAB_STOPS-1]of integer;
       dySpaceBefore:integer;
       dySpaceAfter:integer;
       dyLineSpacing:integer;
       sStyle:word;
       bLineSpacingRule:byte;
       bCRC:byte;
       wShadingWeight:word;
       wShadingStyle:word;
       wNumberingStart:word;
       wNumberingStyle:word;
       wNumberingTab:word;
       wBorderSpace:word;
       wBorderWidth:word;
       wBorders:word;
     end;
     pPARAFORMAT2=pointer to PARAFORMAT2;

const PFM_SPACEBEFORE=0X00000040;
const PFM_SPACEAFTER=0X00000080;
const PFM_LINESPACING=0X00000100;
const PFM_STYLE=0X00000400;
const PFM_BORDER=0X00000800;
const PFM_SHADING=0X00001000;
const PFM_NUMBERINGSTYLE=0X00002000;
const PFM_NUMBERINGTAB=0X00004000;
const PFM_NUMBERINGSTART=0X00008000;
const PFM_RTLPARA=0X00010000;
const PFM_KEEP=0X00020000;
const PFM_KEEPNEXT=0X00040000;
const PFM_PAGEBREAKBEFORE=0X00080000;
const PFM_NOLINENUMBER=0X00100000;
const PFM_NOWIDOWCONTROL=0X00200000;
const PFM_DONOTHYPHEN=0X00400000;
const PFM_SIDEBYSIDE=0X00800000;
const PFM_TABLE=0XC0000000;
const PFM_EFFECTS=PFM_RTLPARA|PFM_KEEP|PFM_KEEPNEXT|PFM_TABLE|PFM_PAGEBREAKBEFORE|PFM_NOLINENUMBER|PFM_NOWIDOWCONTROL|PFM_DONOTHYPHEN|PFM_SIDEBYSIDE|PFM_TABLE;
                                                                                                                                                               const PFM_ALL2=PFM_ALL|PFM_EFFECTS|PFM_SPACEBEFORE|PFM_SPACEAFTER|PFM_LINESPACING|PFM_STYLE|PFM_SHADING|PFM_BORDER|PFM_NUMBERINGTAB|PFM_NUMBERINGSTART|PFM_NUMBERINGSTYLE;
                                                                                                                                                                                                                                                                                                                                         const PFE_RTLPARA=0X00000001;
const PFE_KEEP=0X00000002;
const PFE_KEEPNEXT=0X00000004;
const PFE_PAGEBREAKBEFORE=0X00000008;
const PFE_NOLINENUMBER=0X00000010;
const PFE_NOWIDOWCONTROL=0X00000020;
const PFE_DONOTHYPHEN=0X00000040;
const PFE_SIDEBYSIDE=0X00000080;
const PFE_TABLEROW=0X0000C000;
const PFE_TABLECELLEND=0X00008000;
const PFE_TABLECELL=0X00004000;
const PFA_JUSTIFY=0X00000004;

type REQRESIZE=record
       nmhdr:NMHDR;
       rc:RECT;
     end;
     pREQRESIZE=pointer to REQRESIZE;

type SELCHANGE=record
       nmhdr:NMHDR;
       chrg:CHARRANGE;
       seltyp:word;
     end;
     pSELCHANGE=pointer to SELCHANGE;

const SEL_EMPTY=0X00000000;
const SEL_TEXT=0X00000001;
const SEL_OBJECT=0X00000002;
const SEL_MULTICHAR=0X00000004;
const SEL_MULTIOBJECT=0X00000008;
const GCM_RIGHTMOUSEDROP=0X00008000;
type ENDROPFILES=record
       nmhdr:NMHDR;
       hDrop:HANDLE;
       cp:integer;
       fProtected:boolean;
     end;
     pENDROPFILES=pointer to ENDROPFILES;

type ENPROTECTED=record
       nmhdr:NMHDR;
       msg:cardinal;
       wParam:cardinal;
       lParam:cardinal;
       chrg:CHARRANGE;
     end;
     pENPROTECTED=pointer to ENPROTECTED;

type ENSAVECLIPBOARD=record
       nmhdr:NMHDR;
       cObjectCount:integer;
       cch:integer;
     end;
     pENSAVECLIPBOARD=pointer to ENSAVECLIPBOARD;

type ENOLEOPFAILED=record
       nmhdr:NMHDR;
       iob:integer;
       lOper:integer;
       hr:cardinal;
     end;
     pENOLEOPFAILED=pointer to ENOLEOPFAILED;

const OLEOP_DOVERB=0X00000001;
type OBJECTPOSITIONS=record
       nmhdr:NMHDR;
       cObjectCount:integer;
       pcpPositions:pointer to integer;
     end;
     pOBJECTPOSITIONS=pointer to OBJECTPOSITIONS;

type ENLINK=record
       nmhdr:NMHDR;
       msg:cardinal;
       wParam:cardinal;
       lParam:cardinal;
       chrg:CHARRANGE;
     end;
     pENLINK=pointer to ENLINK;

type ENCORRECTTEXT=record
       nmhdr:NMHDR;
       chrg:CHARRANGE;
       seltyp:word;
     end;
     pENCORRECTTEXT=pointer to ENCORRECTTEXT;

type PUNCTUATION=record
       iSize:cardinal;
       szPunctuation:pstr;
     end;
     pPUNCTUATION=pointer to PUNCTUATION;

type COMPCOLOR=record
       crText:COLORREF;
       crBackground:COLORREF;
       dwEffects:cardinal;
     end;
     pCOMPCOLOR=pointer to COMPCOLOR;

type REPASTESPECIAL=record
       dwAspect:cardinal;
       dwParam:cardinal;
     end;
     pREPASTESPECIAL=pointer to REPASTESPECIAL;

const UID_UNKNOWN=0X00000000;
const UID_TYPING=0X00000001;
const UID_DELETE=0X00000002;
const UID_DRAGDROP=0X00000003;
const UID_CUT=0X00000004;
const UID_PASTE=0X00000005;
const GT_DEFAULT=0X00000000;
const GT_USECRLF=0X00000001;
type GETTEXTEX=record
       cb:cardinal;
       flags:cardinal;
       codepage:cardinal;
       lpDefaultChar:pstr;
       lpUsedDefChar:pBOOL;
     end;
     pGETTEXTEX=pointer to GETTEXTEX;

const GTL_DEFAULT=0X00000000;
const GTL_USECRLF=0X00000001;
const GTL_PRECISE=0X00000002;
const GTL_CLOSE=0X00000004;
const GTL_NUMCHARS=0X00000008;
const GTL_NUMBYTES=0X00000010;
type GETTEXTLENGTHEX=record
       flags:cardinal;
       codepage:cardinal;
     end;
     pGETTEXTLENGTHEX=pointer to GETTEXTLENGTHEX;

//========================================================================
//                          ���� � ������� ������ Ddeml
//========================================================================

from User32;

type HSZPAIR=record
       hszSvc:HSZ;
       hszTopic:HSZ;
     end;
     pHSZPAIR=pointer to HSZPAIR;

type CONVCONTEXT=record
       cb:cardinal;
       wFlags:cardinal;
       wCountryID:cardinal;
       iCodePage:integer;
       dwLangID:cardinal;
       dwSecurity:cardinal;
       qos:cardinal;
     end;
     pCONVCONTEXT=pointer to CONVCONTEXT;

type CONVINFO=record
       cb:cardinal;
       hUser:cardinal;
       hConvPartner:HCONV;
       hszSvcPartner:HSZ;
       hszServiceReq:HSZ;
       hszTopic:HSZ;
       hszItem:HSZ;
       wFmt:cardinal;
       wType:cardinal;
       wStatus:cardinal;
       wConvst:cardinal;
       wLastError:cardinal;
       hConvList:HCONVLIST;
       ConvCtxt:CONVCONTEXT;
       hwnd:HWND;
       hwndPartner:HWND;
     end;
     pCONVINFO=pointer to CONVINFO;

const XST_NULL=0X00000000;
const XST_INCOMPLETE=0X00000001;
const XST_CONNECTED=0X00000002;
const XST_INIT1=0X00000003;
const XST_INIT2=0X00000004;
const XST_REQSENT=0X00000005;
const XST_DATARCVD=0X00000006;
const XST_POKESENT=0X00000007;
const XST_POKEACKRCVD=0X00000008;
const XST_EXECSENT=0X00000009;
const XST_EXECACKRCVD=0X0000000A;
const XST_ADVSENT=0X0000000B;
const XST_UNADVSENT=0X0000000C;
const XST_ADVACKRCVD=0X0000000D;
const XST_UNADVACKRCVD=0X0000000E;
const XST_ADVDATASENT=0X0000000F;
const XST_ADVDATAACKRCVD=0X00000010;
const CADV_LATEACK=0X0000FFFF;
const ST_CONNECTED=0X00000001;
const ST_ADVISE=0X00000002;
const ST_ISLOCAL=0X00000004;
const ST_BLOCKED=0X00000008;
const ST_CLIENT=0X00000010;
const ST_TERMINATED=0X00000020;
const ST_INLIST=0X00000040;
const ST_BLOCKNEXT=0X00000080;
const ST_ISSELF=0X00000100;
const DDE_FACK=0X00008000;
const DDE_FBUSY=0X00004000;
const DDE_FDEFERUPD=0X00004000;
const DDE_FACKREQ=0X00008000;
const DDE_FRELEASE=0X00002000;
const DDE_FREQUESTED=0X00001000;
const DDE_FAPPSTATUS=0X000000FF;
const DDE_FNOTPROCESSED=0X00000000;
const MSGF_DDEMGR=0X00008001;
const CP_WINANSI=0X000003EC;
const CP_WINUNICODE=0X000004B0;
const CP_WINNEUTRAL=CP_WINANSI;
const XTYPF_NOBLOCK=0X00000002;
const XTYPF_NODATA=0X00000004;
const XTYPF_ACKREQ=0X00000008;
const XCLASS_MASK=0X0000FC00;
const XCLASS_BOOL=0X00001000;
const XCLASS_DATA=0X00002000;
const XCLASS_FLAGS=0X00004000;
const XCLASS_NOTIFICATION=0X00008000;
const XTYP_MASK=0X000000F0;
const XTYP_SHIFT=0X00000004;
const TIMEOUT_ASYNC=0XFFFFFFFF;
const QID_SYNC=0XFFFFFFFF;
const CBR_BLOCK=0XFFFFFFFF;

const XTYP_ERROR=0x0000 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;
const XTYP_ADVDATA=0x0010 | XCLASS_FLAGS;
const XTYP_ADVREQ=0x0020 | XCLASS_DATA | XTYPF_NOBLOCK;
const XTYP_ADVSTART=0x0030 | XCLASS_BOOL;
const XTYP_ADVSTOP=0x0040 | XCLASS_NOTIFICATION;
const XTYP_EXECUTE=0x0050 | XCLASS_FLAGS;
const XTYP_CONNECT=0x0060 | XCLASS_BOOL | XTYPF_NOBLOCK;
const XTYP_CONNECT_CONFIRM=0x0070 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;
const XTYP_XACT_COMPLETE=0x0080 | XCLASS_NOTIFICATION;
const XTYP_POKE=0x0090 | XCLASS_FLAGS;
const XTYP_REGISTER=0x00A0 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;
const XTYP_REQUEST=0x00B0 | XCLASS_DATA;
const XTYP_DISCONNECT=0x00C0 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;
const XTYP_UNREGISTER=0x00D0 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;
const XTYP_WILDCONNECT=0x00E0 | XCLASS_DATA | XTYPF_NOBLOCK;
const XTYP_MONITOR=0x00F0 | XCLASS_NOTIFICATION | XTYPF_NOBLOCK;

procedure DdeInitialize ascii(pidInst:pCARDINAL; pfnCallback:address; afCmd:cardinal; ulRes:cardinal):cardinal;

const CBF_FAIL_SELFCONNECTIONS=0X00001000;
const CBF_FAIL_CONNECTIONS=0X00002000;
const CBF_FAIL_ADVISES=0X00004000;
const CBF_FAIL_EXECUTES=0X00008000;
const CBF_FAIL_POKES=0X00010000;
const CBF_FAIL_REQUESTS=0X00020000;
const CBF_FAIL_ALLSVRXACTIONS=0X0003F000;
const CBF_SKIP_CONNECT_CONFIRMS=0X00040000;
const CBF_SKIP_REGISTRATIONS=0X00080000;
const CBF_SKIP_UNREGISTRATIONS=0X00100000;
const CBF_SKIP_DISCONNECTS=0X00200000;
const CBF_SKIP_ALLNOTIFICATIONS=0X003C0000;
const APPCMD_CLIENTONLY=0X00000010;
const APPCMD_FILTERINITS=0X00000020;
const APPCMD_MASK=0X00000FF0;
const APPCLASS_STANDARD=0X00000000;
const APPCLASS_MASK=0X0000000F;

procedure DdeUninitialize(idInst:cardinal):boolean;
procedure DdeConnectList(idInst:cardinal; hszService:HSZ; hszTopic:HSZ; hConvList:HCONVLIST; pCC:pCONVCONTEXT):HCONVLIST;
procedure DdeQueryNextServer(hConvList:HCONVLIST; hConvPrev:HCONV):HCONV;
procedure DdeDisconnectList(hConvList:HCONVLIST):boolean;
procedure DdeConnect(idInst:cardinal; hszService:HSZ; hszTopic:HSZ; pCC:pCONVCONTEXT):HCONV;
procedure DdeDisconnect(hConv:HCONV):boolean;
procedure DdeReconnect(hConv:HCONV):HCONV;
procedure DdeQueryConvInfo(hConv:HCONV; idTransaction:cardinal; pConvInfo:pCONVINFO):cardinal;
procedure DdeSetUserHandle(hConv:HCONV; id:cardinal; hUser:cardinal):boolean;
procedure DdeAbandonTransaction(idInst:cardinal; hConv:HCONV; idTransaction:cardinal):boolean;
procedure DdePostAdvise(idInst:cardinal; hszTopic:HSZ; hszItem:HSZ):boolean;
procedure DdeEnableCallback(idInst:cardinal; hConv:HCONV; wCmd:cardinal):boolean;
procedure DdeImpersonateClient(hConv:HCONV):boolean;

const EC_ENABLEALL=0X00000000;
const EC_ENABLEONE=ST_BLOCKNEXT;
const EC_DISABLE=ST_BLOCKED;
const EC_QUERYWAITING=0X00000002;

procedure DdeNameService(idInst:cardinal; hsz1:HSZ; hsz2:HSZ; afCmd:cardinal):HDDEDATA;

const DNS_REGISTER=0X00000001;
const DNS_UNREGISTER=0X00000002;
const DNS_FILTERON=0X00000004;
const DNS_FILTEROFF=0X00000008;

procedure DdeClientTransaction(pData:pBYTE; cbData:cardinal; hConv:HCONV; hszItem:HSZ; wFmt:cardinal; wType:cardinal; dwTimeout:cardinal; pdwResult:pCARDINAL):HDDEDATA;
procedure DdeCreateDataHandle(idInst:cardinal; pSrc:pBYTE; cb:cardinal; cbOff:cardinal; hszItem:HSZ; wFmt:cardinal; afCmd:cardinal):HDDEDATA;
procedure DdeAddData(hData:HDDEDATA; pSrc:pBYTE; cb:cardinal; cbOff:cardinal):HDDEDATA;
procedure DdeGetData(hData:HDDEDATA; pDst:pBYTE; cbMax:cardinal; cbOff:cardinal):cardinal;
procedure DdeAccessData(hData:HDDEDATA; pcbDataSize:pCARDINAL):pBYTE;
procedure DdeUnaccessData(hData:HDDEDATA):boolean;
procedure DdeFreeDataHandle(hData:HDDEDATA):boolean;

const HDATA_APPOWNED=0X00000001;

procedure DdeGetLastError(idInst:cardinal):cardinal;

const DMLERR_NO_ERROR=0X00000000;
const DMLERR_FIRST=0X00004000;
const DMLERR_ADVACKTIMEOUT=0X00004000;
const DMLERR_BUSY=0X00004001;
const DMLERR_DATAACKTIMEOUT=0X00004002;
const DMLERR_DLL_NOT_INITIALIZED=0X00004003;
const DMLERR_DLL_USAGE=0X00004004;
const DMLERR_EXECACKTIMEOUT=0X00004005;
const DMLERR_INVALIDPARAMETER=0X00004006;
const DMLERR_LOW_MEMORY=0X00004007;
const DMLERR_MEMORY_ERROR=0X00004008;
const DMLERR_NOTPROCESSED=0X00004009;
const DMLERR_NO_CONV_ESTABLISHED=0X0000400A;
const DMLERR_POKEACKTIMEOUT=0X0000400B;
const DMLERR_POSTMSG_FAILED=0X0000400C;
const DMLERR_REENTRANCY=0X0000400D;
const DMLERR_SERVER_DIED=0X0000400E;
const DMLERR_SYS_ERROR=0X0000400F;
const DMLERR_UNADVACKTIMEOUT=0X00004010;
const DMLERR_UNFOUND_QUEUE_ID=0X00004011;
const DMLERR_LAST=0X00004011;

procedure DdeCreateStringHandle ascii(idInst:cardinal; psz:pstr; iCodePage:integer):HSZ;
procedure DdeQueryString ascii(idInst:cardinal; hsz:HSZ; psz:pstr; cchMax:cardinal; iCodePage:integer):cardinal;
procedure DdeFreeStringHandle(idInst:cardinal; hsz:HSZ):boolean;
procedure DdeKeepStringHandle(idInst:cardinal; hsz:HSZ):boolean;
procedure DdeCmpStringHandles(hsz1:HSZ; hsz2:HSZ):integer;

type DDEML_MSG_HOOK_DATA=record
       uiLo:cardinal;
       uiHi:cardinal;
       cbData:cardinal;
       Data:array[0..7]of cardinal;
     end;
     pDDEML_MSG_HOOK_DATA=pointer to DDEML_MSG_HOOK_DATA;

type MONMSGSTRUCT=record
       cb:cardinal;
       hwndTo:HWND;
       dwTime:cardinal;
       hTask:HANDLE;
       wMsg:cardinal;
       wParam:cardinal;
       lParam:cardinal;
       dmhd:DDEML_MSG_HOOK_DATA;
     end;
     pMONMSGSTRUCT=pointer to MONMSGSTRUCT;

type MONCBSTRUCT=record
       cb:cardinal;
       dwTime:cardinal;
       hTask:HANDLE;
       dwRet:cardinal;
       wType:cardinal;
       wFmt:cardinal;
       hConv:HCONV;
       hsz1:HSZ;
       hsz2:HSZ;
       hData:HDDEDATA;
       dwData1:cardinal;
       dwData2:cardinal;
       cc:CONVCONTEXT;
       cbData:cardinal;
       Data:array[0..7]of cardinal;
     end;
     pMONCBSTRUCT=pointer to MONCBSTRUCT;

type MONHSZSTRUCT=record
       cb:cardinal;
       fsAction:boolean;
       dwTime:cardinal;
       hsz:HSZ;
       hTask:HANDLE;
       str:array[0..0]of char;
     end;
     pMONHSZSTRUCT=pointer to MONHSZSTRUCT;

const MH_CREATE=0X00000001;
const MH_KEEP=0X00000002;
const MH_DELETE=0X00000003;
const MH_CLEANUP=0X00000004;

type MONERRSTRUCT=record
       cb:cardinal;
       wLastError:cardinal;
       dwTime:cardinal;
       hTask:HANDLE;
     end;
     pMONERRSTRUCT=pointer to MONERRSTRUCT;

type MONLINKSTRUCT=record
       cb:cardinal;
       dwTime:cardinal;
       hTask:HANDLE;
       fEstablished:boolean;
       fNoData:boolean;
       hszSvc:HSZ;
       hszTopic:HSZ;
       hszItem:HSZ;
       wFmt:cardinal;
       fServer:boolean;
       hConvServer:HCONV;
       hConvClient:HCONV;
     end;
     pMONLINKSTRUCT=pointer to MONLINKSTRUCT;

type MONCONVSTRUCT=record
       cb:cardinal;
       fConnect:boolean;
       dwTime:cardinal;
       hTask:HANDLE;
       hszSvc:HSZ;
       hszTopic:HSZ;
       hConvClient:HCONV;
       hConvServer:HCONV;
     end;
     pMONCONVSTRUCT=pointer to MONCONVSTRUCT;

const MAX_MONITORS=0X00000004;
const APPCLASS_MONITOR=0X00000001;
const MF_HSZ_INFO=0X01000000;
const MF_SENDMSGS=0X02000000;
const MF_POSTMSGS=0X04000000;
const MF_CALLBACKS=0X08000000;
const MF_ERRORS=0X10000000;
const MF_LINKS=0X20000000;
const MF_CONV=0X40000000;

//========================================================================
//                          ���� � ������� ������ ODBC (Microsoft SQL Server)
//========================================================================

from Odbc32;

const SQL_MAX_OPTION_STRING_LENGTH= 256;
const SQL_STILL_EXECUTING=  2;
const SQL_NEED_DATA  =  99;
const SQL_DATE=         9;
const SQL_TIME=   10;
const SQL_TIMESTAMP=                 11;
const SQL_LONGVARCHAR=               -1;
const SQL_BINARY=                    -2;
const SQL_VARBINARY=             -3;
const SQL_LONGVARBINARY=         -4;
const SQL_BIGINT=                -5;
const SQL_TINYINT=               -6;
const SQL_BIT=                   -7;
const SQL_INTERVAL_YEAR=         -80;
const SQL_INTERVAL_MONTH=        -81;
const SQL_INTERVAL_YEAR_TO_MONTH=-82;
const SQL_INTERVAL_DAY=          -83;
const SQL_INTERVAL_HOUR=         -84;
const SQL_INTERVAL_MINUTE=       -85;
const SQL_INTERVAL_SECOND=       -86;
const SQL_INTERVAL_DAY_TO_HOUR=  -87;
const SQL_INTERVAL_DAY_TO_MINUTE=-88;
const SQL_INTERVAL_DAY_TO_SECOND=-89;
const SQL_INTERVAL_HOUR_TO_MINUTE=             -90;
const SQL_INTERVAL_HOUR_TO_SECOND =            -91;
const SQL_INTERVAL_MINUTE_TO_SECOND=           -92;
const SQL_UNICODE=               -95;
const SQL_UNICODE_VARCHAR=       -96;
const SQL_UNICODE_LONGVARCHAR=   -97;
const SQL_UNICODE_CHAR=          SQL_UNICODE;
const SQL_TYPE_DRIVER_START=     SQL_INTERVAL_YEAR;
const SQL_TYPE_DRIVER_END=       SQL_UNICODE_LONGVARCHAR;

const SQL_SPEC_MAJOR=      2;     // Major version of specification  */
const SQL_SPEC_MINOR=      50;    // Minor version of specification  */
const SQL_SQLSTATE_SIZE=   5;     // size of SQLSTATE */
const SQL_MAX_MESSAGE_LENGTH = 512;             // message buffer size */
const SQL_MAX_DSN_LENGTH= 32;     // maximum data source name size*/
const SQL_INVALID_HANDLE=-2;
const SQL_ERROR=         -1;
const SQL_SUCCESS=       0;
const SQL_SUCCESS_WITH_INFO= 1;
const SQL_NO_DATA_FOUND= 100;
const SQL_CHAR=          1;
const SQL_NUMERIC=       2;
const SQL_DECIMAL=       3;
const SQL_INTEGER=       4;
const SQL_SMALLINT=      5;
const SQL_FLOAT=         6;
const SQL_REAL=          7;
const SQL_DOUBLE=        8;
const SQL_VARCHAR=       12;
const SQL_TYPE_NULL=     0;
const SQL_TYPE_MIN=     SQL_BIT;
const SQL_TYPE_MAX=      SQL_VARCHAR;
const SQL_ALL_TYPES=    0;
const SQL_C_CHAR=    SQL_CHAR;
const SQL_C_LONG=    SQL_INTEGER;
const SQL_C_SHORT=   SQL_SMALLINT;
const SQL_C_FLOAT=   SQL_REAL;
const SQL_C_DOUBLE=  SQL_DOUBLE;
const SQL_C_DEFAULT= 99;
const SQL_NO_NULLS=      0;
const SQL_NULLABLE=      1;
const SQL_NULLABLE_UNKNOWN=            2;
const SQL_NULL_DATA=     -1;
const SQL_DATA_AT_EXEC=  -2;
const SQL_NTS=           -3;
const SQL_CLOSE=         0;
const SQL_DROP=          1;
const SQL_UNBIND=        2;
const SQL_RESET_PARAMS=  3;
const SQL_COMMIT=        0;
const SQL_ROLLBACK=      1;
const SQL_COLUMN_COUNT=  0;
const SQL_COLUMN_NAME=   1;
const SQL_COLUMN_TYPE=   2;
const SQL_COLUMN_LENGTH= 3;
const SQL_COLUMN_PRECISION=            4;
const SQL_COLUMN_SCALE=  5;
const SQL_COLUMN_DISPLAY_SIZE=         6;
const SQL_COLUMN_NULLABLE=             7;
const SQL_COLUMN_UNSIGNED=             8;
const SQL_COLUMN_MONEY=  9;
const SQL_COLUMN_UPDATABLE=            10;
const SQL_COLUMN_AUTO_INCREMENT=       11;
const SQL_COLUMN_CASE_SENSITIVE=       12;
const SQL_COLUMN_SEARCHABLE=           13;
const SQL_COLUMN_TYPE_NAME=            14;
const SQL_COLUMN_TABLE_NAME=           15;
const SQL_COLUMN_OWNER_NAME=           16;
const SQL_COLUMN_QUALIFIER_NAME=       17;
const SQL_COLUMN_LABEL=  18;
const SQL_COLATT_OPT_MAX=SQL_COLUMN_LABEL;
const SQL_COLUMN_DRIVER_START=         1000;
const SQL_COLATT_OPT_MIN=SQL_COLUMN_COUNT;
const SQL_ATTR_READONLY= 0;
const SQL_ATTR_WRITE=    1;
const SQL_ATTR_READWRITE_UNKNOWN=      2;
const SQL_UNSEARCHABLE=  0;
const SQL_LIKE_ONLY=     1;
const SQL_ALL_EXCEPT_LIKE=             2;
const SQL_SEARCHABLE=    3;
const SQL_NULL_HENV=     0;
const SQL_NULL_HDBC=     0;
const SQL_NULL_HSTMT=    0;

type DATE_STRUCT=record
        year:word;
        month:word;
        day:word;
end;

type TIME_STRUCT=record
        hour:word;
        minute:word;
        second:word;
end;

type TIMESTAMP_STRUCT=record
        year:word;
        month:word;
        day:word;
        hour:word;
        minute:word;
        second:word;
        fraction:cardinal;
end;

procedure SQLAllocConnect(
    henv:HANDLE;
    phdbc:pHANDLE):word;

procedure SQLAllocEnv(
    phenv:pHANDLE):word;

procedure SQLAllocStmt(
    hdbc:HANDLE;
    phstmt:pHANDLE):word;

procedure SQLBindCol(
    hstmt:HANDLE;
    icol:word;
    fCType:word;
    rgbValue:address;
    cbValueMax:integer;
    pcbValue:pINT):word;

procedure SQLCancel(
    hstmt:HANDLE):word;

procedure SQLColAttributes(
    hstmt:HANDLE;
    icol:word;
    fDescType:word;
    rgbDesc:address;
    cbDescMax:word;
    pcbDesc:pWORD;
    pfDesc:pINT):word;

procedure SQLConnect(
    hdbc:HANDLE;
    szDSN:pstr;
    cbDSN:word;
    szUID:pstr;
    cbUID:word;
    szAuthStr:pstr;
    cbAuthStr:word):word;

procedure SQLDescribeCol(
    hstmt:HANDLE;
    icol:word;
    szColName:pstr;
    cbColNameMax:word;
    pcbColName:pWORD;
    pfSqlType:pWORD;
    pcbColDef:pCARDINAL;
    pibScale:pWORD;
    pfNullable:pWORD):word;

procedure SQLDisconnect(
    hdbc:HANDLE):word;

procedure SQLError(
    henv:HANDLE;
    hdbc:HANDLE;
    hstmt:HANDLE;
    szSqlState:pstr;
    pfNativeError:pINT;
    szErrorMsg:pstr;
    cbErrorMsgMax:word;
    pcbErrorMsg:pWORD):word;

procedure SQLExecDirect(
    hstmt:HANDLE;
    szSqlStr:pstr;
    cbSqlStr:integer):word;

procedure SQLExecute(
    hstmt:HANDLE):word;

procedure SQLFetch(
    hstmt:HANDLE):word;

procedure SQLFreeConnect(
    hdbc:HANDLE):word;

procedure SQLFreeEnv(
    henv:HANDLE):word;

procedure SQLFreeStmt(
    hstmt:HANDLE;
    fOption:word):word;

procedure SQLGetCursorName(
    hstmt:HANDLE;
    szCursor:pstr;
    cbCursorMax:word;
    pcbCursor:pWORD):word;

procedure SQLNumResultCols(
    hstmt:HANDLE;
    pccol:pWORD):word;

procedure SQLPrepare(
    hstmt:HANDLE;
    szSqlStr:pstr;
    cbSqlStr:integer):word;

procedure SQLRowCount(
    hstmt:HANDLE;
    pcrow:pINT):word;

procedure SQLSetCursorName(
    hstmt:HANDLE;
    szCursor:pstr;
    cbCursor:word):word;

procedure SQLTransact(
    henv:HANDLE;
    hdbc:HANDLE;
    fType:word):word;

procedure SQLSetParam(            //      Use SQLBindParameter */
    hstmt:HANDLE;
    ipar:word;
    fCType:word;
    fSqlType:word;
    cbParamDef:cardinal;
    ibScale:word;
    rgbValue:address;
    pcbValue:pINT):word;

const SQL_SIGNED_OFFSET=       -20;
const SQL_UNSIGNED_OFFSET=     -22;
const SQL_NO_TOTAL=      -4;
const SQL_API_SQLALLOCCONNECT=      1;    // Core Functions           */
const SQL_API_SQLALLOCENV=2;
const SQL_API_SQLALLOCSTMT=3;
const SQL_API_SQLBINDCOL= 4;
const SQL_API_SQLCANCEL=  5;
const SQL_API_SQLCOLATTRIBUTES=6;
const SQL_API_SQLCONNECT= 7;
const SQL_API_SQLDESCRIBECOL=  8;
const SQL_API_SQLDISCONNECT=   9;
const SQL_API_SQLERROR=  10;
const SQL_API_SQLEXECDIRECT=  11;
const SQL_API_SQLEXECUTE=12;
const SQL_API_SQLFETCH=  13;
const SQL_API_SQLFREECONNECT= 14;
const SQL_API_SQLFREEENV=15;
const SQL_API_SQLFREESTMT=16;
const SQL_API_SQLGETCURSORNAME=    17;
const SQL_API_SQLNUMRESULTCOLS=    18;
const SQL_API_SQLPREPARE=19;
const SQL_API_SQLROWCOUNT=20;
const SQL_API_SQLSETCURSORNAME=    21;
const SQL_API_SQLSETPARAM=22;
const SQL_API_SQLTRANSACT=23;
const SQL_NUM_FUNCTIONS= 23;
const SQL_EXT_API_START= 40;
const SQL_API_SQLCOLUMNS=40;    // Level 1 Functions        */
const SQL_API_SQLDRIVERCONNECT=    41;
const SQL_API_SQLGETCONNECTOPTION= 42;
const SQL_API_SQLGETDATA=43;
const SQL_API_SQLGETFUNCTIONS=44;
const SQL_API_SQLGETINFO=45;
const SQL_API_SQLGETSTMTOPTION=    46;
const SQL_API_SQLGETTYPEINFO= 47;
const SQL_API_SQLPARAMDATA=   48;
const SQL_API_SQLPUTDATA=49;
const SQL_API_SQLSETCONNECTOPTION= 50;
const SQL_API_SQLSETSTMTOPTION=    51;
const SQL_API_SQLSPECIALCOLUMNS=   52;
const SQL_API_SQLSTATISTICS=  53;
const SQL_API_SQLTABLES= 54;
const SQL_API_SQLBROWSECONNECT=    55;    // Level 2 Functions        */
const SQL_API_SQLCOLUMNPRIVILEGES= 56;
const SQL_API_SQLDATASOURCES= 57;
const SQL_API_SQLDESCRIBEPARAM=    58;
const SQL_API_SQLEXTENDEDFETCH=    59;
const SQL_API_SQLFOREIGNKEYS= 60;
const SQL_API_SQLMORERESULTS= 61;
const SQL_API_SQLNATIVESQL=   62;
const SQL_API_SQLNUMPARAMS=   63;
const SQL_API_SQLPARAMOPTIONS=64;
const SQL_API_SQLPRIMARYKEYS= 65;
const SQL_API_SQLPROCEDURECOLUMNS= 66;
const SQL_API_SQLPROCEDURES=  67;
const SQL_API_SQLSETPOS= 68;
const SQL_API_SQLSETSCROLLOPTIONS= 69;
const SQL_API_SQLTABLEPRIVILEGES=  70;
const SQL_API_SQLDRIVERS=71;
const SQL_API_SQLBINDPARAMETER=    72;
const SQL_EXT_API_LAST=  SQL_API_SQLBINDPARAMETER;
const SQL_API_ALL_FUNCTIONS=  0;
const SQL_NUM_EXTENSIONS= SQL_EXT_API_LAST-SQL_EXT_API_START+1;
const SQL_API_LOADBYORDINAL=  199;
const SQL_INFO_FIRST=         0;
const SQL_ACTIVE_CONNECTIONS= 0;
const SQL_ACTIVE_STATEMENTS=  1;
const SQL_DATA_SOURCE_NAME=   2;
const SQL_DRIVER_HDBC=        3;
const SQL_DRIVER_HENV=        4;
const SQL_DRIVER_HSTMT=       5;
const SQL_DRIVER_NAME=        6;
const SQL_DRIVER_VER=         7;
const SQL_FETCH_DIRECTION=    8;
const SQL_ODBC_API_CONFORMANCE=   9;
const SQL_ODBC_VER=          10;
const SQL_ROW_UPDATES=       11;
const SQL_ODBC_SAG_CLI_CONFORMANCE=        12;
const SQL_SERVER_NAME=       13;
const SQL_SEARCH_PATTERN_ESCAPE=           14;
const SQL_ODBC_SQL_CONFORMANCE=            15;
const SQL_DBMS_NAME=         17;
const SQL_DBMS_VER=          18;
const SQL_ACCESSIBLE_TABLES= 19;
const SQL_ACCESSIBLE_PROCEDURES=           20;
const SQL_PROCEDURES=        21;
const SQL_CONCAT_NULL_BEHAVIOR=            22;
const SQL_CURSOR_COMMIT_BEHAVIOR=          23;
const SQL_CURSOR_ROLLBACK_BEHAVIOR=        24;
const SQL_DATA_SOURCE_READ_ONLY=           25;
const SQL_DEFAULT_TXN_ISOLATION=           26;
const SQL_EXPRESSIONS_IN_ORDERBY=          27;
const SQL_IDENTIFIER_CASE=   28;
const SQL_IDENTIFIER_QUOTE_CHAR=           29;
const SQL_MAX_COLUMN_NAME_LEN=           30;
const SQL_MAX_CURSOR_NAME_LEN=            31;
const SQL_MAX_OWNER_NAME_LEN=32;
const SQL_MAX_PROCEDURE_NAME_LEN=          33;
const SQL_MAX_QUALIFIER_NAME_LEN=          34;
const SQL_MAX_TABLE_NAME_LEN=35;
const SQL_MULT_RESULT_SETS=  36;
const SQL_MULTIPLE_ACTIVE_TXN=             37;
const SQL_OUTER_JOINS=       38;
const SQL_OWNER_TERM=        39;
const SQL_PROCEDURE_TERM=    40;
const SQL_QUALIFIER_NAME_SEPARATOR=        41;
const SQL_QUALIFIER_TERM=    42;
const SQL_SCROLL_CONCURRENCY=43;
const SQL_SCROLL_OPTIONS=    44;
const SQL_TABLE_TERM=        45;
const SQL_TXN_CAPABLE=       46;
const SQL_USER_NAME=         47;
const SQL_CONVERT_FUNCTIONS= 48;
const SQL_NUMERIC_FUNCTIONS= 49;
const SQL_STRING_FUNCTIONS=  50;
const SQL_SYSTEM_FUNCTIONS=  51;
const SQL_TIMEDATE_FUNCTIONS=52;
const SQL_CONVERT_BIGINT=    53;
const SQL_CONVERT_BINARY=    54;
const SQL_CONVERT_BIT=       55;
const SQL_CONVERT_CHAR=      56;
const SQL_CONVERT_DATE=      57;
const SQL_CONVERT_DECIMAL=   58;
const SQL_CONVERT_DOUBLE=    59;
const SQL_CONVERT_FLOAT=     60;
const SQL_CONVERT_INTEGER=   61;
const SQL_CONVERT_LONGVARCHAR=             62;
const SQL_CONVERT_NUMERIC=   63;
const SQL_CONVERT_REAL=      64;
const SQL_CONVERT_SMALLINT=  65;
const SQL_CONVERT_TIME=      66;
const SQL_CONVERT_TIMESTAMP= 67;
const SQL_CONVERT_TINYINT=   68;
const SQL_CONVERT_VARBINARY= 69;
const SQL_CONVERT_VARCHAR=   70;
const SQL_CONVERT_LONGVARBINARY=           71;
const SQL_TXN_ISOLATION_OPTION=            72;
const SQL_ODBC_SQL_OPT_IEF=  73;
const SQL_CORRELATION_NAME=  74;
const SQL_NON_NULLABLE_COLUMNS =           75;
const SQL_DRIVER_HLIB=       76;
const SQL_DRIVER_ODBC_VER=   77;
const SQL_LOCK_TYPES=        78;
const SQL_POS_OPERATIONS=    79;
const SQL_POSITIONED_STATEMENTS=           80;
const SQL_GETDATA_EXTENSIONS=81;
const SQL_BOOKMARK_PERSISTENCE=            82;
const SQL_STATIC_SENSITIVITY=83;
const SQL_FILE_USAGE=        84;
const SQL_NULL_COLLATION=    85;
const SQL_ALTER_TABLE=       86;
const SQL_COLUMN_ALIAS=      87;
const SQL_GROUP_BY=          88;
const SQL_KEYWORDS=          89;
const SQL_ORDER_BY_COLUMNS_IN_SELECT=      90;
const SQL_OWNER_USAGE=       91;
const SQL_QUALIFIER_USAGE=   92;
const SQL_QUOTED_IDENTIFIER_CASE=          93;
const SQL_SPECIAL_CHARACTERS=94;
const SQL_SUBQUERIES=        95;
const SQL_UNION=             96;
const SQL_MAX_COLUMNS_IN_GROUP_BY=         97;
const SQL_MAX_COLUMNS_IN_INDEX=            98;
const SQL_MAX_COLUMNS_IN_ORDER_BY=         99;
const SQL_MAX_COLUMNS_IN_SELECT=           100;
const SQL_MAX_COLUMNS_IN_TABLE=            101;
const SQL_MAX_INDEX_SIZE=    102;
const SQL_MAX_ROW_SIZE_INCLUDES_LONG=      103;
const SQL_MAX_ROW_SIZE=      104;
const SQL_MAX_STATEMENT_LEN= 105;
const SQL_MAX_TABLES_IN_SELECT=            106;
const SQL_MAX_USER_NAME_LEN= 107;
const SQL_MAX_CHAR_LITERAL_LEN=            108;
const SQL_TIMEDATE_ADD_INTERVALS=          109;
const SQL_TIMEDATE_DIFF_INTERVALS=         110;
const SQL_NEED_LONG_DATA_LEN=111;
const SQL_MAX_BINARY_LITERAL_LEN=          112;
const SQL_LIKE_ESCAPE_CLAUSE=113;
const SQL_QUALIFIER_LOCATION=114;
const SQL_OJ_CAPABILITIES=         65003;  // Temp value until ODBC 3.0 */
const SQL_INFO_LAST=         SQL_QUALIFIER_LOCATION;
const SQL_INFO_DRIVER_START= 1000;
const SQL_CVT_CHAR=          0x00000001;
const SQL_CVT_NUMERIC=       0x00000002;
const SQL_CVT_DECIMAL=       0x00000004;
const SQL_CVT_INTEGER=       0x00000008;
const SQL_CVT_SMALLINT=      0x00000010;
const SQL_CVT_FLOAT=         0x00000020;
const SQL_CVT_REAL=          0x00000040;
const SQL_CVT_DOUBLE=        0x00000080;
const SQL_CVT_VARCHAR=       0x00000100;
const SQL_CVT_LONGVARCHAR=   0x00000200;
const SQL_CVT_BINARY=        0x00000400;
const SQL_CVT_VARBINARY=     0x00000800;
const SQL_CVT_BIT=           0x00001000;
const SQL_CVT_TINYINT=       0x00002000;
const SQL_CVT_BIGINT=        0x00004000;
const SQL_CVT_DATE=          0x00008000;
const SQL_CVT_TIME=          0x00010000;
const SQL_CVT_TIMESTAMP=     0x00020000;
const SQL_CVT_LONGVARBINARY= 0x00040000;
const SQL_FN_CVT_CONVERT=    0x00000001;
const SQL_FN_STR_CONCAT=     0x00000001;
const SQL_FN_STR_INSERT=     0x00000002;
const SQL_FN_STR_LEFT=       0x00000004;
const SQL_FN_STR_LTRIM=      0x00000008;
const SQL_FN_STR_LENGTH=     0x00000010;
const SQL_FN_STR_LOCATE=     0x00000020;
const SQL_FN_STR_LCASE=      0x00000040;
const SQL_FN_STR_REPEAT=     0x00000080;
const SQL_FN_STR_REPLACE=    0x00000100;
const SQL_FN_STR_RIGHT=      0x00000200;
const SQL_FN_STR_RTRIM=      0x00000400;
const SQL_FN_STR_SUBSTRING=  0x00000800;
const SQL_FN_STR_UCASE=      0x00001000;
const SQL_FN_STR_ASCII=      0x00002000;
const SQL_FN_STR_CHAR=       0x00004000;
const SQL_FN_STR_DIFFERENCE= 0x00008000;
const SQL_FN_STR_LOCATE_2=   0x00010000;
const SQL_FN_STR_SOUNDEX=    0x00020000;
const SQL_FN_STR_SPACE=      0x00040000;
const SQL_FN_NUM_ABS=        0x00000001;
const SQL_FN_NUM_ACOS=       0x00000002;
const SQL_FN_NUM_ASIN=       0x00000004;
const SQL_FN_NUM_ATAN=       0x00000008;
const SQL_FN_NUM_ATAN2=      0x00000010;
const SQL_FN_NUM_CEILING=    0x00000020;
const SQL_FN_NUM_COS=        0x00000040;
const SQL_FN_NUM_COT=        0x00000080;
const SQL_FN_NUM_EXP=        0x00000100;
const SQL_FN_NUM_FLOOR=      0x00000200;
const SQL_FN_NUM_LOG=        0x00000400;
const SQL_FN_NUM_MOD=        0x00000800;
const SQL_FN_NUM_SIGN=       0x00001000;
const SQL_FN_NUM_SIN=        0x00002000;
const SQL_FN_NUM_SQRT=       0x00004000;
const SQL_FN_NUM_TAN=        0x00008000;
const SQL_FN_NUM_PI=         0x00010000;
const SQL_FN_NUM_RAND=       0x00020000;
const SQL_FN_NUM_DEGREES=    0x00040000;
const SQL_FN_NUM_LOG10=      0x00080000;
const SQL_FN_NUM_POWER=      0x00100000;
const SQL_FN_NUM_RADIANS=    0x00200000;
const SQL_FN_NUM_ROUND=      0x00400000;
const SQL_FN_NUM_TRUNCATE=   0x00800000;
const SQL_FN_TD_NOW=         0x00000001;
const SQL_FN_TD_CURDATE=     0x00000002;
const SQL_FN_TD_DAYOFMONTH=  0x00000004;
const SQL_FN_TD_DAYOFWEEK=   0x00000008;
const SQL_FN_TD_DAYOFYEAR=   0x00000010;
const SQL_FN_TD_MONTH=       0x00000020;
const SQL_FN_TD_QUARTER=     0x00000040;
const SQL_FN_TD_WEEK=        0x00000080;
const SQL_FN_TD_YEAR=        0x00000100;
const SQL_FN_TD_CURTIME=     0x00000200;
const SQL_FN_TD_HOUR=        0x00000400;
const SQL_FN_TD_MINUTE=      0x00000800;
const SQL_FN_TD_SECOND=      0x00001000;
const SQL_FN_TD_TIMESTAMPADD=0x00002000;
const SQL_FN_TD_TIMESTAMPDIFF=             0x00004000;
const SQL_FN_TD_DAYNAME=     0x00008000;
const SQL_FN_TD_MONTHNAME=   0x00010000;
const SQL_FN_SYS_USERNAME=   0x00000001;
const SQL_FN_SYS_DBNAME=     0x00000002;
const SQL_FN_SYS_IFNULL=     0x00000004;
const SQL_FN_TSI_FRAC_SECOND=0x00000001;
const SQL_FN_TSI_SECOND=     0x00000002;
const SQL_FN_TSI_MINUTE=     0x00000004;
const SQL_FN_TSI_HOUR=       0x00000008;
const SQL_FN_TSI_DAY=        0x00000010;
const SQL_FN_TSI_WEEK=       0x00000020;
const SQL_FN_TSI_MONTH=      0x00000040;
const SQL_FN_TSI_QUARTER=    0x00000080;
const SQL_FN_TSI_YEAR=       0x00000100;
const SQL_OAC_NONE=          0x0000;
const SQL_OAC_LEVEL1=        0x0001;
const SQL_OAC_LEVEL2=        0x0002;
const SQL_OSCC_NOT_COMPLIANT=0x0000;
const SQL_OSCC_COMPLIANT=    0x0001;
const SQL_OSC_MINIMUM=       0x0000;
const SQL_OSC_CORE=          0x0001;
const SQL_OSC_EXTENDED=      0x0002;
const SQL_CB_NULL=           0x0000;
const SQL_CB_NON_NULL=       0x0001;
const SQL_CB_DELETE=         0x0000;
const SQL_CB_CLOSE=          0x0001;
const SQL_CB_PRESERVE=       0x0002;
const SQL_IC_UPPER=          0x0001;
const SQL_IC_LOWER=          0x0002;
const SQL_IC_SENSITIVE=      0x0003;
const SQL_IC_MIXED=          0x0004;
const SQL_TC_NONE=           0x0000;
const SQL_TC_DML=            0x0001;
const SQL_TC_ALL=            0x0002;
const SQL_TC_DDL_COMMIT=     0x0003;
const SQL_TC_DDL_IGNORE=     0x0004;
const SQL_SO_FORWARD_ONLY=   0x00000001;
const SQL_SO_KEYSET_DRIVEN=  0x00000002;
const SQL_SO_DYNAMIC=        0x00000004;
const SQL_SO_MIXED=          0x00000008;
const SQL_SO_STATIC=         0x00000010;
const SQL_SCCO_READ_ONLY=    0x00000001;
const SQL_SCCO_LOCK=         0x00000002;
const SQL_SCCO_OPT_ROWVER=   0x00000004;
const SQL_SCCO_OPT_VALUES=   0x00000008;
const SQL_FD_FETCH_NEXT=     0x00000001;
const SQL_FD_FETCH_FIRST=    0x00000002;
const SQL_FD_FETCH_LAST=     0x00000004;
const SQL_FD_FETCH_PRIOR=    0x00000008;
const SQL_FD_FETCH_ABSOLUTE= 0x00000010;
const SQL_FD_FETCH_RELATIVE= 0x00000020;
const SQL_FD_FETCH_RESUME=   0x00000040;
const SQL_FD_FETCH_BOOKMARK= 0x00000080;
const SQL_TXN_READ_UNCOMMITTED=            0x00000001;
const SQL_TXN_READ_COMMITTED=0x00000002;
const SQL_TXN_REPEATABLE_READ=             0x00000004;
const SQL_TXN_SERIALIZABLE=  0x00000008;
const SQL_TXN_VERSIONING=    0x00000010;
const SQL_CN_NONE=           0x0000;
const SQL_CN_DIFFERENT=      0x0001;
const SQL_CN_ANY=            0x0002;
const SQL_NNC_NULL=          0x0000;
const SQL_NNC_NON_NULL=      0x0001;
const SQL_NC_HIGH=           0x0000;
const SQL_NC_LOW=            0x0001;
const SQL_NC_START=          0x0002;
const SQL_NC_END=            0x0004;
const SQL_FILE_NOT_SUPPORTED=0x0000;
const SQL_FILE_TABLE=        0x0001;
const SQL_FILE_QUALIFIER=    0x0002;
const SQL_GD_ANY_COLUMN=     0x00000001;
const SQL_GD_ANY_ORDER=      0x00000002;
const SQL_GD_BLOCK=          0x00000004;
const SQL_GD_BOUND=          0x00000008;
const SQL_AT_ADD_COLUMN=     0x00000001;
const SQL_AT_DROP_COLUMN=    0x00000002;
const SQL_PS_POSITIONED_DELETE=            0x00000001;
const SQL_PS_POSITIONED_UPDATE=            0x00000002;
const SQL_PS_SELECT_FOR_UPDATE=            0x00000004;
const SQL_GB_NOT_SUPPORTED=  0x0000;
const SQL_GB_GROUP_BY_EQUALS_SELECT=       0x0001;
const SQL_GB_GROUP_BY_CONTAINS_SELECT=     0x0002;
const SQL_GB_NO_RELATION=    0x0003;
const SQL_OU_DML_STATEMENTS= 0x00000001;
const SQL_OU_PROCEDURE_INVOCATION=         0x00000002;
const SQL_OU_TABLE_DEFINITION=             0x00000004;
const SQL_OU_INDEX_DEFINITION=             0x00000008;
const SQL_OU_PRIVILEGE_DEFINITION=         0x00000010;
const SQL_QU_DML_STATEMENTS= 0x00000001;
const SQL_QU_PROCEDURE_INVOCATION=         0x00000002;
const SQL_QU_TABLE_DEFINITION=             0x00000004;
const SQL_QU_INDEX_DEFINITION=             0x00000008;
const SQL_QU_PRIVILEGE_DEFINITION=         0x00000010;
const SQL_SQ_COMPARISON=     0x00000001;
const SQL_SQ_EXISTS=         0x00000002;
const SQL_SQ_IN=             0x00000004;
const SQL_SQ_QUANTIFIED=     0x00000008;
const SQL_SQ_CORRELATED_SUBQUERIES=        0x00000010;
const SQL_U_UNION=           0x00000001;
const SQL_U_UNION_ALL=       0x00000002;
const SQL_BP_CLOSE=          0x00000001;
const SQL_BP_DELETE=         0x00000002;
const SQL_BP_DROP=           0x00000004;
const SQL_BP_TRANSACTION=    0x00000008;
const SQL_BP_UPDATE=         0x00000010;
const SQL_BP_OTHER_HSTMT=    0x00000020;
const SQL_BP_SCROLL=         0x00000040;
const SQL_SS_ADDITIONS=      0x00000001;
const SQL_SS_DELETIONS=      0x00000002;
const SQL_SS_UPDATES=        0x00000004;
const SQL_LCK_NO_CHANGE=     0x00000001;
const SQL_LCK_EXCLUSIVE=     0x00000002;
const SQL_LCK_UNLOCK=        0x00000004;
const SQL_POS_POSITION=      0x00000001;
const SQL_POS_REFRESH=       0x00000002;
const SQL_POS_UPDATE=        0x00000004;
const SQL_POS_DELETE=        0x00000008;
const SQL_POS_ADD=           0x00000010;
const SQL_QL_START=          0x0001;
const SQL_QL_END=            0x0002;
const SQL_OJ_LEFT=           0x00000001;
const SQL_OJ_RIGHT=          0x00000002;
const SQL_OJ_FULL=           0x00000004;
const SQL_OJ_NESTED=         0x00000008;
const SQL_OJ_NOT_ORDERED=    0x00000010;
const SQL_OJ_INNER=          0x00000020;
const SQL_OJ_ALL_COMPARISON_OPS=           0x00000040;
const SQL_QUERY_TIMEOUT= 0;
const SQL_MAX_ROWS=      1;
const SQL_NOSCAN=        2;
const SQL_MAX_LENGTH=    3;
const SQL_ASYNC_ENABLE=  4;
const SQL_BIND_TYPE=     5;
const SQL_CURSOR_TYPE=   6;
const SQL_CONCURRENCY=   7;
const SQL_KEYSET_SIZE=   8;
const SQL_ROWSET_SIZE=   9;
const SQL_SIMULATE_CURSOR=             10;
const SQL_RETRIEVE_DATA= 11;
const SQL_USE_BOOKMARKS= 12;
const SQL_GET_BOOKMARK=  13;     //      GetStmtOption Only */
const SQL_ROW_NUMBER=    14;      //      GetStmtOption Only */
const SQL_STMT_OPT_MAX=  SQL_ROW_NUMBER;
const SQL_STMT_OPT_MIN=  SQL_QUERY_TIMEOUT;
const SQL_QUERY_TIMEOUT_DEFAULT=       0;
const SQL_MAX_ROWS_DEFAULT=            0;
const SQL_NOSCAN_OFF=    0;     //      1.0 FALSE */
const SQL_NOSCAN_ON=     1;     //      1.0 TRUE */
const SQL_NOSCAN_DEFAULT=SQL_NOSCAN_OFF;
const SQL_MAX_LENGTH_DEFAULT=          0;
const SQL_ASYNC_ENABLE_OFF=            0;
const SQL_ASYNC_ENABLE_ON=             1;
const SQL_ASYNC_ENABLE_DEFAULT=        SQL_ASYNC_ENABLE_OFF;
const SQL_BIND_BY_COLUMN=0;
const SQL_BIND_TYPE_DEFAULT=           SQL_BIND_BY_COLUMN;  // Default value */
const SQL_CONCUR_READ_ONLY=            1;
const SQL_CONCUR_LOCK=   2;
const SQL_CONCUR_ROWVER= 3;
const SQL_CONCUR_VALUES= 4;
const SQL_CONCUR_DEFAULT=SQL_CONCUR_READ_ONLY; // Default value
const SQL_CURSOR_FORWARD_ONLY=         0;
const SQL_CURSOR_KEYSET_DRIVEN=        1;
const SQL_CURSOR_DYNAMIC=2;
const SQL_CURSOR_STATIC= 3;
const SQL_CURSOR_TYPE_DEFAULT=         SQL_CURSOR_FORWARD_ONLY; // Default value */
const SQL_ROWSET_SIZE_DEFAULT=         1;
const SQL_KEYSET_SIZE_DEFAULT=         0;
const SQL_SC_NON_UNIQUE= 0;
const SQL_SC_TRY_UNIQUE= 1;
const SQL_SC_UNIQUE=     2;
const SQL_RD_OFF=        0;
const SQL_RD_ON=         1;
const SQL_RD_DEFAULT=    SQL_RD_ON;
const SQL_UB_OFF=        0;
const SQL_UB_ON=         1;
const SQL_UB_DEFAULT=    SQL_UB_OFF;
const SQL_ACCESS_MODE=   101;
const SQL_AUTOCOMMIT=    102;
const SQL_LOGIN_TIMEOUT= 103;
const SQL_OPT_TRACE=     104;
const SQL_OPT_TRACEFILE= 105;
const SQL_TRANSLATE_DLL= 106;
const SQL_TRANSLATE_OPTION=            107;
const SQL_TXN_ISOLATION= 108;
const SQL_CURRENT_QUALIFIER=           109;
const SQL_ODBC_CURSORS=  110;
const SQL_QUIET_MODE=    111;
const SQL_PACKET_SIZE=   112;
const SQL_CONN_OPT_MAX=  SQL_PACKET_SIZE;
const SQL_CONNECT_OPT_DRVR_START=      1000;
const SQL_CONN_OPT_MIN=  SQL_ACCESS_MODE;
const SQL_MODE_READ_WRITE=             0;
const SQL_MODE_READ_ONLY=1;
const SQL_MODE_DEFAULT=  SQL_MODE_READ_WRITE;
const SQL_AUTOCOMMIT_OFF=0;
const SQL_AUTOCOMMIT_ON= 1;
const SQL_AUTOCOMMIT_DEFAULT=          SQL_AUTOCOMMIT_ON;
const SQL_LOGIN_TIMEOUT_DEFAULT=       15L;
const SQL_OPT_TRACE_OFF= 0;
const SQL_OPT_TRACE_ON=  1;
const SQL_OPT_TRACE_DEFAULT=           SQL_OPT_TRACE_OFF;
const SQL_CUR_USE_IF_NEEDED=           0;
const SQL_CUR_USE_ODBC=  1;
const SQL_CUR_USE_DRIVER=2;
const SQL_CUR_DEFAULT=   SQL_CUR_USE_DRIVER;
const SQL_BEST_ROWID=    1;
const SQL_ROWVER=        2;
const SQL_SCOPE_CURROW=  0;
const SQL_SCOPE_TRANSACTION=           1;
const SQL_SCOPE_SESSION= 2;
const SQL_INDEX_UNIQUE=  0;
const SQL_INDEX_ALL=     1;
const SQL_QUICK=         0;
const SQL_ENSURE=        1;
const SQL_TABLE_STAT=    0;
const SQL_INDEX_CLUSTERED=             1;
const SQL_INDEX_HASHED=  2;
const SQL_INDEX_OTHER=   3;
const SQL_PC_UNKNOWN=    0;
const SQL_PC_NOT_PSEUDO= 1;
const SQL_PC_PSEUDO=     2;
const SQL_FETCH_NEXT= 1;
const SQL_FETCH_FIRST= 2;

procedure SQLColumns(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word;
    szColumnName:pstr;
    cbColumnName:word):word;

procedure SQLGetConnectOption(
    hdbc:HANDLE;
    fOption:word;
    pvParam:address):word;

procedure SQLGetData(
    hstmt:HANDLE;
    icol:word;
    fCType:word;
    rgbValue:address;
    cbValueMax:integer;
    pcbValue:pINT):word;

procedure SQLGetFunctions(
    hdbc:HANDLE;
    fFunction:word;
    pfExists:pWORD):word;

procedure SQLGetInfo(
    hdbc:HANDLE;
    fInfoType:word;
    rgbInfoValue:address;
    cbInfoValueMax:word;
   pcbInfoValue:pWORD):word;

procedure SQLGetStmtOption(
    hstmt:HANDLE;
    fOption:word;
    pvParam:address):word;

procedure SQLGetTypeInfo(
    hstmt:HANDLE;
    fSqlType:word):word;

procedure SQLParamData(
    hstmt:HANDLE;
    prgbValue:address):word;

procedure SQLPutData(
    hstmt:HANDLE;
    rgbValue:address;
    cbValue:integer):word;

procedure SQLSetConnectOption(
    hdbc:HANDLE;
    fOption:word;
    vParam:cardinal):word;

procedure SQLSetStmtOption(
    hstmt:HANDLE;
    fOption:word;
    vParam:cardinal):word;

procedure SQLSpecialColumns(
    hstmt:HANDLE;
    fColType:word;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word;
    fScope:word;
    fNullable:word):word;

procedure SQLStatistics(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word;
    fUnique:word;
    fAccuracy:word):word;

procedure SQLTables(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word;
    szTableType:pstr;
    cbTableType:word):word;

procedure SQLDataSources(
    henv:HANDLE;
    fDirection:word;
    szDSN:pstr;
    cbDSNMax:word;
    pcbDSN:pWORD;
    szDescription:pstr;
    cbDescriptionMax:word;
    pcbDescription:pWORD):word;

const SQL_FETCH_LAST=     3;
const SQL_FETCH_PRIOR=    4;
const SQL_FETCH_ABSOLUTE= 5;
const SQL_FETCH_RELATIVE= 6;
const SQL_FETCH_BOOKMARK= 8;
const SQL_ROW_SUCCESS=    0;
const SQL_ROW_DELETED=    1;
const SQL_ROW_UPDATED=    2;
const SQL_ROW_NOROW=      3;
const SQL_ROW_ADDED=      4;
const SQL_ROW_ERROR=      5;
const SQL_CASCADE=        0;
const SQL_RESTRICT=       1;
const SQL_SET_NULL=       2;
const SQL_NO_ACTION= 3;
const SQL_SET_DEFAULT=  4;
const SQL_PARAM_TYPE_UNKNOWN=           0;
const SQL_PARAM_INPUT=    1;
const SQL_PARAM_INPUT_OUTPUT=           2;
const SQL_RESULT_COL=     3;
const SQL_PARAM_OUTPUT=   4;
const SQL_RETURN_VALUE=   5;
const SQL_PT_UNKNOWN=     0;
const SQL_PT_PROCEDURE=   1;
const SQL_PT_FUNCTION=    2;
const SQL_PARAM_TYPE_DEFAULT=           SQL_PARAM_INPUT_OUTPUT;
const SQL_SETPARAM_VALUE_MAX=           -1;

const SQL_DATABASE_NAME= 16;    // Use SQLGetConnectOption/SQL_CURRENT_QUALIFIER */
const SQL_FD_FETCH_PREV= SQL_FD_FETCH_PRIOR;
const SQL_FETCH_PREV=    SQL_FETCH_PRIOR;
const SQL_CONCUR_TIMESTAMP=            SQL_CONCUR_ROWVER;
const SQL_SCCO_OPT_TIMESTAMP=          SQL_SCCO_OPT_ROWVER;
const SQL_CC_DELETE=     SQL_CB_DELETE;
const SQL_CR_DELETE=     SQL_CB_DELETE;
const SQL_CC_CLOSE=      SQL_CB_CLOSE;
const SQL_CR_CLOSE=      SQL_CB_CLOSE;
const SQL_CC_PRESERVE=   SQL_CB_PRESERVE;
const SQL_CR_PRESERVE=   SQL_CB_PRESERVE;
const SQL_FETCH_RESUME=  7;     // Not supported by 2.0 drivers */
const SQL_SCROLL_FORWARD_ONLY=         0;    //-SQL_CURSOR_FORWARD_ONLY */
const SQL_SCROLL_KEYSET_DRIVEN=        -1; //-SQL_CURSOR_KEYSET_DRIVEN */
const SQL_SCROLL_DYNAMIC=-2; //-SQL_CURSOR_DYNAMIC */
const SQL_SCROLL_STATIC= -3L; //-SQL_CURSOR_STATIC */
const SQL_PC_NON_PSEUDO= SQL_PC_NOT_PSEUDO;

procedure SQLSetScrollOptions(    //      Use SQLSetStmtOptions */
    hstmt:HANDLE;
    fConcurrency:word;
    crowKeyset:integer;
    crowRowset:word):cardinal;

const SQL_DEFAULT_PARAM=            -5;
const SQL_IGNORE=     -6;
const SQL_LEN_DATA_AT_EXEC_OFFSET=  -100;
const SQL_ENTIRE_ROWSET=            0;
const SQL_POSITION=   0;               //      1.0 FALSE */
const SQL_REFRESH=    1;               //      1.0 TRUE */
const SQL_UPDATE=     2;
const SQL_DELETE=     3;
const SQL_ADD=        4;
const SQL_LOCK_NO_CHANGE=           0; //      1.0 FALSE */
const SQL_LOCK_EXCLUSIVE=           1; //      1.0 TRUE */
const SQL_LOCK_UNLOCK=2;
const SQL_DRIVER_NOPROMPT=             0;
const SQL_DRIVER_COMPLETE=             1;
const SQL_DRIVER_PROMPT= 2;
const SQL_DRIVER_COMPLETE_REQUIRED=    3;

procedure SQLDriverConnect(
    hdbc:HANDLE;
    hwnd:HWND;
    szConnStrIn:pstr;
    cbConnStrIn:word;
    szConnStrOut:pstr;
    cbConnStrOutMax:word;
    pcbConnStrOut:pWORD;
    fDriverCompletion:word):cardinal;

procedure SQLBrowseConnect(
    hdbc:HANDLE;
    szConnStrIn:pstr;
    cbConnStrIn:word;
    szConnStrOut:pstr;
    cbConnStrOutMax:word;
    pcbConnStrOut:pWORD):cardinal;

procedure SQLColumnPrivileges(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word;
    szColumnName:pstr;
    cbColumnName:word):cardinal;

procedure SQLDescribeParam(
    hstmt:HANDLE;
    ipar:word;
    pfSqlType:pWORD;
    pcbParamDef:pCARDINAL;
    pibScale:pWORD;
    pfNullable:pWORD):cardinal;

procedure SQLExtendedFetch(
    hstmt:HANDLE;
    fFetchType:word;
    irow:integer;
    pcrow:pCARDINAL;
    rgfRowStatus:pWORD):cardinal;

procedure SQLForeignKeys(
    hstmt:HANDLE;
    szPkCatalogName:pstr;
    cbPkCatalogName:word;
    szPkSchemaName:pstr;
    cbPkSchemaName:word;
    szPkTableName:pstr;
    cbPkTableName:word;
    szFkCatalogName:pstr;
    cbFkCatalogName:word;
    szFkSchemaName:pstr;
    cbFkSchemaName:word;
    szFkTableName:pstr;
    cbFkTableName:word):cardinal;

procedure SQLMoreResults(
    hstmt:HANDLE):cardinal;

procedure SQLNativeSql(
    hdbc:HANDLE;
    szSqlStrIn:pstr;
    cbSqlStrIn:integer;
    szSqlStr:pstr;
    cbSqlStrMax:integer;
    pcbSqlStr:pINT):cardinal;

procedure SQLNumParams(
    hstmt:HANDLE;
    pcpar:pWORD):cardinal;

procedure SQLParamOptions(
    hstmt:HANDLE;
    crow:cardinal;
    pirow:pCARDINAL):cardinal;

procedure SQLPrimaryKeys(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word):cardinal;

procedure SQLProcedureColumns(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szProcName:pstr;
    cbProcName:word;
    szColumnName:pstr;
    cbColumnName:word):cardinal;

procedure SQLProcedures(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szProcName:pstr;
    cbProcName:word):cardinal;

procedure SQLSetPos(
    hstmt:HANDLE;
    irow:word;
    fOption:word;
    fLock:word):cardinal;

procedure SQLTablePrivileges(
    hstmt:HANDLE;
    szCatalogName:pstr;
    cbCatalogName:word;
    szSchemaName:pstr;
    cbSchemaName:word;
    szTableName:pstr;
    cbTableName:word):cardinal;

procedure SQLDrivers(
    henv:HANDLE;
    fDirection:word;
    szDriverDesc:pstr;
    cbDriverDescMax:word;
    pcbDriverDesc:pWORD;
    szDriverAttributes:pstr;
    cbDrvrAttrMax:word;
    pcbDrvrAttr:pWORD):cardinal;

procedure SQLBindParameter(
    hstmt:HANDLE;
    ipar:word;
    fParamType:word;
    fCType:word;
    fSqlType:word;
    cbColDef:cardinal;
    ibScale:word;
    rgbValue:address;
    cbValueMax:integer;
    pcbValue:pINT):cardinal;

end Win32.

